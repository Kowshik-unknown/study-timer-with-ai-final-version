import React, { useEffect, useState, useSyncExternalStore } from "react";
import GardenScene from "./GardenScene";
import { Icon } from "../icons";
import { Ring, SectionHead, Stat, CountUp } from "../shared";
import { ambient, MOODS, MoodId } from "../../lib/audioEngine";
import { fmtDur, gardenTier, MODE_LABEL, useStore, TimerMode } from "../../state/store";

const fmt = (sec: number) => {
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
};

/* ---------- distraction shield ---------- */

function DistractionShield() {
  const { state } = useStore();
  const [, force] = useState(0);

  /* tick once a second so "present for…" stays alive */
  useEffect(() => {
    const iv = window.setInterval(() => force((x) => x + 1), 1000);
    return () => window.clearInterval(iv);
  }, []);

  const presentSecs = Math.max(0, Math.floor((Date.now() - state.lastReturnAt) / 1000));

  return (
    <div className="panel p-5">
      <div className="flex items-center gap-2 mb-3.5">
        <Icon name="shield" size={16} strokeWidth={2} className="text-coral-400" />
        <span className="font-display font-bold text-sm text-mist-100">Distraction shield</span>
        <span className={`ml-auto flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wider rounded-full border px-2 py-0.5 ${
          document.hidden ? "border-coral-500/50 text-coral-300" : "border-leaf-500/50 text-leaf-400 bg-leaf-600/10"
        }`}>
          <span className={`w-1.5 h-1.5 rounded-full ${document.hidden ? "bg-coral-400" : "bg-leaf-400 pulse-dot"}`} />
          on the page
        </span>
      </div>

      <div className="grid grid-cols-3 gap-2.5">
        <div className="rounded-lg border border-leaf-500/35 bg-leaf-600/8 px-3 py-2.5">
          <div className="text-[10px] uppercase tracking-wider font-bold text-leaf-400">Present for</div>
          <div className="font-mono font-bold text-lg text-mist-100 tabular-nums leading-tight mt-0.5">{fmtDur(presentSecs)}</div>
        </div>
        <div className="rounded-lg border border-pine-600/70 bg-pine-900/50 px-3 py-2.5">
          <div className="text-[10px] uppercase tracking-wider font-bold text-mist-500">Last absence</div>
          <div className="font-mono font-bold text-lg text-mist-100 tabular-nums leading-tight mt-0.5">
            {state.lastAwaySecs > 0 ? fmtDur(state.lastAwaySecs) : "—"}
          </div>
        </div>
        <div className="rounded-lg border border-coral-500/35 bg-coral-500/8 px-3 py-2.5">
          <div className="text-[10px] uppercase tracking-wider font-bold text-coral-400">Away today</div>
          <div className="font-mono font-bold text-lg text-mist-100 tabular-nums leading-tight mt-0.5">
            {state.awaySecsToday > 0 ? fmtDur(state.awaySecsToday) : "0s"}
          </div>
        </div>
      </div>

      {state.awayLog.length > 0 ? (
        <div className="mt-3.5 space-y-1.5">
          <div className="text-[10px] uppercase tracking-widest font-bold text-mist-600">Recent absences</div>
          {state.awayLog.slice(0, 4).map((e, i) => (
            <div key={e.at + "-" + i} className="flex items-center gap-2.5 text-xs rounded-md bg-pine-900/50 border border-pine-700/60 px-3 py-1.5">
              <Icon name="clock" size={12} className="text-coral-400 shrink-0" />
              <span className="font-mono text-mist-400 tabular-nums">
                {new Date(e.at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
              </span>
              <span className="ml-auto font-semibold text-mist-200">{fmtDur(e.secs)} away</span>
            </div>
          ))}
        </div>
      ) : (
        <p className="text-[11px] text-mist-600 mt-3 leading-relaxed">
          No absences logged today. Leave this tab and Grove will time exactly how long the garden missed you.
        </p>
      )}

      <p className="text-[11px] text-mist-600 mt-3 pt-3 border-t border-pine-700/60 leading-relaxed flex items-center gap-1.5">
        <Icon name="timer" size={12} className="shrink-0" />
        {state.settings.autoPauseAway
          ? "Focus auto-pauses while you're away — resume when you return."
          : "Auto-pause is off — the timer keeps running while you're away. Change in Settings."}
      </p>
    </div>
  );
}

const PRESETS = [15, 25, 45, 60];

export default function TimerView() {
  const { state, timer, setMode, setDurationMin, startTimer, pauseTimer, resetTimer, skipPhase } = useStore();
  const [mood, setMood] = useState<MoodId>("lofi");
  const [volume, setVolume] = useState(0.65);
  const [syncMusic, setSyncMusic] = useState(true);
  useSyncExternalStore(ambient.subscribe, ambient.getVersion);

  const focusRunning = timer.running && timer.mode === "focus";
  const seedProgress = focusRunning ? 1 - timer.remaining / timer.duration : null;
  const tier = gardenTier(state.plants.length);
  const pct = 1 - timer.remaining / timer.duration;
  const isBreak = timer.mode !== "focus";

  /* auto-sync ambience with the timer */
  useEffect(() => {
    if (!syncMusic) return;
    if (timer.running && !ambient.playing) ambient.start(mood);
    if (!timer.running && !timer.endsAt && ambient.playing && timer.remaining === timer.duration) {
      /* only stop on a full reset, keep music through pauses */
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [timer.running, syncMusic]);

  useEffect(() => {
    ambient.setVolume(volume);
  }, [volume]);

  const toggleMusic = () => {
    if (ambient.playing) ambient.stop();
    else ambient.start(mood);
  };

  const pickMood = (m: MoodId) => {
    setMood(m);
    if (ambient.playing) ambient.start(m);
  };

  return (
    <div>
      <SectionHead
        kicker="Focus Greenhouse"
        title="Grow the garden, one session at a time"
        desc="Run a focus session and a new plant takes root in your 3D garden. The glowing seed in the centre grows in real time as your timer runs — pause, and it waits for you."
        icon="sprout"
      />

      <div className="grid lg:grid-cols-[1fr_390px] gap-5 items-start">
        {/* ---------- 3D garden ---------- */}
        <div className="relative h-[440px] sm:h-[520px] lg:h-[620px] rounded-xl overflow-hidden border border-pine-600/40 bg-pine-900 shadow-lift">
          <GardenScene plants={state.plants} seedProgress={seedProgress} />

          <div className="absolute top-3 left-3 flex items-center gap-2 pointer-events-none">
            <div className="panel rounded-lg px-3 py-2 bg-pine-900/80 backdrop-blur flex items-center gap-2">
              <Icon name="leaf" size={15} className="text-leaf-400" />
              <div>
                <div className="text-[10px] uppercase tracking-widest text-mist-500 font-semibold leading-none">Garden tier</div>
                <div className="font-display font-bold text-sm text-mist-100 leading-tight">{tier.name}</div>
              </div>
            </div>
            <div className="panel rounded-lg px-3 py-2 bg-pine-900/80 backdrop-blur">
              <span className="font-display font-bold text-sm text-leaf-300">{state.plants.length}</span>
              <span className="text-[11px] text-mist-400 ml-1">plants</span>
            </div>
          </div>

          {focusRunning && (
            <div className="absolute top-3 right-3 panel rounded-lg px-3 py-2 bg-pine-900/80 backdrop-blur flex items-center gap-2 pointer-events-none">
              <span className="w-2 h-2 rounded-full bg-leaf-400 pulse-dot" />
              <span className="text-xs font-semibold text-leaf-300">Growing… {Math.round((seedProgress ?? 0) * 100)}%</span>
            </div>
          )}
          {isBreak && timer.running && (
            <div className="absolute top-3 right-3 panel rounded-lg px-3 py-2 bg-pine-900/80 backdrop-blur flex items-center gap-2 pointer-events-none">
              <span className="w-2 h-2 rounded-full bg-aqua-400 pulse-dot" />
              <span className="text-xs font-semibold text-aqua-300">Resting in the shade</span>
            </div>
          )}

          <div className="absolute bottom-3 right-3 flex items-center gap-1.5 text-[11px] text-mist-500 bg-pine-900/70 backdrop-blur rounded-md px-2.5 py-1.5 pointer-events-none">
            <Icon name="orbit" size={13} />
            drag to orbit · scroll to zoom
          </div>

          {state.plants.length === 0 && (
            <div className="absolute bottom-3 left-3 panel rounded-lg px-3 py-2 bg-pine-900/85 backdrop-blur max-w-[260px] pointer-events-none">
              <div className="text-xs text-mist-300 leading-relaxed">
                <span className="text-leaf-300 font-semibold">Bare soil for now.</span> Finish your first focus session and the
                first plant sprouts here.
              </div>
            </div>
          )}
        </div>

        {/* ---------- right column ---------- */}
        <div className="flex flex-col gap-4">
          {/* timer card */}
          <div className="panel p-5">
            <div className="grid grid-cols-3 gap-1.5 p-1 rounded-lg bg-pine-900/80 border border-pine-700/60">
              {(["focus", "short", "long"] as TimerMode[]).map((m) => (
                <button
                  key={m}
                  onClick={() => setMode(m)}
                  disabled={timer.running}
                  className={`chip-btn rounded-md px-2 py-2 text-xs font-semibold transition-colors ${
                    timer.mode === m
                      ? m === "focus"
                        ? "bg-leaf-600/25 text-leaf-300 border border-leaf-500/40"
                        : "bg-aqua-500/20 text-aqua-300 border border-aqua-500/40"
                      : "text-mist-400 border border-transparent hover:text-mist-200 disabled:opacity-40"
                  }`}
                >
                  {MODE_LABEL[m]}
                </button>
              ))}
            </div>

            <div className="flex justify-center mt-5">
              <Ring
                pct={pct}
                size={224}
                stroke={9}
                color={isBreak ? "#8ad4cb" : "#98dd66"}
              >
                <div className="font-mono font-semibold text-[44px] leading-none text-mist-100 tabular-nums">{fmt(timer.remaining)}</div>
                <div className={`text-[11px] uppercase tracking-[0.2em] font-semibold mt-2 ${isBreak ? "text-aqua-400" : "text-leaf-400"}`}>
                  {MODE_LABEL[timer.mode]}
                </div>
                {timer.mode === "focus" && (
                  <div className="text-[11px] text-mist-500 mt-1">
                    worth <span className="text-gold-400 font-semibold">{Math.max(1, Math.round(timer.duration / 60)) * 2} XP</span>
                  </div>
                )}
              </Ring>
            </div>

            {/* cycle dots */}
            <div className="flex items-center justify-center gap-2 mt-4">
              {[0, 1, 2, 3].map((i) => (
                <span
                  key={i}
                  className={`w-2 h-2 rounded-full transition-colors duration-300 ${
                    i < timer.cycles % 4 || (timer.cycles > 0 && timer.cycles % 4 === 0 && i < 4)
                      ? "bg-gold-400"
                      : "bg-pine-600"
                  }`}
                  title={`Session ${i + 1} of 4 before a long break`}
                />
              ))}
              <span className="text-[11px] text-mist-500 ml-1">long break every 4th</span>
            </div>

            <div className="flex items-center gap-2.5 mt-5">
              <button
                onClick={timer.running ? pauseTimer : startTimer}
                className={`chip-btn flex-1 flex items-center justify-center gap-2 rounded-lg px-4 py-3 font-display font-bold text-[15px] transition-all ${
                  timer.running
                    ? "bg-pine-700 border border-pine-600 text-mist-100 hover:bg-pine-600"
                    : isBreak
                    ? "bg-aqua-500/20 border border-aqua-500/50 text-aqua-300 hover:bg-aqua-500/30 shadow-glow"
                    : "bg-leaf-600/25 border border-leaf-500/60 text-leaf-200 hover:bg-leaf-600/40 shadow-glow"
                }`}
              >
                <Icon name={timer.running ? "pause" : "play"} size={17} strokeWidth={2.2} />
                {timer.running ? "Pause" : timer.remaining < timer.duration ? "Resume" : "Start"}
              </button>
              <button
                onClick={resetTimer}
                className="chip-btn rounded-lg p-3 border border-pine-600 bg-pine-800 text-mist-300 hover:text-mist-100 hover:border-pine-500"
                title="Reset"
              >
                <Icon name="reset" size={17} />
              </button>
              <button
                onClick={skipPhase}
                className="chip-btn rounded-lg p-3 border border-pine-600 bg-pine-800 text-mist-300 hover:text-mist-100 hover:border-pine-500"
                title="Skip phase (no XP for skipped focus)"
              >
                <Icon name="skip" size={17} />
              </button>
            </div>

            {/* presets */}
            <div className="flex items-center gap-1.5 mt-4 flex-wrap">
              <span className="text-[11px] text-mist-500 mr-1 uppercase tracking-wider font-semibold">Focus length</span>
              {PRESETS.map((p) => (
                <button
                  key={p}
                  onClick={() => {
                    setMode("focus");
                    setDurationMin(p);
                  }}
                  disabled={timer.running}
                  className={`chip-btn rounded-md px-2.5 py-1 text-xs font-semibold border ${
                    timer.mode === "focus" && timer.duration === p * 60
                      ? "border-leaf-500/60 text-leaf-300 bg-leaf-600/20"
                      : "border-pine-600 text-mist-400 hover:text-mist-200 hover:border-pine-500 disabled:opacity-40"
                  }`}
                >
                  {p}m
                </button>
              ))}
              <div className="flex items-center gap-1 ml-auto">
                <button
                  onClick={() => setDurationMin(Math.max(5, Math.round(timer.duration / 60) - 5))}
                  disabled={timer.running || timer.mode !== "focus"}
                  className="chip-btn w-6 h-6 rounded-md border border-pine-600 text-mist-400 hover:text-mist-100 text-sm disabled:opacity-40"
                >
                  −
                </button>
                <span className="font-mono text-xs text-mist-300 w-9 text-center tabular-nums">
                  {Math.round(timer.duration / 60)}m
                </span>
                <button
                  onClick={() => setDurationMin(Math.min(120, Math.round(timer.duration / 60) + 5))}
                  disabled={timer.running || timer.mode !== "focus"}
                  className="chip-btn w-6 h-6 rounded-md border border-pine-600 text-mist-400 hover:text-mist-100 text-sm disabled:opacity-40"
                >
                  +
                </button>
              </div>
            </div>
          </div>

          {/* ambience card */}
          <div className="panel p-5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Icon name="music" size={16} className="text-gold-400" />
                <span className="font-display font-bold text-sm text-mist-100">Ambient sound</span>
              </div>
              <label className="flex items-center gap-2 cursor-pointer select-none">
                <span className="text-[11px] text-mist-500">sync with timer</span>
                <button
                  onClick={() => setSyncMusic((v) => !v)}
                  className={`w-9 h-5 rounded-full transition-colors relative ${syncMusic ? "bg-leaf-600" : "bg-pine-600"}`}
                  aria-label="Toggle sync"
                >
                  <span
                    className={`absolute top-0.5 w-4 h-4 rounded-full bg-mist-100 transition-all ${syncMusic ? "left-[18px]" : "left-0.5"}`}
                  />
                </button>
              </label>
            </div>

            <div className="grid gap-2 mt-3">
              {MOODS.map((m) => (
                <button
                  key={m.id}
                  onClick={() => pickMood(m.id)}
                  className={`chip-btn text-left rounded-lg px-3.5 py-2.5 border flex items-center gap-3 ${
                    mood === m.id
                      ? "border-leaf-500/60 bg-leaf-600/15"
                      : "border-pine-600/70 bg-pine-900/50 hover:border-pine-500"
                  }`}
                >
                  <div className={`flex items-end gap-[3px] h-4 w-5 ${mood === m.id && ambient.playing ? "" : "opacity-30"}`}>
                    {ambient.playing && mood === m.id ? (
                      <>
                        <span className="eq-bar w-[3px] rounded bg-leaf-400" />
                        <span className="eq-bar w-[3px] rounded bg-leaf-400" />
                        <span className="eq-bar w-[3px] rounded bg-leaf-400" />
                      </>
                    ) : (
                      <>
                        <span className="w-[3px] h-2 rounded bg-mist-500" />
                        <span className="w-[3px] h-3.5 rounded bg-mist-500" />
                        <span className="w-[3px] h-2.5 rounded bg-mist-500" />
                      </>
                    )}
                  </div>
                  <div className="min-w-0">
                    <div className={`text-sm font-semibold ${mood === m.id ? "text-leaf-300" : "text-mist-200"}`}>{m.name}</div>
                    <div className="text-[11px] text-mist-500 truncate">{m.desc}</div>
                  </div>
                  <span className="ml-auto text-[10px] uppercase tracking-wider font-bold text-mist-600 border border-pine-600 rounded px-1.5 py-0.5">
                    {m.tag}
                  </span>
                </button>
              ))}
            </div>

            <div className="flex items-center gap-3 mt-4">
              <button
                onClick={toggleMusic}
                className={`chip-btn flex items-center gap-2 rounded-lg px-3.5 py-2 text-sm font-semibold border ${
                  ambient.playing
                    ? "border-gold-500/60 bg-gold-500/15 text-gold-300"
                    : "border-pine-600 bg-pine-800 text-mist-300 hover:text-mist-100"
                }`}
              >
                <Icon name={ambient.playing ? "pause" : "play"} size={14} strokeWidth={2.2} />
                {ambient.playing ? "Stop" : "Play"}
              </button>
              <Icon name="volume" size={16} className="text-mist-500 shrink-0" />
              <input
                type="range"
                min={0}
                max={1}
                step={0.02}
                value={volume}
                onChange={(e) => setVolume(parseFloat(e.target.value))}
                className="flex-1"
                style={{ ["--fill" as string]: `${volume * 100}%` }}
                aria-label="Volume"
              />
            </div>
            <p className="text-[11px] text-mist-600 mt-2.5 leading-relaxed">
              Sound is synthesized live in your browser — rain, birdsong, vinyl crackle. No files, no ads.
            </p>
          </div>

          <DistractionShield />

          {/* stats */}
          <div className="grid grid-cols-2 gap-3">
            <Stat label="Today" value={<><CountUp value={state.todayMin} /> min</>} icon="timer" tone="text-leaf-400" />
            <Stat
              label="All-time focus"
              value={`${Math.floor(state.totalMin / 60)}h ${state.totalMin % 60}m`}
              icon="chart"
              tone="text-aqua-400"
            />
            <Stat label="Sessions" value={<CountUp value={state.sessions} />} icon="check" tone="text-gold-400" />
            <Stat label="Plants grown" value={<CountUp value={state.plants.length} />} icon="sprout" tone="text-lav-400" />
          </div>
        </div>
      </div>
    </div>
  );
}
