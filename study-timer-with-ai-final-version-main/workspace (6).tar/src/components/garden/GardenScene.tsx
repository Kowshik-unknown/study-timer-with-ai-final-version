import React, { useMemo, useRef } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { OrbitControls, Sparkles } from "@react-three/drei";
import * as THREE from "three";
import type { PlantRec } from "../../state/store";

const PETALS = ["#f4c566", "#f2907e", "#c0b1ec", "#8ad4cb", "#f7b0a2", "#b5e88a"];
const GREENS = ["#3f7d46", "#4c9a54", "#5aa53b", "#6fbf62"];

function hash(s: string): number {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0;
  return Math.abs(h);
}

const pick = <T,>(arr: T[], seed: number) => arr[seed % arr.length];

/* ---------------- individual plants ---------------- */

function PlantMesh({ rec }: { rec: PlantRec }) {
  const ref = useRef<THREE.Group>(null);
  const cur = useRef(0.04);
  const h = hash(rec.id);
  const petal = pick(PETALS, h);
  const green = pick(GREENS, h >> 2);
  const phase = (h % 100) / 16;

  useFrame((state, dt) => {
    const g = ref.current;
    if (!g) return;
    cur.current = THREE.MathUtils.damp(cur.current, rec.s, 2.0, dt);
    g.scale.setScalar(cur.current);
    g.rotation.z = Math.sin(state.clock.elapsedTime * 0.8 + phase) * 0.03;
  });

  return (
    <group position={[rec.x, 0, rec.z]}>
      {/* soft ground shadow */}
      <mesh rotation-x={-Math.PI / 2} position={[0, 0.01, 0]}>
        <circleGeometry args={[0.55, 24]} />
        <meshBasicMaterial color="#0a1710" transparent opacity={0.4} />
      </mesh>
      <group ref={ref}>
        {rec.type === "sprout" && (
          <>
            <mesh position={[0, 0.28, 0]}>
              <cylinderGeometry args={[0.035, 0.055, 0.56, 8]} />
              <meshStandardMaterial color={green} roughness={0.8} />
            </mesh>
            <mesh position={[-0.16, 0.5, 0]} rotation={[0, 0, 0.7]} scale={[1, 0.42, 0.6]}>
              <sphereGeometry args={[0.2, 12, 10]} />
              <meshStandardMaterial color={green} roughness={0.7} />
            </mesh>
            <mesh position={[0.16, 0.62, 0]} rotation={[0, 0, -0.7]} scale={[1, 0.42, 0.6]}>
              <sphereGeometry args={[0.17, 12, 10]} />
              <meshStandardMaterial color="#5aa53b" roughness={0.7} />
            </mesh>
          </>
        )}
        {rec.type === "flower" && (
          <>
            <mesh position={[0, 0.45, 0]}>
              <cylinderGeometry args={[0.03, 0.045, 0.9, 8]} />
              <meshStandardMaterial color={green} roughness={0.8} />
            </mesh>
            <mesh position={[-0.14, 0.42, 0.02]} rotation={[0, 0, 0.9]} scale={[1, 0.35, 0.5]}>
              <sphereGeometry args={[0.14, 10, 8]} />
              <meshStandardMaterial color={green} roughness={0.75} />
            </mesh>
            {Array.from({ length: 6 }).map((_, i) => {
              const a = (i / 6) * Math.PI * 2;
              return (
                <mesh key={i} position={[Math.cos(a) * 0.19, 0.95, Math.sin(a) * 0.19]} scale={[1, 0.72, 1]}>
                  <sphereGeometry args={[0.115, 10, 8]} />
                  <meshStandardMaterial color={petal} roughness={0.55} />
                </mesh>
              );
            })}
            <mesh position={[0, 0.95, 0]}>
              <sphereGeometry args={[0.115, 12, 10]} />
              <meshStandardMaterial color="#f4c566" roughness={0.4} emissive="#8a6215" emissiveIntensity={0.35} />
            </mesh>
          </>
        )}
        {rec.type === "tree" && (
          <>
            <mesh position={[0, 0.55, 0]}>
              <cylinderGeometry args={[0.09, 0.15, 1.1, 10]} />
              <meshStandardMaterial color="#6b4a2f" roughness={0.95} />
            </mesh>
            <mesh position={[0, 1.35, 0]}>
              <coneGeometry args={[0.85, 1.1, 10]} />
              <meshStandardMaterial color={green} roughness={0.85} />
            </mesh>
            <mesh position={[0, 2.05, 0]}>
              <coneGeometry args={[0.62, 0.95, 10]} />
              <meshStandardMaterial color="#4c9a54" roughness={0.85} />
            </mesh>
            <mesh position={[0, 2.65, 0]}>
              <coneGeometry args={[0.4, 0.8, 10]} />
              <meshStandardMaterial color="#6fbf62" roughness={0.85} />
            </mesh>
          </>
        )}
        {rec.type === "mushroom" && (
          <>
            <mesh position={[0, 0.26, 0]}>
              <cylinderGeometry args={[0.08, 0.12, 0.52, 10]} />
              <meshStandardMaterial color="#e8dcc3" roughness={0.8} />
            </mesh>
            <mesh position={[0, 0.58, 0]} scale={[1, 0.62, 1]}>
              <sphereGeometry args={[0.34, 16, 12]} />
              <meshStandardMaterial color={petal} roughness={0.5} />
            </mesh>
            <mesh position={[0.3, 0.16, 0.18]}>
              <cylinderGeometry args={[0.045, 0.06, 0.3, 8]} />
              <meshStandardMaterial color="#e8dcc3" roughness={0.8} />
            </mesh>
            <mesh position={[0.3, 0.35, 0.18]} scale={[1, 0.62, 1]}>
              <sphereGeometry args={[0.16, 12, 10]} />
              <meshStandardMaterial color={petal} roughness={0.5} />
            </mesh>
          </>
        )}
        {rec.type === "fern" && (
          <>
            {Array.from({ length: 6 }).map((_, i) => {
              const a = (i / 6) * Math.PI * 2 + 0.3;
              return (
                <mesh
                  key={i}
                  position={[Math.cos(a) * 0.1, 0.42, Math.sin(a) * 0.1]}
                  rotation={[Math.sin(a) * 0.55, 0, -Math.cos(a) * 0.55]}
                >
                  <coneGeometry args={[0.055, 0.95, 6]} />
                  <meshStandardMaterial color={i % 2 ? green : "#5aa53b"} roughness={0.8} />
                </mesh>
              );
            })}
          </>
        )}
      </group>
    </group>
  );
}

/* ---------------- live seed in the centre ---------------- */

function Seed({ progress }: { progress: number | null }) {
  const bud = useRef<THREE.Mesh>(null);
  const ring = useRef<THREE.Mesh>(null);
  const stem = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    const t = state.clock.elapsedTime;
    const p = progress ?? 0;
    if (bud.current) {
      const base = progress === null ? 0.16 : 0.2 + p * 0.42;
      const pulse = 1 + Math.sin(t * 2.2) * (progress === null ? 0.06 : 0.04);
      bud.current.scale.setScalar(base * pulse);
      bud.current.position.y = 0.55 + p * 1.15;
    }
    if (stem.current) {
      stem.current.scale.y = Math.max(0.02, 0.55 + p * 1.15);
      stem.current.position.y = (0.55 + p * 1.15) / 2;
    }
    if (ring.current) {
      const k = (t % 2) / 2;
      ring.current.scale.setScalar(0.6 + k * 1.6);
      (ring.current.material as THREE.MeshBasicMaterial).opacity = (1 - k) * (progress === null ? 0.15 : 0.4);
    }
  });

  return (
    <group>
      <mesh rotation-x={-Math.PI / 2} position={[0, 0.012, 0]} ref={ring}>
        <ringGeometry args={[0.5, 0.56, 40]} />
        <meshBasicMaterial color="#98dd66" transparent opacity={0.3} side={THREE.DoubleSide} />
      </mesh>
      <mesh position={[0, 0.06, 0]} scale={[1, 0.3, 1]}>
        <sphereGeometry args={[0.42, 16, 12]} />
        <meshStandardMaterial color="#2a1f14" roughness={1} />
      </mesh>
      <mesh ref={stem} position={[0, 0.28, 0]}>
        <cylinderGeometry args={[0.045, 0.07, 1, 8]} />
        <meshStandardMaterial color="#5aa53b" roughness={0.7} emissive="#1d4d1c" emissiveIntensity={0.5} />
      </mesh>
      <mesh ref={bud} position={[0, 0.55, 0]}>
        <icosahedronGeometry args={[1, 1]} />
        <meshStandardMaterial
          color={progress === null ? "#3c6146" : "#b5e88a"}
          emissive={progress === null ? "#16301f" : "#5aa53b"}
          emissiveIntensity={progress === null ? 0.4 : 0.9}
          roughness={0.35}
        />
      </mesh>
      <pointLight position={[0, 1.6, 0]} color="#98dd66" intensity={progress === null ? 0.4 : 1.4} distance={7} />
    </group>
  );
}

/* ---------------- ground & rocks ---------------- */

function Ground() {
  const rocks = useMemo(
    () =>
      Array.from({ length: 14 }).map((_, i) => {
        const a = (i / 14) * Math.PI * 2 + 0.35;
        const r = 10.6 + ((i * 37) % 10) / 6;
        return {
          pos: [Math.cos(a) * r, 0.1, Math.sin(a) * r] as [number, number, number],
          s: 0.1 + ((i * 13) % 7) / 40,
          rot: (i * 0.9) % 3,
        };
      }),
    []
  );
  const patches = useMemo(
    () =>
      Array.from({ length: 7 }).map((_, i) => {
        const a = (i / 7) * Math.PI * 2 + 1.1;
        const r = 3 + ((i * 53) % 10) / 2.2;
        return { pos: [Math.cos(a) * r, 0.005, Math.sin(a) * r] as [number, number, number], s: 1.2 + ((i * 29) % 10) / 7 };
      }),
    []
  );
  return (
    <group>
      <mesh rotation-x={-Math.PI / 2}>
        <circleGeometry args={[13, 72]} />
        <meshStandardMaterial color="#17301e" roughness={1} />
      </mesh>
      {patches.map((p, i) => (
        <mesh key={i} rotation-x={-Math.PI / 2} position={p.pos}>
          <circleGeometry args={[p.s, 28]} />
          <meshStandardMaterial color="#112517" roughness={1} />
        </mesh>
      ))}
      <mesh rotation-x={-Math.PI / 2} position={[0, 0.008, 0]}>
        <ringGeometry args={[12.7, 13, 72]} />
        <meshBasicMaterial color="#0c1811" transparent opacity={0.9} />
      </mesh>
      {rocks.map((r, i) => (
        <mesh key={i} position={r.pos} rotation={[0, r.rot, 0]} scale={r.s}>
          <dodecahedronGeometry args={[1, 0]} />
          <meshStandardMaterial color="#2e4636" roughness={0.95} />
        </mesh>
      ))}
    </group>
  );
}

/* ---------------- scene root ---------------- */

export default function GardenScene({
  plants,
  seedProgress,
}: {
  plants: PlantRec[];
  seedProgress: number | null;
}) {
  return (
    <Canvas
      dpr={[1, 1.8]}
      camera={{ position: [8.5, 6.2, 10.5], fov: 40 }}
      onCreated={({ gl }) => gl.setClearColor("#0c1811")}
    >
      <fog attach="fog" args={["#0c1811", 17, 36]} />
      <hemisphereLight args={["#cfe8c9", "#0e1f14", 0.85]} />
      <directionalLight position={[6, 11, 4]} intensity={1.25} color="#fff1d0" />
      <directionalLight position={[-8, 5, -6]} intensity={0.25} color="#8ad4cb" />
      <Ground />
      {plants.map((p) => (
        <PlantMesh key={p.id} rec={p} />
      ))}
      <Seed progress={seedProgress} />
      <Sparkles count={120} scale={[21, 7, 21]} size={2.1} speed={0.24} opacity={0.5} color="#f4c566" position={[0, 3, 0]} />
      <OrbitControls
        enablePan={false}
        autoRotate
        autoRotateSpeed={0.45}
        minDistance={7}
        maxDistance={22}
        maxPolarAngle={Math.PI / 2.12}
        target={[0, 0.6, 0]}
      />
    </Canvas>
  );
}
