/* Compact knowledge bank for the doubt solver. */

export interface KnowledgeEntry {
  id: string;
  keys: string[];
  title: string;
  body: string;
  steps?: string[];
  related: string[];
}

export const KNOWLEDGE: KnowledgeEntry[] = [
  {
    id: "photosynthesis",
    keys: ["photosynthesis", "chlorophyll", "calvin", "light reaction", "stomata"],
    title: "Photosynthesis",
    body: "Photosynthesis is how plants turn light energy into chemical energy stored as glucose. Chlorophyll in the chloroplasts captures light, water is split (releasing oxygen), and CO₂ is fixed into sugar in the Calvin cycle. The overall equation is: 6CO₂ + 6H₂O + light → C₆H₁₂O₆ + 6O₂.",
    steps: [
      "Light-dependent reactions (thylakoid membranes): H₂O is split, O₂ released, ATP + NADPH made.",
      "Light-independent reactions (stroma): the Calvin cycle fixes CO₂ using ATP and NADPH.",
      "Rate depends on light intensity, CO₂ concentration and temperature (limiting factors).",
    ],
    related: ["cellular respiration", "chloroplast structure", "limiting factors"],
  },
  {
    id: "newton",
    keys: ["newton", "laws of motion", "inertia", "force", "friction"],
    title: "Newton's Laws of Motion",
    body: "Newton's three laws describe how forces change motion. (1) An object stays at rest or in uniform motion unless a net force acts — inertia. (2) Force equals mass times acceleration: F = ma. (3) Every action has an equal and opposite reaction.",
    steps: [
      "Law 1: no net force → no change in velocity.",
      "Law 2: F = ma; rearrange to a = F/m or m = F/a depending on the unknown.",
      "Law 3: forces always come in pairs acting on different objects.",
    ],
    related: ["free-body diagrams", "friction", "momentum"],
  },
  {
    id: "pythagoras",
    keys: ["pythagoras", "pythagorean", "hypotenuse", "right triangle", "right-angled"],
    title: "Pythagorean Theorem",
    body: "In any right-angled triangle, the square of the hypotenuse equals the sum of the squares of the other two sides: a² + b² = c², where c is the longest side opposite the right angle.",
    steps: [
      "Identify the hypotenuse (longest side, opposite the right angle) — that is c.",
      "Square the two known sides and add them.",
      "Take the square root of the sum to find c. If finding a shorter side, subtract instead: a² = c² − b².",
    ],
    related: ["trigonometry", "distance formula", "special triangles"],
  },
  {
    id: "mitosis",
    keys: ["mitosis", "meiosis", "cell division", "chromosome", "cytokinesis"],
    title: "Mitosis vs Meiosis",
    body: "Mitosis makes two genetically identical diploid daughter cells for growth and repair. Meiosis makes four genetically unique haploid gametes for reproduction. Mitosis has one division; meiosis has two, with crossing-over in prophase I creating variation.",
    steps: [
      "Mitosis stages: prophase → metaphase → anaphase → telophase, then cytokinesis.",
      "Meiosis I separates homologous chromosome pairs; meiosis II separates sister chromatids.",
      "Result: mitosis → 2 diploid clones; meiosis → 4 haploid, genetically different cells.",
    ],
    related: ["cell cycle", "crossing over", "chromosome number"],
  },
  {
    id: "supply-demand",
    keys: ["supply", "demand", "equilibrium", "price", "elasticity", "economics"],
    title: "Supply & Demand",
    body: "Demand is how much buyers want at each price (usually falling as price rises); supply is how much sellers offer (usually rising with price). The equilibrium price is where the curves cross — no shortage, no surplus.",
    steps: [
      "Price above equilibrium → surplus → sellers cut prices.",
      "Price below equilibrium → shortage → buyers bid prices up.",
      "Shifts: income, tastes and substitutes move demand; costs and technology move supply.",
    ],
    related: ["elasticity", "market failure", "opportunity cost"],
  },
  {
    id: "ohm",
    keys: ["ohm", "voltage", "current", "resistance", "circuit"],
    title: "Ohm's Law",
    body: "Ohm's Law links the three basic circuit quantities: V = I × R. Voltage (volts) equals current (amps) times resistance (ohms). It holds for ohmic conductors at constant temperature.",
    steps: [
      "To find current: I = V / R.",
      "To find resistance: R = V / I.",
      "Series resistors add (R = R₁ + R₂); parallel: 1/R = 1/R₁ + 1/R₂.",
    ],
    related: ["power (P = VI)", "series & parallel circuits", "kirchhoff's laws"],
  },
  {
    id: "osmosis",
    keys: ["osmosis", "diffusion", "concentration gradient", "semipermeable", "tonicity"],
    title: "Osmosis & Diffusion",
    body: "Diffusion is the net movement of particles from high to low concentration. Osmosis is specifically the diffusion of water across a semipermeable membrane, from dilute (high water potential) to concentrated (low water potential) solution.",
    steps: [
      "Both are passive — no ATP needed; both move down a gradient.",
      "Isotonic: no net water movement. Hypertonic outside: cell shrinks. Hypotonic outside: cell swells.",
      "Factors speeding diffusion: steeper gradient, higher temperature, larger surface area.",
    ],
    related: ["active transport", "water potential", "cell membranes"],
  },
  {
    id: "dna",
    keys: ["dna", "replication", "nucleotide", "double helix", "rna", "genome"],
    title: "DNA Structure & Replication",
    body: "DNA is a double helix of two antiparallel strands held together by base pairs: A–T and G–C. Each nucleotide has a sugar, a phosphate and a base. Replication is semi-conservative — each new DNA molecule keeps one old strand.",
    steps: [
      "Helicase unzips the double helix, breaking hydrogen bonds.",
      "DNA polymerase builds new strands by matching complementary bases (A↔T, G↔C).",
      "Each daughter molecule contains one original and one new strand.",
    ],
    related: ["protein synthesis", "mutation", "chargaff's rules"],
  },
  {
    id: "derivative",
    keys: ["derivative", "differentiation", "slope", "rate of change", "calculus"],
    title: "Derivatives",
    body: "The derivative f′(x) measures the instantaneous rate of change of f — geometrically, the slope of the tangent line. Power rule: d/dx [xⁿ] = n·xⁿ⁻¹. Derivatives locate maxima, minima and rates in physics.",
    steps: [
      "Apply the power rule term by term: d/dx[3x²] = 6x.",
      "Set f′(x) = 0 to find critical points (possible maxima/minima).",
      "Check the second derivative: f″ > 0 → minimum, f″ < 0 → maximum.",
    ],
    related: ["chain rule", "integration", "limits"],
  },
  {
    id: "inflation",
    keys: ["inflation", "cpi", "purchasing power", "monetary policy", "deflation"],
    title: "Inflation",
    body: "Inflation is a sustained rise in the general price level, which erodes purchasing power — the same money buys less over time. It is commonly measured by the CPI (consumer price index). Central banks usually target around 2% per year.",
    steps: [
      "Demand-pull: too much money chasing too few goods.",
      "Cost-push: rising production costs (wages, energy) lift prices.",
      "Real value: real ≈ nominal − inflation. At 5% inflation, money halves in buying power in ≈14 years.",
    ],
    related: ["interest rates", "cpi", "quantity theory of money"],
  },
  {
    id: "fractions",
    keys: ["fraction", "denominator", "numerator", "lcd", "common denominator"],
    title: "Fractions",
    body: "A fraction a/b represents a parts out of b equal parts. To add or subtract, first rewrite with a common denominator, then combine numerators. To multiply, multiply straight across; to divide, multiply by the reciprocal.",
    steps: [
      "Add/subtract: find the LCD, convert both fractions, add numerators only.",
      "Multiply: (a/b) × (c/d) = ac/bd. Simplify at the end.",
      "Divide: (a/b) ÷ (c/d) = (a/b) × (d/c) — “keep, change, flip”.",
    ],
    related: ["decimals & percentages", "ratios", "simplifying"],
  },
  {
    id: "blackhole",
    keys: ["black hole", "event horizon", "singularity", "schwarzschild", "gravity well"],
    title: "Black Holes",
    body: "A black hole is a region where mass is compressed so densely that the escape velocity exceeds the speed of light. The boundary is the event horizon; inside, all paths lead to the singularity. They form when massive stars collapse at the end of their lives.",
    steps: [
      "Event horizon radius (Schwarzschild): r = 2GM/c².",
      "Time appears to slow near the horizon for a distant observer.",
      "Hawking radiation predicts very slow evaporation over immense timescales.",
    ],
    related: ["general relativity", "neutron stars", "escape velocity"],
  },
  {
    id: "hamlet",
    keys: ["hamlet", "shakespeare", "revenge tragedy", "soliloquy"],
    title: "Themes in Hamlet",
    body: "Hamlet is a revenge tragedy built around delay, doubt and performance. Key themes: revenge vs. morality, madness (real and feigned), corruption (“something is rotten in the state of Denmark”), death and the afterlife, and the gap between action and thought.",
    steps: [
      "The ghost's command sets the revenge plot; Hamlet's hesitation drives the tragedy.",
      "The play-within-a-play (“The Mousetrap”) tests Claudius's guilt.",
      "Soliloquies like “To be or not to be” expose his internal paralysis.",
    ],
    related: ["tragic hero", "dramatic irony", "elizabethan revenge tragedy"],
  },
  {
    id: "organelles",
    keys: ["organelle", "mitochondria", "ribosome", "nucleus", "golgi", "endoplasmic"],
    title: "Cell Organelles",
    body: "Organelles are specialised compartments in a cell. The nucleus stores DNA; mitochondria run aerobic respiration (the “powerhouse”); ribosomes build proteins; the endoplasmic reticulum processes them; the Golgi packages and ships them; lysosomes digest waste.",
    steps: [
      "Need energy talk? → mitochondria (aerobic respiration, ATP).",
      "Need protein talk? → ribosomes (synthesis), rough ER (folding), Golgi (packaging).",
      "Plant-only: chloroplasts, cell wall, large central vacuole.",
    ],
    related: ["prokaryote vs eukaryote", "membrane transport", "enzymes"],
  },
  {
    id: "gravity",
    keys: ["gravity", "gravitational", "weight", "g-force", "free fall"],
    title: "Gravity & Weight",
    body: "Gravity is the attractive force between masses. Near Earth's surface it accelerates falling objects at g ≈ 9.81 m/s². Weight is the force of gravity on a mass: W = m·g — mass stays constant, weight changes with location.",
    steps: [
      "Newton's law of gravitation: F = G·m₁m₂/r².",
      "Weight: W = mg (in newtons). Mass is in kg and never changes.",
      "In free fall, air resistance is ignored, so all objects accelerate equally.",
    ],
    related: ["newton's laws", "orbital motion", "potential energy"],
  },
  {
    id: "tenses",
    keys: ["tense", "past tense", "present perfect", "grammar", "verb"],
    title: "English Tenses (quick map)",
    body: "Tenses place actions in time. Simple forms state facts (I study); continuous forms show ongoing action (I am studying); perfect forms connect to another time (I have studied); perfect-continuous adds duration (I have been studying for an hour).",
    steps: [
      "Present perfect (have/has + V3): past action relevant now — “I have finished.”",
      "Past simple: finished, timed action — “I finished yesterday.”",
      "Future with ‘will’ for decisions made now; ‘going to’ for plans already made.",
    ],
    related: ["conditionals", "passive voice", "reported speech"],
  },
];

export function searchKnowledge(query: string): KnowledgeEntry | null {
  const q = query.toLowerCase();
  let best: KnowledgeEntry | null = null;
  let bestScore = 0;
  for (const e of KNOWLEDGE) {
    let score = 0;
    for (const k of e.keys) {
      if (q.includes(k)) score += k.length > 6 ? 2 : 1.4;
    }
    if (score > bestScore) {
      bestScore = score;
      best = e;
    }
  }
  return bestScore >= 1 ? best : null;
}

export const SUGGESTED_DOUBTS = [
  "Solve 2x + 5 = 17",
  "Solve x^2 - 5x + 6 = 0",
  "What is 35% of 240?",
  "(128 + 56) / 8 * 3",
  "Explain photosynthesis",
  "State Newton's laws of motion",
  "What is the Pythagorean theorem?",
  "Mitosis vs meiosis?",
  "Explain Ohm's law",
  "What is a derivative?",
];
