import React, { useMemo, useState, useSyncExternalStore } from "react";
import { StoreProvider, useStore, levelInfo } from "./state/store";
import { Icon, IconName } from "./components/icons";
import { Ring, ToastHost } from "./components/shared";
import TimerView from "./components/garden/TimerView";
import Flashcards from "./components/Flashcards";
import DoubtSolver from "./components/DoubtSolver";
import NotesStudio from "./components/NotesStudio";
import DistractionCalc from "./components/DistractionCalc";
import Settings from "./components/Settings";
import { ambient, MOODS } from "./lib/audioEngine";
import { applyTheme, loadStoredTheme, resolveBases, saveStoredTheme, StoredTheme, ThemeBases } from "./lib/themes";

type ViewId = "garden" | "cards" | "doubt" | "notes" | "audit" | "settings";

const VIEWS: { id: ViewId; label: string; icon: IconName; blurb: string }[] = [
  { id: "garden", label: "Garden & Timer", icon: "sprout", blurb: "3D focus garden" },
  { id: "cards", label: "Flashcards", icon: "cards", blurb: "Auto deck forge" },
  { id: "doubt", label: "Doubt Solver", icon: "spark", blurb: "Step-by-step tutor" },
  { id: "notes", label: "Notes & Quizzes", icon: "notes", blurb: "PDF · video · text" },
  { id: "audit", label: "Distraction Audit", icon: "target", blurb: "Attention cost" },
  { id: "settings", label: "Settings", icon: "gear", blurb: "Themes & behavior" },
];

/* ---------- ambient spores ---------- */

function SporeField() {
  const spores = useMemo(
    () =>
      Array.from({ length: 12 }).map((_, i) => ({
        left: `${(i * 8.3 + 4) % 96}%`,
        size: 2 + ((i * 7) % 4),
        d: 18 + ((i * 5) % 16),
        delay: -((i * 3.7) % 20),
        o: 0.25 + ((i * 13) % 30) / 100,
        x: ((i % 2 ? 1 : -1) * (20 + (i * 11) % 60)) | 0,
        glow: i % 3 === 0 ? "var(--t-glow3)" : i % 3 === 1 ? "var(--t-glow1)" : "var(--t-glow2)",
      })),
    []
  );
  return (
    <div className="fixed inset-0 z-0 pointer-events-none overflow-hidden" aria-hidden>
      {spores.map((s, i) => (
        <span
          key={i}
          className="spore"
          style={{
            left: s.left,
            width: s.size,
            height: s.size,
            background: s.glow,
            boxShadow: `0 0 ${s.size * 3}px color-mix(in srgb, ${s.glow} 35%, transparent)`,
            ["--spore-d" as string]: `${s.d}s`,
            ["--spore-delay" as string]: `${s.delay}s`,
            ["--spore-o" as string]: s.o,
            ["--spore-x" as string]: `${s.x}px`,
          }}
        />
      ))}
      <div className="absolute inset-0 noise-layer opacity-60" />
    </div>
  );
}

/* ---------- now playing pill ---------- */

function NowPlaying() {
  useSyncExternalStore(ambient.subscribe, ambient.getVersion);
  if (!ambient.playing) return null;
  const mood = MOODS.find((m) => m.id === ambient.mood);
  return (
    <div className="fixed bottom-4 right-4 z-[70] rise-in">
      <div className="panel rounded-full pl-4 pr-2 py-2 flex items-center gap-3 bg-pine-900/90 backdrop-blur border-gold-500/40">
        <div className="flex items-end gap-[3px] h-4">
          <span className="eq-bar w-[3px] rounded bg-gold-400" />
          <span className="eq-bar w-[3px] rounded bg-gold-400" />
          <span className="eq-bar w-[3px] rounded bg-gold-400" />
        </div>
        <div className="leading-tight">
          <div className="text-xs font-bold text-mist-100">{mood?.name}</div>
          <div className="text-[10px] text-mist-500">ambient · Grove audio</div>
        </div>
        <button
          onClick={() => ambient.stop()}
          className="chip-btn w-8 h-8 rounded-full bg-pine-700 border border-pine-600 text-mist-300 hover:text-coral-400 flex items-center justify-center"
          aria-label="Stop ambience"
        >
          <Icon name="pause" size={13} strokeWidth={2.4} />
        </button>
      </div>
    </div>
  );
}

/* ---------- sidebar ---------- */

function Sidebar({ view, setView }: { view: ViewId; setView: (v: ViewId) => void }) {
  const { state } = useStore();
  const lvl = levelInfo(state.xp);
  return (
    <aside className="hidden md:flex w-[248px] shrink-0 flex-col border-r border-pine-700/50 bg-pine-900/60 backdrop-blur relative z-10">
      <div className="px-5 pt-6 pb-5">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-leaf-600 to-leaf-700 border border-leaf-500/60 flex items-center justify-center text-pine-950 shadow-glow">
            <Icon name="sprout" size={22} strokeWidth={2.1} className="text-pine-950" />
          </div>
          <div>
            <div className="font-display font-extrabold text-xl tracking-tight text-mist-100 leading-none">Grove</div>
            <div className="text-[10px] uppercase tracking-[0.24em] font-bold text-leaf-400 mt-1">study garden</div>
          </div>
        </div>
      </div>

      <nav className="px-3 flex-1">
        {VIEWS.map((v) => {
          const active = view === v.id;
          return (
            <button
              key={v.id}
              onClick={() => setView(v.id)}
              className={`chip-btn w-full flex items-center gap-3 rounded-lg px-3 py-2.5 mb-1 text-left border transition-colors ${
                active
                  ? "bg-leaf-600/15 border-leaf-500/40 text-leaf-200"
                  : "border-transparent text-mist-400 hover:text-mist-100 hover:bg-pine-800/70"
              }`}
            >
              <span className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 border ${active ? "bg-leaf-600/25 border-leaf-500/50 text-leaf-300" : "bg-pine-800 border-pine-600/60 text-mist-500"}`}>
                <Icon name={v.icon} size={16} />
              </span>
              <span className="min-w-0">
                <span className="block text-sm font-semibold leading-tight">{v.label}</span>
                <span className={`block text-[10px] ${active ? "text-leaf-400/80" : "text-mist-600"}`}>{v.blurb}</span>
              </span>
              {active && <span className="ml-auto w-1.5 h-1.5 rounded-full bg-leaf-400 pulse-dot" />}
            </button>
          );
        })}
      </nav>

      {/* progression card */}
      <div className="p-3.5">
        <div className="panel p-4">
          <div className="flex items-center gap-3">
            <Ring pct={lvl.pct / 100} size={58} stroke={5} color="#f4c566">
              <span className="font-display font-extrabold text-lg text-gold-300">{lvl.level}</span>
            </Ring>
            <div className="min-w-0">
              <div className="text-[10px] uppercase tracking-widest font-bold text-mist-500">Level {lvl.level}</div>
              <div className="font-mono text-sm font-bold text-mist-100 tabular-nums">
                {lvl.into} <span className="text-mist-500 font-normal">/ {lvl.need} XP</span>
              </div>
              <div className="h-1.5 rounded-full bg-pine-700 mt-1.5 overflow-hidden">
                <div className="h-full rounded-full bg-gradient-to-r from-gold-600 to-gold-400 transition-all duration-700" style={{ width: `${lvl.pct}%` }} />
              </div>
            </div>
          </div>
          <div className="flex items-center justify-between mt-3.5 pt-3.5 border-t border-pine-700/60">
            <span className={`flex items-center gap-1.5 text-sm font-bold ${state.streak > 0 ? "text-coral-400" : "text-mist-500"}`}>
              <Icon name="flame" size={16} strokeWidth={2} />
              {state.streak} day{state.streak === 1 ? "" : "s"}
            </span>
            <span className="text-[11px] text-mist-500 flex items-center gap-1">
              <Icon name="star" size={12} /> best {state.bestStreak}
            </span>
          </div>
        </div>
        <p className="text-[10px] text-mist-600 text-center mt-2.5 leading-relaxed">
          Study anything → earn XP → the grove grows
        </p>
      </div>
    </aside>
  );
}

/* ---------- top bar ---------- */

const fmtClock = (sec: number) => `${String(Math.floor(sec / 60)).padStart(2, "0")}:${String(sec % 60).padStart(2, "0")}`;

function TopBar({ view, setView }: { view: ViewId; setView: (v: ViewId) => void }) {
  const { state, timer } = useStore();
  const lvl = levelInfo(state.xp);
  const active = VIEWS.find((v) => v.id === view)!;
  const timerBusy = timer.running || timer.remaining < timer.duration;
  return (
    <header className="sticky top-0 z-40 border-b border-pine-700/50 bg-pine-950/75 backdrop-blur">
      <div className="flex items-center gap-3 px-4 sm:px-6 h-[58px]">
        <div className="md:hidden flex items-center gap-2 shrink-0">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-leaf-600 to-leaf-700 flex items-center justify-center">
            <Icon name="sprout" size={17} className="text-pine-950" strokeWidth={2.2} />
          </div>
          <span className="font-display font-extrabold text-mist-100">Grove</span>
        </div>
        <div className="hidden md:block min-w-0">
          <h1 className="font-display font-bold text-[17px] text-mist-100 leading-tight truncate">{active.label}</h1>
          <p className="text-[11px] text-mist-500 leading-tight">{active.blurb}</p>
        </div>

        <div className="ml-auto flex items-center gap-2 sm:gap-2.5">
          {timerBusy && (
            <button
              onClick={() => setView("garden")}
              className={`chip-btn hidden sm:flex items-center gap-2 rounded-full border px-3 py-1.5 ${
                timer.running ? "border-leaf-500/50 bg-leaf-600/15" : "border-pine-600 bg-pine-800"
              }`}
              title="Jump to timer"
            >
              <span className={`w-1.5 h-1.5 rounded-full ${timer.running ? "bg-leaf-400 pulse-dot" : "bg-gold-400"}`} />
              <span className="font-mono text-xs font-bold text-mist-100 tabular-nums">{fmtClock(timer.remaining)}</span>
              <span className="text-[10px] uppercase tracking-wider font-semibold text-mist-500">
                {timer.running ? (timer.mode === "focus" ? "focusing" : "break") : "paused"}
              </span>
            </button>
          )}

          <div className={`flex items-center gap-1.5 rounded-full border px-3 py-1.5 ${state.streak > 0 ? "border-coral-500/50 bg-coral-500/10" : "border-pine-600 bg-pine-800"}`} title="Daily study streak">
            <Icon name="flame" size={14} strokeWidth={2.1} className={state.streak > 0 ? "text-coral-400" : "text-mist-500"} />
            <span className="font-mono text-xs font-bold text-mist-100 tabular-nums">{state.streak}</span>
          </div>

          <div className="hidden xs:flex sm:flex items-center gap-2 rounded-full border border-gold-500/40 bg-gold-500/10 px-3 py-1.5" title={`${state.xp} XP total`}>
            <Icon name="bolt" size={13} strokeWidth={2.2} className="text-gold-400" />
            <span className="font-mono text-xs font-bold text-gold-200 tabular-nums">{state.xp}</span>
            <span className="text-[10px] font-bold text-gold-500">LV {lvl.level}</span>
          </div>
        </div>
      </div>

      {/* mobile nav */}
      <div className="md:hidden flex gap-1.5 px-3 pb-2.5 overflow-x-auto [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
        {VIEWS.map((v) => (
          <button
            key={v.id}
            onClick={() => setView(v.id)}
            className={`chip-btn shrink-0 flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs font-semibold ${
              view === v.id ? "border-leaf-500/50 bg-leaf-600/15 text-leaf-200" : "border-pine-600 bg-pine-800 text-mist-400"
            }`}
          >
            <Icon name={v.icon} size={13} />
            {v.label}
          </button>
        ))}
      </div>
    </header>
  );
}

/* ---------- shell ---------- */

function Shell() {
  const [view, setView] = useState<ViewId>("garden");
  const [stored, setStored] = useState<StoredTheme>(() => {
    const t = loadStoredTheme();
    applyTheme(resolveBases(t));
    return t;
  });

  const pickPreset = (id: string) => {
    const next = { ...stored, presetId: id };
    applyTheme(resolveBases(next));
    saveStoredTheme(next);
    setStored(next);
  };

  const saveCustom = (bases: ThemeBases, name: string) => {
    const next: StoredTheme = { presetId: "custom", custom: bases, customName: name };
    applyTheme(bases);
    saveStoredTheme(next);
    setStored(next);
  };

  return (
    <div className="h-full flex relative overflow-hidden">
      <SporeField />
      <Sidebar view={view} setView={setView} />
      <div className="flex-1 flex flex-col min-w-0 relative z-10">
        <TopBar view={view} setView={setView} />
        <main className="flex-1 overflow-y-auto">
          <div className="max-w-[1180px] mx-auto px-4 sm:px-6 py-7 pb-24">
            {view === "garden" && <TimerView />}
            {view === "cards" && <Flashcards />}
            {view === "doubt" && <DoubtSolver />}
            {view === "notes" && <NotesStudio />}
            {view === "audit" && <DistractionCalc />}
            {view === "settings" && <Settings stored={stored} onPreset={pickPreset} onCustom={saveCustom} />}
          </div>
        </main>
      </div>
      <NowPlaying />
      <ToastHost />
    </div>
  );
}

export default function App() {
  return (
    <StoreProvider>
      <Shell />
    </StoreProvider>
  );
}
