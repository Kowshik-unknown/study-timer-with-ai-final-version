import React, { useRef, useState } from "react";
import { Icon } from "./icons";
import { EmptyState, Reveal, Ring, SectionHead } from "./shared";
import {
  extractPdfText,
  makeFlashcards,
  makeNotes,
  makeQuiz,
  notesToMarkdown,
  QuizQ,
  StudyNotes,
} from "../lib/textEngine";
import { aiSummarizeText, aiSummarizeVideo, AiEndpoint } from "../lib/ai";
import { useStore } from "../state/store";

type SourceTab = "paste" | "pdf" | "video";

function shuffleArr<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

export default function NotesStudio() {
  const { award, toast, saveDeck, recordQuiz, state } = useStore();
  const [tab, setTab] = useState<SourceTab>("paste");
  const [title, setTitle] = useState("");
  const [raw, setRaw] = useState("");
  const [videoUrl, setVideoUrl] = useState("");
  const [pdfMeta, setPdfMeta] = useState<{ name: string; pages: number; chars: number } | null>(null);
  const [extracting, setExtracting] = useState<{ pct: number; page: number; total: number } | null>(null);
  const [generating, setGenerating] = useState(false);
  const [notes, setNotes] = useState<StudyNotes | null>(null);
  const [sourceKind, setSourceKind] = useState<SourceTab>("paste");
  const [aiSummary, setAiSummary] = useState<string | null>(null);
  const [aiBusy, setAiBusy] = useState<"summary" | "video" | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const endpoint: AiEndpoint | null =
    state.settings.aiUrl.trim() || state.settings.aiKey.trim()
      ? { url: state.settings.aiUrl, key: state.settings.aiKey, model: state.settings.aiModel }
      : null;

  /* quiz state */
  const [quiz, setQuiz] = useState<QuizQ[] | null>(null);
  const [qIdx, setQIdx] = useState(0);
  const [picked, setPicked] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [quizDone, setQuizDone] = useState(false);

  const handlePdf = async (file: File) => {
    if (!/\.pdf$/i.test(file.name) && file.type !== "application/pdf") {
      toast("warn", "Not a PDF", "Please choose a .pdf file.");
      return;
    }
    setExtracting({ pct: 0, page: 0, total: 0 });
    try {
      const text = await extractPdfText(file, (pct, page, total) => setExtracting({ pct, page, total }));
      if (text.length < 300) {
        toast("warn", "Little text found", "This PDF looks scanned or image-based — try a text-based PDF.");
        setExtracting(null);
        return;
      }
      setRaw(text);
      setTitle(file.name.replace(/\.pdf$/i, ""));
      setPdfMeta({ name: file.name, pages: (text.match(/\f/g) || []).length + 1, chars: text.length });
      toast("ok", "PDF digested", `${Math.round(text.length / 1000)}k characters extracted.`);
    } catch {
      toast("warn", "Could not read that PDF", "The file may be corrupted or password-protected.");
    }
    setExtracting(null);
  };

  const fetchVideoTitle = async () => {
    if (!videoUrl.trim()) return;
    try {
      const res = await fetch(`https://noembed.com/embed?url=${encodeURIComponent(videoUrl.trim())}`);
      const d = await res.json();
      if (d?.title) setTitle(d.title);
    } catch {
      /* offline is fine */
    }
  };

  const generate = (overrideText?: string, overrideTitle?: string) => {
    const text = overrideText ?? raw;
    const ttl = overrideTitle ?? title;
    if (text.trim().length < 400) {
      toast("warn", "Not enough material", "The source needs at least ~400 characters for decent notes and quiz questions.");
      return;
    }
    setGenerating(true);
    setQuiz(null);
    setAiSummary(null);
    window.setTimeout(() => {
      const n = makeNotes(text, ttl);
      setNotes(n);
      setSourceKind(tab);
      setGenerating(false);
      award(20, "Notes distilled from source");
    }, 850);
  };

  /* ---------- AI summaries (built-in keys) ---------- */

  const summarizeWithAI = async () => {
    if (aiBusy) return;
    if (raw.trim().length < 400) {
      toast("warn", "Not enough material", "Add at least ~400 characters of source material first.");
      return;
    }
    setAiBusy("summary");
    try {
      const r = await aiSummarizeText(raw, endpoint);
      setAiSummary(r.text);
      award(20, "AI study brief generated");
    } catch {
      toast("warn", "AI unreachable", "Couldn't reach the tutor just now — the extractive summary below still works.");
    }
    setAiBusy(null);
  };

  const summarizeVideoAI = async () => {
    if (aiBusy) return;
    const url = videoUrl.trim();
    if (!/^https?:\/\//i.test(url)) {
      toast("warn", "Add the YouTube link first", "Paste the video URL above so the tutor knows what to summarize.");
      return;
    }
    setAiBusy("video");
    try {
      let ttl = "";
      try {
        const res = await fetch(`https://noembed.com/embed?url=${encodeURIComponent(url)}`);
        const d = await res.json();
        ttl = typeof d?.title === "string" ? d.title : "";
        if (ttl) setTitle(ttl);
      } catch {
        /* title fetch is best-effort */
      }
      const r = await aiSummarizeVideo(url, ttl, endpoint);
      setRaw(r.text);
      setPdfMeta(null);
      generate(r.text, ttl || "YouTube topic");
      setAiSummary(r.text);
    } catch {
      toast("warn", "AI unreachable", "Couldn't summarize that video right now — check your connection and try again.");
    }
    setAiBusy(null);
  };

  const startQuiz = () => {
    const qs = makeQuiz(raw, 8);
    if (qs.length < 3) {
      toast("warn", "Too few quiz questions", "The text needs more distinct key terms. Try a longer or more varied source.");
      return;
    }
    setQuiz(qs);
    setQIdx(0);
    setPicked(null);
    setScore(0);
    setQuizDone(false);
  };

  const answer = (i: number) => {
    if (picked !== null || !quiz) return;
    setPicked(i);
    const correct = i === quiz[qIdx].answer;
    if (correct) {
      setScore((s) => s + 1);
      award(10, "Quiz answer correct");
    }
  };

  const nextQ = () => {
    if (!quiz) return;
    if (qIdx + 1 >= quiz.length) {
      setQuizDone(true);
      recordQuiz(score, quiz.length);
    } else {
      setQIdx((i) => i + 1);
      setPicked(null);
    }
  };

  const sendToFlashcards = () => {
    const cards = makeFlashcards(raw, notes?.title || title, 10);
    if (cards.length < 3) {
      toast("warn", "Could not build cards from this source");
      return;
    }
    saveDeck(notes?.title || "Notes deck", notes?.title || "Notes", cards);
    toast("ok", "Deck created", `${cards.length} cards saved — open Flashcards to study them.`);
  };

  const copyMd = async () => {
    if (!notes) return;
    try {
      await navigator.clipboard.writeText(notesToMarkdown(notes));
      toast("ok", "Markdown copied", "Paste it into Notion, Obsidian, anywhere.");
    } catch {
      toast("warn", "Clipboard blocked", "Your browser refused — use Download instead.");
    }
  };

  const downloadMd = () => {
    if (!notes) return;
    const blob = new Blob([notesToMarkdown(notes)], { type: "text/markdown" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${notes.title.replace(/[^\w\d-]+/g, "-").slice(0, 40) || "notes"}.md`;
    a.click();
    URL.revokeObjectURL(url);
    toast("ok", "Notes downloaded", "Markdown file saved.");
  };

  const TABS: { id: SourceTab; label: string; icon: "file" | "upload" | "film" }[] = [
    { id: "paste", label: "Paste text", icon: "file" },
    { id: "pdf", label: "PDF upload", icon: "upload" },
    { id: "video", label: "Video", icon: "film" },
  ];

  return (
    <div>
      <SectionHead
        kicker="Notes Studio"
        title="Feed it a PDF, a video transcript, raw text"
        desc="Grove distills any source into a summary, key points, definitions and an outline, writes an AI study brief, and spins the same material into an interactive quiz and flashcards — YouTube links included."
        icon="notes"
        tone="lav"
      />

      <div className="grid lg:grid-cols-[430px_1fr] gap-5 items-start">
        {/* ---------- source ---------- */}
        <Reveal>
          <div className="panel p-5">
            <div className="grid grid-cols-3 gap-1.5 p-1 rounded-lg bg-pine-900/80 border border-pine-700/60 mb-4">
              {TABS.map((t) => (
                <button
                  key={t.id}
                  onClick={() => setTab(t.id)}
                  className={`chip-btn rounded-md px-2 py-2 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors ${
                    tab === t.id
                      ? "bg-lav-400/15 text-lav-300 border border-lav-400/40"
                      : "text-mist-400 border border-transparent hover:text-mist-200"
                  }`}
                >
                  <Icon name={t.icon} size={13} /> {t.label}
                </button>
              ))}
            </div>

            <label className="block">
              <span className="text-[11px] uppercase tracking-wider font-semibold text-mist-500">Title</span>
              <input
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. Chapter 4 — Cell Biology"
                className="mt-1.5 w-full rounded-lg bg-pine-900/80 border border-pine-600/70 px-3.5 py-2.5 text-sm text-mist-100 placeholder-mist-600 focus:border-lav-400/60 outline-none transition-colors"
              />
            </label>

            {tab === "paste" && (
              <div className="mt-4">
                <textarea
                  value={raw}
                  onChange={(e) => {
                    setRaw(e.target.value);
                    setPdfMeta(null);
                  }}
                  rows={11}
                  placeholder="Paste your textbook chapter, article or lecture transcript here…"
                  className="w-full rounded-lg bg-pine-900/80 border border-pine-600/70 px-3.5 py-2.5 text-sm text-mist-100 placeholder-mist-600 focus:border-lav-400/60 outline-none transition-colors resize-y leading-relaxed"
                />
                <div className="text-[11px] text-mist-600 mt-1 text-right">{raw.trim().length.toLocaleString()} chars</div>
              </div>
            )}

            {tab === "pdf" && (
              <div className="mt-4">
                <input
                  ref={fileRef}
                  type="file"
                  accept="application/pdf,.pdf"
                  className="hidden"
                  onChange={(e) => {
                    const f = e.target.files?.[0];
                    if (f) void handlePdf(f);
                    e.target.value = "";
                  }}
                />
                <button
                  onClick={() => fileRef.current?.click()}
                  onDragOver={(e) => e.preventDefault()}
                  onDrop={(e) => {
                    e.preventDefault();
                    const f = e.dataTransfer.files?.[0];
                    if (f) void handlePdf(f);
                  }}
                  className="chip-btn w-full rounded-xl border-2 border-dashed border-pine-600 hover:border-lav-400/60 bg-pine-900/50 px-4 py-8 text-center transition-colors"
                >
                  <div className="w-11 h-11 mx-auto rounded-lg bg-lav-400/12 border border-lav-400/40 text-lav-300 flex items-center justify-center mb-3">
                    <Icon name="upload" size={20} />
                  </div>
                  <div className="text-sm font-semibold text-mist-200">Drop a PDF or click to browse</div>
                  <div className="text-[11px] text-mist-500 mt-1">Text is extracted locally — nothing is uploaded</div>
                </button>

                {extracting && (
                  <div className="mt-3 rise-in">
                    <div className="flex justify-between text-[11px] font-semibold text-mist-400 mb-1.5">
                      <span className="flex items-center gap-1.5">
                        <span className="w-3 h-3 rounded-full border-2 border-lav-300 border-t-transparent animate-spin" />
                        Reading page {extracting.page || "…"}{extracting.total ? ` / ${extracting.total}` : ""}
                      </span>
                      <span className="font-mono">{Math.round(extracting.pct * 100)}%</span>
                    </div>
                    <div className="h-2 rounded-full bg-pine-800 overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-lav-400 to-leaf-400 rounded-full transition-all duration-300"
                        style={{ width: `${extracting.pct * 100}%` }}
                      />
                    </div>
                  </div>
                )}

                {pdfMeta && !extracting && (
                  <div className="mt-3 rise-in flex items-center gap-2.5 rounded-lg border border-leaf-500/40 bg-leaf-600/10 px-3.5 py-2.5">
                    <Icon name="check" size={15} className="text-leaf-400 shrink-0" strokeWidth={2.4} />
                    <div className="min-w-0 text-xs">
                      <div className="font-semibold text-mist-100 truncate">{pdfMeta.name}</div>
                      <div className="text-mist-500">
                        ~{(pdfMeta.chars / 1000).toFixed(0)}k chars ready to distill
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}

            {tab === "video" && (
              <div className="mt-4 space-y-3">
                <div>
                  <span className="text-[11px] uppercase tracking-wider font-semibold text-mist-500">Video link (optional)</span>
                  <div className="flex gap-2 mt-1.5">
                    <input
                      value={videoUrl}
                      onChange={(e) => setVideoUrl(e.target.value)}
                      placeholder="https://youtube.com/watch?v=…"
                      className="flex-1 rounded-lg bg-pine-900/80 border border-pine-600/70 px-3.5 py-2.5 text-sm text-mist-100 placeholder-mist-600 focus:border-lav-400/60 outline-none transition-colors"
                    />
                    <button
                      onClick={() => void fetchVideoTitle()}
                      className="chip-btn rounded-lg px-3 py-2 text-xs font-semibold border border-pine-600 text-mist-300 hover:text-mist-100 shrink-0"
                    >
                      Fetch title
                    </button>
                  </div>
                </div>
                <div>
                  <span className="text-[11px] uppercase tracking-wider font-semibold text-mist-500">Video transcript</span>
                  <textarea
                    value={raw}
                    onChange={(e) => setRaw(e.target.value)}
                    rows={9}
                    placeholder={"On YouTube: ⋯ → Show transcript → copy → paste here."}
                    className="mt-1.5 w-full rounded-lg bg-pine-900/80 border border-pine-600/70 px-3.5 py-2.5 text-sm text-mist-100 placeholder-mist-600 focus:border-lav-400/60 outline-none transition-colors resize-y leading-relaxed"
                  />
                  <p className="text-[11px] text-mist-600 mt-1 leading-relaxed">
                    Browsers block direct transcript scraping, so paste it from the video's transcript panel — Grove does the rest.
                  </p>
                </div>

                <div className="rounded-xl border border-lav-400/35 bg-lav-400/8 p-4">
                  <div className="flex items-center gap-2 text-lav-300">
                    <Icon name="wand" size={15} strokeWidth={2} />
                    <span className="text-[11px] uppercase tracking-widest font-bold">No transcript? Let the tutor watch it</span>
                  </div>
                  <p className="text-[11px] text-mist-500 mt-1.5 leading-relaxed">
                    Grove sends the link to the built-in AI (with web search) and writes a topic brief — then builds full notes, a
                    quiz and flashcards from it. No key needed on your side.
                  </p>
                  <button
                    onClick={() => void summarizeVideoAI()}
                    disabled={!!aiBusy}
                    className="chip-btn mt-3 w-full flex items-center justify-center gap-2 rounded-lg px-4 py-2.5 text-sm font-bold bg-lav-400/15 border border-lav-400/60 text-lav-300 hover:bg-lav-400/30 disabled:opacity-60"
                  >
                    {aiBusy === "video" ? (
                      <>
                        <span className="w-4 h-4 rounded-full border-2 border-lav-300 border-t-transparent animate-spin" />
                        Watching & summarizing…
                      </>
                    ) : (
                      <>
                        <Icon name="film" size={15} />
                        Summarize video with AI · +20 XP
                      </>
                    )}
                  </button>
                </div>
              </div>
            )}

            <button
              onClick={() => generate()}
              disabled={generating || !!extracting}
              className="chip-btn mt-5 w-full flex items-center justify-center gap-2 rounded-lg px-4 py-3 font-display font-bold text-[15px] bg-lav-400/15 border border-lav-400/60 text-lav-300 hover:bg-lav-400/30 disabled:opacity-60"
            >
              {generating ? (
                <>
                  <span className="w-4 h-4 rounded-full border-2 border-lav-300 border-t-transparent animate-spin" />
                  Distilling…
                </>
              ) : (
                <>
                  <Icon name="wand" size={16} strokeWidth={2} />
                  Generate notes · +20 XP
                </>
              )}
            </button>
            {generating && <div className="shimmer h-2 rounded-full mt-3" />}
          </div>
        </Reveal>

        {/* ---------- output ---------- */}
        <Reveal delay={90}>
          {!notes && !quiz && (
            <EmptyState
              icon="notes"
              title="Your distilled notes land here"
              sub="Summary, key points, definitions, a section outline — plus one-click quiz and flashcard generation from the same source."
            />
          )}

          {/* quiz mode */}
          {quiz && !quizDone && (
            <div className="panel p-6 sm:p-7 rise-in">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-[11px] uppercase tracking-widest text-lav-400 font-bold">Interactive quiz</div>
                  <div className="font-display font-bold text-mist-100">
                    Question {qIdx + 1} <span className="text-mist-500 font-normal">/ {quiz.length}</span>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-semibold text-leaf-400 border border-leaf-500/40 bg-leaf-600/15 rounded-md px-2 py-1">
                    {score} correct
                  </span>
                  <button
                    onClick={() => setQuiz(null)}
                    className="chip-btn text-xs text-mist-500 hover:text-mist-200 border border-pine-600 rounded-md px-2.5 py-1"
                  >
                    exit
                  </button>
                </div>
              </div>

              <div className="h-1.5 rounded-full bg-pine-700/70 mt-3 overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-lav-400 to-leaf-400 rounded-full transition-all duration-500"
                  style={{ width: `${(qIdx / quiz.length) * 100}%` }}
                />
              </div>

              <p className="font-display text-lg sm:text-xl font-semibold text-mist-100 leading-relaxed mt-5">
                {quiz[qIdx].prompt}
              </p>

              <div className="grid sm:grid-cols-2 gap-2.5 mt-5">
                {quiz[qIdx].options.map((opt, i) => {
                  const isAnswer = i === quiz[qIdx].answer;
                  const isPicked = picked === i;
                  let cls = "border-pine-600/70 bg-pine-900/60 text-mist-200 hover:border-lav-400/60 hover:-translate-y-0.5";
                  if (picked !== null) {
                    if (isAnswer) cls = "border-leaf-500/70 bg-leaf-600/20 text-leaf-200";
                    else if (isPicked) cls = "border-coral-500/70 bg-coral-500/15 text-coral-300";
                    else cls = "border-pine-700/60 bg-pine-900/40 text-mist-500 opacity-60";
                  }
                  return (
                    <button
                      key={i}
                      onClick={() => answer(i)}
                      disabled={picked !== null}
                      className={`chip-btn rounded-lg border px-4 py-3 text-left text-sm font-semibold flex items-center gap-2.5 transition-all ${cls}`}
                    >
                      <span className="w-6 h-6 shrink-0 rounded-md bg-pine-800 border border-pine-600 text-[11px] font-bold flex items-center justify-center">
                        {String.fromCharCode(65 + i)}
                      </span>
                      {opt}
                      {picked !== null && isAnswer && <Icon name="check" size={15} className="ml-auto shrink-0" strokeWidth={2.6} />}
                      {picked !== null && isPicked && !isAnswer && <Icon name="x" size={15} className="ml-auto shrink-0" strokeWidth={2.6} />}
                    </button>
                  );
                })}
              </div>

              {picked !== null && (
                <div className="rise-in mt-4">
                  <div
                    className={`rounded-lg border px-4 py-3 text-[13px] leading-relaxed ${
                      picked === quiz[qIdx].answer
                        ? "border-leaf-500/50 bg-leaf-600/10 text-mist-300"
                        : "border-coral-500/50 bg-coral-500/8 text-mist-300"
                    }`}
                  >
                    <span className="font-semibold text-mist-100">From the source: </span>
                    {quiz[qIdx].context}
                  </div>
                  <button
                    onClick={nextQ}
                    className="chip-btn mt-4 w-full rounded-lg px-4 py-3 font-display font-bold text-sm bg-lav-400/15 border border-lav-400/60 text-lav-300 hover:bg-lav-400/30 flex items-center justify-center gap-2"
                  >
                    {qIdx + 1 >= quiz.length ? "See results" : "Next question"}
                    <Icon name="arrow" size={15} />
                  </button>
                </div>
              )}
            </div>
          )}

          {/* quiz results */}
          {quiz && quizDone && (
            <div className="panel p-8 text-center rise-in">
              <Ring pct={quiz.length ? score / quiz.length : 0} size={160} stroke={10} color={score / quiz.length >= 0.6 ? "#98dd66" : "#f4c566"}>
                <div className="font-mono text-3xl font-bold text-mist-100 tabular-nums">
                  {score}/{quiz.length}
                </div>
                <div className="text-[10px] uppercase tracking-widest text-mist-500 font-bold mt-1">score</div>
              </Ring>
              <h3 className="font-display text-2xl font-bold text-mist-100 mt-5">
                {score / quiz.length >= 0.8 ? "Grove-level mastery" : score / quiz.length >= 0.6 ? "Solid roots" : "Worth another pass"}
              </h3>
              <p className="text-sm text-mist-400 mt-1.5">
                +{score * 10} XP banked · result saved to your study record
              </p>
              <div className="flex justify-center gap-2.5 mt-6">
                <button
                  onClick={startQuiz}
                  className="chip-btn rounded-lg px-4 py-2.5 text-sm font-semibold border border-pine-600 text-mist-300 hover:text-mist-100 flex items-center gap-2"
                >
                  <Icon name="shuffle" size={14} /> Retake quiz
                </button>
                <button
                  onClick={() => setQuiz(null)}
                  className="chip-btn rounded-lg px-4 py-2.5 text-sm font-semibold bg-lav-400/15 border border-lav-400/60 text-lav-300 hover:bg-lav-400/30 flex items-center gap-2"
                >
                  <Icon name="notes" size={14} /> Back to notes
                </button>
              </div>
            </div>
          )}

          {/* notes display */}
          {notes && !quiz && (
            <div className="space-y-4 rise-in">
              <div className="panel p-6">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div className="min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-[10px] uppercase tracking-widest font-bold text-lav-300 border border-lav-400/40 bg-lav-400/10 rounded px-2 py-0.5">
                        {sourceKind === "pdf" ? "PDF source" : sourceKind === "video" ? "Video source" : "Text source"}
                      </span>
                      <span className="text-[11px] text-mist-500 font-mono">{notes.wordCount.toLocaleString()} words in</span>
                    </div>
                    <h3 className="font-display text-2xl font-bold text-mist-100 mt-2 leading-tight">{notes.title}</h3>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <button
                      onClick={() => void summarizeWithAI()}
                      disabled={!!aiBusy}
                      className="chip-btn text-xs font-bold border border-lav-400/50 bg-lav-400/10 rounded-lg px-3 py-2 text-lav-300 hover:bg-lav-400/25 flex items-center gap-1.5 disabled:opacity-60"
                    >
                      {aiBusy === "summary" ? (
                        <span className="w-3.5 h-3.5 rounded-full border-2 border-lav-300 border-t-transparent animate-spin" />
                      ) : (
                        <Icon name="wand" size={13} strokeWidth={2.2} />
                      )}
                      {aiBusy === "summary" ? "Summarizing…" : "AI summary · +20 XP"}
                    </button>
                    <button onClick={() => void copyMd()} className="chip-btn text-xs font-semibold border border-pine-600 rounded-lg px-3 py-2 text-mist-300 hover:text-mist-100 flex items-center gap-1.5">
                      <Icon name="copy" size={13} /> Copy MD
                    </button>
                    <button onClick={downloadMd} className="chip-btn text-xs font-semibold border border-pine-600 rounded-lg px-3 py-2 text-mist-300 hover:text-mist-100 flex items-center gap-1.5">
                      <Icon name="download" size={13} /> Download
                    </button>
                    <button onClick={sendToFlashcards} className="chip-btn text-xs font-semibold border border-gold-500/50 bg-gold-500/12 rounded-lg px-3 py-2 text-gold-300 hover:bg-gold-500/25 flex items-center gap-1.5">
                      <Icon name="cards" size={13} /> To flashcards
                    </button>
                    <button onClick={startQuiz} className="chip-btn text-xs font-bold border border-leaf-500/60 bg-leaf-600/20 rounded-lg px-3 py-2 text-leaf-200 hover:bg-leaf-600/35 flex items-center gap-1.5">
                      <Icon name="bolt" size={13} strokeWidth={2.2} /> Generate quiz
                    </button>
                  </div>
                </div>
              </div>

              {aiSummary && (
                <div className="panel p-6 border-lav-400/40 rise-in">
                  <div className="flex items-center gap-2 text-lav-400 mb-3">
                    <Icon name="wand" size={15} strokeWidth={2} />
                    <span className="text-[11px] uppercase tracking-widest font-bold">AI study brief · Grove tutor</span>
                    <span className="ml-auto text-[9px] uppercase tracking-widest font-bold text-lav-300 border border-lav-400/40 rounded px-1.5 py-0.5">
                      gemini tutor
                    </span>
                  </div>
                  <p className="text-sm text-mist-200 leading-relaxed whitespace-pre-line">{aiSummary}</p>
                </div>
              )}

              <div className="panel p-6">
                <div className="flex items-center gap-2 text-leaf-400 mb-3">
                  <Icon name="leaf" size={15} strokeWidth={2} />
                  <span className="text-[11px] uppercase tracking-widest font-bold">Summary</span>
                </div>
                <div className="space-y-2.5">
                  {notes.summary.map((s, i) => (
                    <p key={i} className="text-sm text-mist-200 leading-relaxed border-l-2 border-leaf-500/50 pl-3.5">
                      {s}
                    </p>
                  ))}
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div className="panel p-6">
                  <div className="flex items-center gap-2 text-gold-400 mb-3">
                    <Icon name="star" size={15} strokeWidth={2} />
                    <span className="text-[11px] uppercase tracking-widest font-bold">Key points</span>
                  </div>
                  <ul className="space-y-2.5">
                    {notes.keyPoints.map((k, i) => (
                      <li key={i} className="flex gap-2.5 text-[13px] text-mist-300 leading-relaxed">
                        <Icon name="check" size={14} className="text-gold-400 shrink-0 mt-0.5" strokeWidth={2.4} />
                        {k}
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="panel p-6">
                  <div className="flex items-center gap-2 text-aqua-400 mb-3">
                    <Icon name="book" size={15} strokeWidth={2} />
                    <span className="text-[11px] uppercase tracking-widest font-bold">Definitions</span>
                  </div>
                  {notes.definitions.length === 0 ? (
                    <p className="text-xs text-mist-500">No strong definition sentences detected in this source.</p>
                  ) : (
                    <ul className="space-y-3">
                      {notes.definitions.map((d) => (
                        <li key={d.term}>
                          <span className="text-[13px] font-bold text-aqua-300">{d.term}</span>
                          <p className="text-[13px] text-mist-400 leading-relaxed mt-0.5">{d.def}</p>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              </div>

              {notes.outline.length > 0 && (
                <div className="panel p-6">
                  <div className="flex items-center gap-2 text-lav-400 mb-3">
                    <Icon name="notes" size={15} strokeWidth={2} />
                    <span className="text-[11px] uppercase tracking-widest font-bold">Outline</span>
                  </div>
                  <div className="grid md:grid-cols-2 gap-x-6 gap-y-4">
                    {notes.outline.map((o, i) => (
                      <div key={i}>
                        <div className="flex items-baseline gap-2">
                          <span className="font-mono text-[11px] font-bold text-lav-400">{String(i + 1).padStart(2, "0")}</span>
                          <span className="text-sm font-bold text-mist-100">{o.heading}</span>
                        </div>
                        <ul className="mt-1.5 space-y-1.5 pl-6">
                          {o.points.map((p, j) => (
                            <li key={j} className="text-[13px] text-mist-400 leading-relaxed list-disc marker:text-pine-500">
                              {p}
                            </li>
                          ))}
                        </ul>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </Reveal>
      </div>
    </div>
  );
}
