// src/lib/ai.ts
// Doubt solving + summarization via the Google Gemini API.
//
// The core request below is the verified one (plain contents → parts, key in
// the query string). It is wrapped in a model ladder — newest families (3.x
// flash / flash-lite) first, evergreen "-latest" aliases next, retired names
// last. A 404 on a dead model rolls to the next one automatically, and after
// Gemini, backup routes keep the tutor answering even if the key is ever
// throttled or revoked.

interface AIEndpoint {
  url?: string;
  key?: string;
  model?: string;
}

export type AiEndpoint = AIEndpoint;

export interface AiReply {
  text: string;
  engine: string;
}

/* Built-in tutor key — used whenever Settings doesn't supply one. */
const DEFAULT_GEMINI_KEY = "AQ.Ab8RN6IuULOZ09bnFKNFnUscFBY93zFdLTQHYXizPZsMpn2dJA";

export const maskKey = (k: string) => (k ? `${k.slice(0, 4)}…${k.slice(-4)}` : "");
export const builtinKeyHint = (custom?: string) => maskKey((custom || "").trim() || DEFAULT_GEMINI_KEY);

/* Current model families first (3.x), then the evergreen "-latest" aliases,
   then older generations. 404s on retired names resolve in under a second,
   so burning through dead entries is cheap. */
const MODEL_FALLBACKS = [
  "gemini-3.6-flash",
  "gemini-3.5-flash",
  "gemini-3.5-flash-lite",
  "gemini-3-flash",
  "gemini-flash-latest",
  "gemini-pro-latest",
  "gemini-3-pro-preview",
  "gemini-2.5-flash",
  "gemini-2.5-pro",
  "gemini-2.0-flash",
  "gemini-1.5-flash",
  "gemini-pro",
];

/* Backup routes if every Gemini call fails (throttle / revoked key / outage). */
const POLLINATIONS_URL = "https://text.pollinations.ai/openai";
const BACKUP_KEYS = [
  "sk-W2E5rrpZnJYYHe96PIjM8l1zqPc0pmtL8eW77LQ29_s",
  "e20a842cd9d84a37df9ee6a3389e2820",
];

const TUTOR_INSTRUCTION =
  "You are a helpful tutor for students in math, physics, chemistry and every school subject. " +
  "For numerical problems: state the formula, substitute the given values with units, solve step by step, " +
  "and end with 'Answer: <value with units>'. For theory: short numbered steps ending with one crisp takeaway. " +
  "Plain text only, no markdown symbols.";

/* ---------- the verified Gemini request ---------- */

async function callGeminiModel(prompt: string, apiKey: string, model: string, timeoutMs: number): Promise<string> {
  // Use Gemini API directly
  const geminiUrl = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`;

  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), timeoutMs);

  try {
    const response = await fetch(`${geminiUrl}?key=${encodeURIComponent(apiKey)}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        contents: [
          {
            parts: [
              {
                text: prompt,
              },
            ],
          },
        ],
        generationConfig: {
          temperature: 0.7,
          maxOutputTokens: 1024,
        },
      }),
      signal: controller.signal,
    });

    if (!response.ok) {
      let detail = "";
      try {
        const err = await response.json();
        detail = err?.error?.message ? ` — ${String(err.error.message).slice(0, 140)}` : "";
      } catch {
        /* non-JSON error body */
      }
      throw new Error(`Gemini API error: ${response.status}${detail}`);
    }

    const data = await response.json();
    const answer =
      data?.candidates?.[0]?.content?.parts?.[0]?.text ||
      "I couldn't generate an answer. Please try again.";

    return answer;
  } catch (error) {
    console.error("AI Error:", error);
    throw error;
  } finally {
    window.clearTimeout(timer);
  }
}

/* Try the preferred model first, then walk down the live model families. */
async function geminiWithFallbacks(prompt: string, endpoint?: AIEndpoint | null): Promise<{ text: string; model: string }> {
  const apiKey = (endpoint?.key || "").trim() || DEFAULT_GEMINI_KEY;
  /* "-latest" aliases always resolve to the newest generation Google serves. */
  const preferred = (endpoint?.model || "").trim() || "gemini-flash-latest";

  const order = [preferred, ...MODEL_FALLBACKS.filter((m) => m !== preferred)];
  let lastError: unknown = null;

  for (const model of order) {
    try {
      const text = await callGeminiModel(prompt, apiKey, model, 12000);
      return { text, model };
    } catch (e) {
      lastError = e;
    }
  }
  throw lastError instanceof Error ? lastError : new Error("Gemini unreachable");
}

/* ---------- backup routes (only if all Gemini models fail) ---------- */

async function postChat(url: string, body: Record<string, unknown>, bearer: string | null, timeoutMs: number): Promise<string> {
  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...(bearer ? { Authorization: `Bearer ${bearer}` } : {}),
      },
      body: JSON.stringify(body),
      signal: controller.signal,
    });
    if (!res.ok) throw new Error(`backup route ${res.status}`);
    const data = await res.json();
    const text: string | undefined = data?.choices?.[0]?.message?.content;
    if (!text || !text.trim()) throw new Error("Empty reply");
    return text.trim();
  } finally {
    window.clearTimeout(timer);
  }
}

async function anonGet(prompt: string): Promise<string> {
  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), 20000);
  try {
    const q = prompt.slice(0, 1500);
    const url = `https://text.pollinations.ai/${encodeURIComponent(q)}?model=gemini&referrer=grove`;
    const res = await fetch(url, { signal: controller.signal });
    if (!res.ok) throw new Error(`free tier ${res.status}`);
    const text = (await res.text()).trim();
    if (!text) throw new Error("Empty reply");
    return text;
  } finally {
    window.clearTimeout(timer);
  }
}

/* ---------- public entry ---------- */

export async function askOnlineAI(
  question: string,
  endpoint?: AIEndpoint | null
): Promise<{ text: string; engine: string }> {
  const prompt = `${TUTOR_INSTRUCTION}\n\nStudent's doubt: ${question}`;

  // An optional custom OpenAI-compatible endpoint from Settings takes priority.
  if (endpoint && endpoint.url && endpoint.url.trim()) {
    try {
      const base = endpoint.url.trim();
      const url = base.endsWith("/chat/completions") ? base : `${base.replace(/\/+$/, "")}/chat/completions`;
      const text = await postChat(
        url,
        {
          model: endpoint.model || "gpt-4o-mini",
          messages: [
            { role: "system", content: TUTOR_INSTRUCTION },
            { role: "user", content: question },
          ],
          temperature: 0.7,
        },
        endpoint.key || null,
        20000
      );
      return { text, engine: "your endpoint" };
    } catch {
      /* fall through to Gemini */
    }
  }

  /* 1 — Gemini across the whole model family */
  try {
    const r = await geminiWithFallbacks(prompt, endpoint);
    return { text: r.text, engine: `gemini · ${r.model}` };
  } catch (geminiErr) {
    console.warn("All Gemini models failed:", geminiErr);

    /* 2 — backup keys through Pollinations */
    for (const key of BACKUP_KEYS) {
      for (const model of ["gemini", "openai-large"]) {
        try {
          const text = await postChat(
            `${POLLINATIONS_URL}?referrer=grove`,
            {
              model,
              messages: [
                { role: "system", content: TUTOR_INSTRUCTION },
                { role: "user", content: question },
              ],
              temperature: 0.7,
            },
            key,
            15000
          );
          return { text, engine: `backup route · ${model}` };
        } catch {
          /* next */
        }
      }
    }

    /* 3 — anonymous free tier */
    try {
      const text = await anonGet(prompt);
      return { text, engine: "free tier" };
    } catch (freeErr) {
      throw geminiErr instanceof Error ? geminiErr : freeErr;
    }
  }
}

/* ---------- Grove summarizers (same verified request path) ---------- */

export async function aiSummarizeText(source: string, endpoint: AiEndpoint | null): Promise<AiReply> {
  const trimmed = source.trim().slice(0, 6000);
  const prompt =
    "You are a study notes assistant. From the material below, write a focused study summary: " +
    "start with 2-3 sentences capturing the core idea, then 6-8 bullet lines with the key facts, formulas or definitions a student must remember. " +
    "Use plain text only, no markdown symbols, under 260 words.\n\nMATERIAL:\n" +
    trimmed;
  try {
    const r = await geminiWithFallbacks(prompt, endpoint);
    return { text: r.text, engine: `gemini · ${r.model}` };
  } catch {
    return { text: await anonGet(prompt), engine: "free tier" };
  }
}

export async function aiSummarizeVideo(
  videoUrl: string,
  knownTitle: string,
  endpoint: AiEndpoint | null
): Promise<AiReply> {
  const prompt =
    "You are a study assistant. A student shared this video: " +
    videoUrl +
    (knownTitle ? ` (title: "${knownTitle}")` : "") +
    ". Summarize the topic it covers for revision: 2-3 sentences on the core idea, then 6-8 bullet lines of the key concepts, terms, formulas or steps. " +
    "If you cannot access the video itself, briefly teach the same topic from your own knowledge and say so in one short line at the end. " +
    "Use plain text only, no markdown symbols, under 300 words.";
  try {
    const r = await geminiWithFallbacks(prompt, endpoint);
    return { text: r.text, engine: `gemini · ${r.model}` };
  } catch {
    return { text: await anonGet(prompt), engine: "free tier" };
  }
}
