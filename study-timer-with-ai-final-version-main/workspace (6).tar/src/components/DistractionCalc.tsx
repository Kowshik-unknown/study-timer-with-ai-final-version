import React, { useEffect, useState } from "react";
import { Icon, IconName } from "./icons";
import { CountUp, Reveal, Ring, SectionHead } from "./shared";
import { useStore } from "../state/store";

const LS_KEY = "grove-distraction-v1";

interface Inputs {
  pickups: number;
  perPickup: number;
  social: number;
  streaming: number;
  switches: number;
}

const DEFAULTS: Inputs = { pickups: 58, perPickup: 3, social: 90, streaming: 45, switches: 30 };

function loadInputs(): Inputs {
  try {
    const raw = localStorage.getItem(LS_KEY);
    return raw ? { ...DEFAULTS, ...JSON.parse(raw) } : DEFAULTS;
  } catch {
    return DEFAULTS;
  }
}

const fmtH = (min: number) => {
  const h = Math.floor(min / 60);
  const m = Math.round(min % 60);
  return h > 0 ? `${h}h ${m}m` : `${m}m`;
};

function Slider({
  label,
  value,
  min,
  max,
  step = 1,
  unit,
  icon,
  tone,
  onChange,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step?: number;
  unit: string;
  icon: IconName;
  tone: string;
  onChange: (v: number) => void;
}) {
  const pct = ((value - min) / (max - min)) * 100;
  return (
    <div className="py-3.5 border-b border-pine-700/50 last:border-0">
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-2.5 min-w-0">
          <span className={`w-8 h-8 rounded-lg bg-pine-800 border border-pine-600/60 flex items-center justify-center shrink-0 ${tone}`}>
            <Icon name={icon} size={15} />
          </span>
          <span className="text-sm font-semibold text-mist-200 truncate">{label}</span>
        </div>
        <span className="font-mono text-sm font-semibold text-mist-100 tabular-nums shrink-0">
          {value}
          <span className="text-mist-500 text-[11px] ml-1">{unit}</span>
        </span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(parseFloat(e.target.value))}
        className="w-full mt-2.5"
        style={{ ["--fill" as string]: `${pct}%` }}
        aria-label={label}
      />
    </div>
  );
}

export default function DistractionCalc() {
  const { award, toast, state } = useStore();
  const [inp, setInp] = useState<Inputs>(loadInputs);
  const [taps, setTaps] = useState<{ key: string; count: number }>(() => {
    const key = new Date().toISOString().slice(0, 10);
    try {
      const raw = localStorage.getItem("grove-taps-v1");
      const p = raw ? JSON.parse(raw) : null;
      return p && p.key === key ? p : { key, count: 0 };
    } catch {
      return { key, count: 0 };
    }
  });

  useEffect(() => {
    localStorage.setItem(LS_KEY, JSON.stringify(inp));
  }, [inp]);

  useEffect(() => {
    localStorage.setItem("grove-taps-v1", JSON.stringify(taps));
  }, [taps]);

  const pickupMin = inp.pickups * inp.perPickup;
  const switchMin = inp.switches * 0.75;
  const dailyMin = pickupMin + inp.social + inp.streaming + switchMin;
  const yearlyH = (dailyMin * 365) / 60;
  const daysLost = yearlyH / 24;
  const wakingPct = (dailyMin / (16 * 60)) * 100;
  const score = Math.max(4, Math.min(97, Math.round(100 - (dailyMin / (16 * 60)) * 235)));
  const scoreColor = score >= 70 ? "#98dd66" : score >= 40 ? "#f4c566" : "#f2907e";

  const buckets = [
    { label: "Phone pickups", min: pickupMin, icon: "target" as IconName, tone: "text-coral-400", bar: "#e97261" },
    { label: "Social feeds", min: inp.social, icon: "spark" as IconName, tone: "text-gold-400", bar: "#f4c566" },
    { label: "Streaming & video", min: inp.streaming, icon: "film" as IconName, tone: "text-lav-400", bar: "#c0b1ec" },
    { label: "Context switches", min: switchMin, icon: "shuffle" as IconName, tone: "text-aqua-400", bar: "#8ad4cb" },
  ];
  const maxBucket = Math.max(...buckets.map((b) => b.min), 1);

  const reclaim = [0.25, 0.5, 0.75].map((f) => {
    const h = yearlyH * f;
    return {
      f,
      h,
      books: Math.round(h / 6),
      sessions: Math.round((h * 60) / 25),
      cards: Math.round(h * 60 * 2),
    };
  });

  const set = (k: keyof Inputs) => (v: number) => setInp((p) => ({ ...p, [k]: v }));

  const registerTap = () => {
    setTaps((t) => ({ ...t, count: t.count + 1 }));
    if ((taps.count + 1) % 10 === 0) {
      award(5, "Caught yourself distracted 10× — awareness is half the fix");
    }
  };

  return (
    <div>
      <SectionHead
        kicker="Distraction Audit"
        title="What is your attention really costing?"
        desc="Drag the sliders to match a typical day. Grove computes the hours leaking away, your focus score, and exactly what reclaiming even 25% buys you."
        icon="target"
        tone="coral"
      />

      <div className="grid lg:grid-cols-[420px_1fr] gap-5 items-start">
        {/* inputs */}
        <Reveal>
          <div className="panel p-5">
            <div className="flex items-center justify-between mb-1">
              <span className="font-display font-bold text-mist-100">A typical day</span>
              <button
                onClick={() => {
                  setInp(DEFAULTS);
                  toast("info", "Sliders reset", "Back to the sample day.");
                }}
                className="chip-btn text-[11px] font-semibold text-mist-500 hover:text-mist-200 border border-pine-600 rounded-md px-2 py-1"
              >
                reset
              </button>
            </div>
            <Slider label="Phone pickups" value={inp.pickups} min={0} max={150} unit="×/day" icon="target" tone="text-coral-400" onChange={set("pickups")} />
            <Slider label="Minutes per pickup" value={inp.perPickup} min={1} max={15} unit="min" icon="clock" tone="text-coral-400" onChange={set("perPickup")} />
            <Slider label="Social media" value={inp.social} min={0} max={300} unit="min/day" icon="spark" tone="text-gold-400" onChange={set("social")} />
            <Slider label="Streaming / videos" value={inp.streaming} min={0} max={300} unit="min/day" icon="film" tone="text-lav-400" onChange={set("streaming")} />
            <Slider label="Task switches" value={inp.switches} min={0} max={80} unit="×/day" icon="shuffle" tone="text-aqua-400" onChange={set("switches")} />
            <p className="text-[11px] text-mist-600 mt-2 leading-relaxed">
              Each task switch costs ~45 seconds of refocus time — it adds up faster than you think.
            </p>
          </div>

          {/* tally clicker */}
          <div className="panel p-5 mt-4">
            <div className="flex items-center gap-2 mb-2">
              <Icon name="flame" size={15} className="text-coral-400" />
              <span className="text-[11px] uppercase tracking-widest font-bold text-mist-500">Live distraction tally · today</span>
            </div>
            <p className="text-xs text-mist-500 leading-relaxed mb-3">
              Keep this open while you study. Every time you catch yourself drifting, tap the button — honesty builds the muscle.
            </p>
            <div className="flex items-center gap-3">
              <button
                onClick={registerTap}
                className="chip-btn flex-1 rounded-xl py-4 bg-coral-500/12 border border-coral-500/50 text-coral-300 font-display font-bold text-lg hover:bg-coral-500/25 active:scale-[0.98] transition-transform"
              >
                I got distracted
              </button>
              <div className="text-center shrink-0 w-20">
                <div className="font-mono text-2xl font-bold text-mist-100 tabular-nums">{taps.count}</div>
                <div className="text-[10px] uppercase tracking-wider text-mist-500 font-semibold">
                  ≈ {fmtH(taps.count * inp.perPickup)} lost
                </div>
              </div>
            </div>
          </div>
        </Reveal>

        {/* results */}
        <div className="space-y-5">
          <Reveal delay={80}>
            <div className="grid sm:grid-cols-[auto_1fr] gap-5 panel p-6 items-center">
              <div className="flex justify-center">
                <Ring pct={score / 100} size={168} stroke={10} color={scoreColor}>
                  <div className="font-mono text-4xl font-bold tabular-nums" style={{ color: scoreColor }}>
                    <CountUp value={score} />
                  </div>
                  <div className="text-[10px] uppercase tracking-[0.2em] font-bold text-mist-500 mt-1">Focus score</div>
                </Ring>
              </div>
              <div>
                <div className="grid grid-cols-2 gap-x-6 gap-y-4">
                  <div>
                    <div className="text-[11px] uppercase tracking-wider font-semibold text-mist-500">Lost per day</div>
                    <div className="font-display text-3xl font-bold text-coral-300">{fmtH(dailyMin)}</div>
                  </div>
                  <div>
                    <div className="text-[11px] uppercase tracking-wider font-semibold text-mist-500">Lost per year</div>
                    <div className="font-display text-3xl font-bold text-coral-300">
                      <CountUp value={yearlyH} decimals={0} />h
                    </div>
                  </div>
                  <div>
                    <div className="text-[11px] uppercase tracking-wider font-semibold text-mist-500">Full days / year</div>
                    <div className="font-display text-2xl font-bold text-mist-100">
                      <CountUp value={daysLost} decimals={1} /> days
                    </div>
                  </div>
                  <div>
                    <div className="text-[11px] uppercase tracking-wider font-semibold text-mist-500">Of waking life</div>
                    <div className="font-display text-2xl font-bold text-mist-100">
                      <CountUp value={wakingPct} decimals={1} />%
                    </div>
                  </div>
                </div>
                <p className="text-xs text-mist-500 mt-3 leading-relaxed border-t border-pine-700/60 pt-3">
                  That is <span className="text-mist-200 font-semibold">{Math.round(daysLost)} full days</span> a year spent in
                  fragments — more than a two-week holiday, gone in five-second sips.
                </p>
              </div>
            </div>
          </Reveal>

          <Reveal delay={140}>
            <div className="panel p-6">
              <div className="font-display font-bold text-mist-100 mb-4">Where it leaks</div>
              <div className="space-y-3.5">
                {buckets.map((b, i) => (
                  <div key={b.label}>
                    <div className="flex justify-between text-[12px] mb-1.5">
                      <span className={`font-semibold flex items-center gap-1.5 ${b.tone}`}>
                        <Icon name={b.icon} size={13} /> {b.label}
                      </span>
                      <span className="font-mono text-mist-300 tabular-nums">{fmtH(b.min)} /day</span>
                    </div>
                    <div className="h-2.5 rounded-full bg-pine-800 overflow-hidden">
                      <div
                        className="h-full rounded-full grow-bar"
                        style={{ width: `${(b.min / maxBucket) * 100}%`, background: b.bar, animationDelay: `${i * 120}ms` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </Reveal>

          <Reveal delay={200}>
            <div className="panel p-6">
              <div className="flex items-center gap-2 mb-1">
                <Icon name="sprout" size={16} className="text-leaf-400" />
                <span className="font-display font-bold text-mist-100">What reclaiming it buys you</span>
              </div>
              <p className="text-xs text-mist-500 mb-4">Cut distractions by a fraction — here's what the reclaimed hours become per year.</p>
              <div className="grid sm:grid-cols-3 gap-3">
                {reclaim.map((r, i) => (
                  <div
                    key={r.f}
                    className={`rounded-xl border p-4 transition-transform duration-200 hover:-translate-y-1 ${
                      i === 1 ? "border-leaf-500/60 bg-leaf-600/12 shadow-glow" : "border-pine-600/70 bg-pine-900/60"
                    }`}
                  >
                    <div className={`text-[11px] uppercase tracking-widest font-bold ${i === 1 ? "text-leaf-400" : "text-mist-500"}`}>
                      −{Math.round(r.f * 100)}% distraction
                    </div>
                    <div className="font-display text-2xl font-bold text-mist-100 mt-1">
                      <CountUp value={r.h} decimals={0} /> h/yr
                    </div>
                    <ul className="mt-3 space-y-1.5 text-[12px] text-mist-400">
                      <li className="flex justify-between gap-2">
                        <span>Books finished</span>
                        <span className="font-mono text-gold-300 font-semibold">{r.books}</span>
                      </li>
                      <li className="flex justify-between gap-2">
                        <span>Grove sessions</span>
                        <span className="font-mono text-leaf-300 font-semibold">{r.sessions}</span>
                      </li>
                      <li className="flex justify-between gap-2">
                        <span>Flashcards reviewed</span>
                        <span className="font-mono text-aqua-300 font-semibold">{r.cards}</span>
                      </li>
                    </ul>
                  </div>
                ))}
              </div>
              <p className="text-[11px] text-mist-600 mt-3">
                Lifetime focus banked so far: <span className="text-leaf-300 font-semibold">{state.totalMin} min</span> across{" "}
                {state.sessions} sessions — every one of them reclaimed from this pile.
              </p>
            </div>
          </Reveal>
        </div>
      </div>
    </div>
  );
}
