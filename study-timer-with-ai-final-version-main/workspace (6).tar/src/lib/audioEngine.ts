/* Procedural ambient music engine — everything is synthesized in-browser. */

export type MoodId = "lofi" | "forest" | "deep";

export interface MoodDef {
  id: MoodId;
  name: string;
  tag: string;
  desc: string;
}

export const MOODS: MoodDef[] = [
  { id: "lofi", name: "Rainy Lo-fi", tag: "warm", desc: "Mellow chords, soft rain & vinyl crackle" },
  { id: "forest", name: "Forest Dawn", tag: "airy", desc: "Open pads, wind through leaves, distant birds" },
  { id: "deep", name: "Deep Root", tag: "focus", desc: "Low drone for long, unbroken concentration" },
];

const CHORDS: Record<MoodId, number[][]> = {
  lofi: [
    [174.61, 220.0, 261.63, 329.63], // Fmaj7
    [220.0, 261.63, 329.63, 392.0], // Am7
    [146.83, 174.61, 220.0, 261.63], // Dm7
    [196.0, 233.08, 293.66, 349.23], // Gm7-ish color
  ],
  forest: [
    [146.83, 220.0, 293.66, 440.0],
    [130.81, 196.0, 261.63, 392.0],
    [164.81, 246.94, 329.63, 493.88],
    [110.0, 164.81, 220.0, 329.63],
  ],
  deep: [
    [82.41, 123.47, 164.81],
    [73.42, 110.0, 146.83],
    [87.31, 130.81, 174.61],
  ],
};

const SCALES: Record<MoodId, number[]> = {
  lofi: [349.23, 392.0, 440.0, 523.25, 587.33, 698.46],
  forest: [523.25, 587.33, 659.25, 783.99, 880.0, 1046.5],
  deep: [164.81, 196.0, 220.0, 246.94],
};

const MOOD_WAVE: Record<MoodId, OscillatorType> = {
  lofi: "triangle",
  forest: "sine",
  deep: "sine",
};

const CHORD_DUR: Record<MoodId, number> = { lofi: 4.4, forest: 6.2, deep: 8.5 };

type AC = AudioContext;

class AmbientEngine {
  private ctx: AC | null = null;
  private master: GainNode | null = null;
  private noiseBuf: AudioBuffer | null = null;
  private live: { stop?: () => void; disconnect?: () => void }[] = [];
  private timeouts: number[] = [];
  private running = false;
  private version = 0;
  private listeners = new Set<() => void>();

  mood: MoodId = "lofi";
  volume = 0.65;
  playing = false;

  subscribe = (fn: () => void) => {
    this.listeners.add(fn);
    return () => {
      this.listeners.delete(fn);
    };
  };

  getVersion = () => this.version;

  private emit() {
    this.version++;
    this.listeners.forEach((fn) => fn());
  }

  private ensure(): AC {
    if (!this.ctx) {
      const Ctor =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new Ctor();
      this.master = this.ctx.createGain();
      this.master.gain.value = this.volume * 0.5;
      this.master.connect(this.ctx.destination);
    }
    if (this.ctx.state === "suspended") void this.ctx.resume();
    return this.ctx;
  }

  private moodSeed: MoodId = "lofi";

  private buildNoise(ctx: AC) {
    const len = ctx.sampleRate * 2;
    const buf = ctx.createBuffer(1, len, ctx.sampleRate);
    const data = buf.getChannelData(0);
    let last = 0;
    for (let i = 0; i < len; i++) {
      const white = Math.random() * 2 - 1;
      last = (last + 0.02 * white) / 1.02;
      data[i] = (this.moodSeed === "forest" ? last * 3.2 : white) * 0.6;
    }
    this.noiseBuf = buf;
  }

  setVolume(v: number) {
    this.volume = v;
    if (this.master && this.ctx) {
      this.master.gain.setTargetAtTime(v * 0.5, this.ctx.currentTime, 0.06);
    }
    this.emit();
  }

  start(mood: MoodId) {
    const ctx = this.ensure();
    this.stopInternal();
    this.mood = mood;
    this.moodSeed = mood;
    this.running = true;
    this.playing = true;
    this.buildNoise(ctx);
    this.startPad(ctx);
    this.startTexture(ctx);
    if (mood !== "deep") this.startPluck(ctx);
    this.emit();
  }

  stop() {
    this.stopInternal();
    this.emit();
  }

  private stopInternal() {
    this.running = false;
    this.playing = false;
    this.timeouts.forEach((t) => window.clearTimeout(t));
    this.timeouts = [];
    this.live.forEach((n) => {
      try {
        n.stop?.();
        n.disconnect?.();
      } catch {
        /* noop */
      }
    });
    this.live = [];
  }

  private later(fn: () => void, ms: number) {
    const id = window.setTimeout(() => {
      if (this.running) fn();
    }, ms);
    this.timeouts.push(id);
  }

  /* ---------- layers ---------- */

  private startPad(ctx: AC) {
    const chords = CHORDS[this.mood];
    const dur = CHORD_DUR[this.mood];
    const wave = MOOD_WAVE[this.mood];
    const schedule = (i: number, t: number) => {
      const chord = chords[i % chords.length];
      const g = ctx.createGain();
      g.gain.setValueAtTime(0.0001, t);
      g.gain.linearRampToValueAtTime(this.mood === "deep" ? 0.22 : 0.13, t + dur * 0.4);
      g.gain.setValueAtTime(this.mood === "deep" ? 0.22 : 0.13, t + dur * 0.72);
      g.gain.linearRampToValueAtTime(0.0001, t + dur + 0.4);
      const filt = ctx.createBiquadFilter();
      filt.type = "lowpass";
      filt.frequency.value = this.mood === "deep" ? 480 : 1150;
      g.connect(filt);
      filt.connect(this.master!);
      chord.forEach((f, k) => {
        const o = ctx.createOscillator();
        o.type = wave;
        o.frequency.value = f;
        o.detune.value = (k - 1) * 5;
        o.connect(g);
        o.start(t);
        o.stop(t + dur + 0.5);
        this.live.push(o);
      });
      this.live.push(g);
      const waitMs = Math.max(60, (t + dur - ctx.currentTime - 0.2) * 1000);
      this.later(() => schedule(i + 1, t + dur), waitMs);
    };
    schedule(0, ctx.currentTime + 0.08);
  }

  private noiseSource(ctx: AC, filterFreq: number, gainVal: number, q = 0.6): AudioBufferSourceNode {
    const src = ctx.createBufferSource();
    src.buffer = this.noiseBuf!;
    src.loop = true;
    const filt = ctx.createBiquadFilter();
    filt.type = "lowpass";
    filt.frequency.value = filterFreq;
    filt.Q.value = q;
    const g = ctx.createGain();
    g.gain.value = gainVal;
    src.connect(filt);
    filt.connect(g);
    g.connect(this.master!);
    src.start();
    this.live.push(src, g);
    return src;
  }

  private startTexture(ctx: AC) {
    if (this.mood === "lofi") {
      this.noiseSource(ctx, 1350, 0.045); // rain
      // vinyl crackle: short bursts
      const crackle = () => {
        const t = ctx.currentTime;
        const src = ctx.createBufferSource();
        src.buffer = this.noiseBuf!;
        const bp = ctx.createBiquadFilter();
        bp.type = "bandpass";
        bp.frequency.value = 2600 + Math.random() * 1800;
        bp.Q.value = 8;
        const g = ctx.createGain();
        g.gain.setValueAtTime(0.05, t);
        g.gain.exponentialRampToValueAtTime(0.0001, t + 0.04 + Math.random() * 0.05);
        src.connect(bp);
        bp.connect(g);
        g.connect(this.master!);
        src.start(t);
        src.stop(t + 0.12);
        this.live.push(src);
        this.later(crackle, 120 + Math.random() * 600);
      };
      this.later(crackle, 400);
    } else if (this.mood === "forest") {
      this.noiseSource(ctx, 340, 0.05); // wind
      const bird = () => {
        const t = ctx.currentTime + 0.02;
        const o = ctx.createOscillator();
        o.type = "sine";
        const base = 2100 + Math.random() * 1300;
        o.frequency.setValueAtTime(base, t);
        o.frequency.exponentialRampToValueAtTime(base * 1.35, t + 0.07);
        o.frequency.exponentialRampToValueAtTime(base * 0.9, t + 0.16);
        const g = ctx.createGain();
        g.gain.setValueAtTime(0.0001, t);
        g.gain.linearRampToValueAtTime(0.035, t + 0.02);
        g.gain.exponentialRampToValueAtTime(0.0001, t + 0.2);
        o.connect(g);
        g.connect(this.master!);
        o.start(t);
        o.stop(t + 0.25);
        this.live.push(o);
        if (Math.random() < 0.5) {
          // little echo chirp
          const t2 = t + 0.22;
          const o2 = ctx.createOscillator();
          o2.type = "sine";
          o2.frequency.setValueAtTime(base * 1.12, t2);
          const g2 = ctx.createGain();
          g2.gain.setValueAtTime(0.0001, t2);
          g2.gain.linearRampToValueAtTime(0.022, t2 + 0.02);
          g2.gain.exponentialRampToValueAtTime(0.0001, t2 + 0.18);
          o2.connect(g2);
          g2.connect(this.master!);
          o2.start(t2);
          o2.stop(t2 + 0.22);
          this.live.push(o2);
        }
        this.later(bird, 2600 + Math.random() * 6500);
      };
      this.later(bird, 900);
    } else {
      this.noiseSource(ctx, 200, 0.035); // deep rumble air
    }
  }

  private startPluck(ctx: AC) {
    const scale = SCALES[this.mood];
    const pluck = () => {
      if (Math.random() < 0.72) {
        const t = ctx.currentTime + 0.02;
        const f = scale[Math.floor(Math.random() * scale.length)];
        const o = ctx.createOscillator();
        o.type = this.mood === "forest" ? "sine" : "triangle";
        o.frequency.value = f;
        const g = ctx.createGain();
        g.gain.setValueAtTime(0.0001, t);
        g.gain.linearRampToValueAtTime(0.055, t + 0.012);
        g.gain.exponentialRampToValueAtTime(0.0001, t + 0.9);
        const lp = ctx.createBiquadFilter();
        lp.type = "lowpass";
        lp.frequency.value = 2400;
        o.connect(g);
        g.connect(lp);
        lp.connect(this.master!);
        o.start(t);
        o.stop(t + 1);
        this.live.push(o);
      }
      this.later(pluck, 900 + Math.random() * 2100);
    };
    this.later(pluck, 1400);
  }

  /* ---------- one-shots ---------- */

  chime() {
    const ctx = this.ensure();
    const notes = [523.25, 659.25, 783.99];
    notes.forEach((f, i) => {
      const t = ctx.currentTime + i * 0.16;
      [f, f * 2].forEach((ff, j) => {
        const o = ctx.createOscillator();
        o.type = "sine";
        o.frequency.value = ff;
        const g = ctx.createGain();
        const peak = (j === 0 ? 0.16 : 0.05) / (i + 1) ** 0.5;
        g.gain.setValueAtTime(0.0001, t);
        g.gain.linearRampToValueAtTime(peak, t + 0.015);
        g.gain.exponentialRampToValueAtTime(0.0001, t + 1.4);
        o.connect(g);
        g.connect(this.master!);
        o.start(t);
        o.stop(t + 1.5);
      });
    });
  }

  blip() {
    const ctx = this.ensure();
    const t = ctx.currentTime;
    const o = ctx.createOscillator();
    o.type = "sine";
    o.frequency.setValueAtTime(740, t);
    o.frequency.exponentialRampToValueAtTime(980, t + 0.06);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.045, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.1);
    o.connect(g);
    g.connect(this.master!);
    o.start(t);
    o.stop(t + 0.12);
  }
}

export const ambient = new AmbientEngine();
