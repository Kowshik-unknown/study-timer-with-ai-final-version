import React, { useEffect, useRef, useState } from "react";
import { Icon, IconName } from "./icons";
import { useStore } from "../state/store";

/* ---------- scroll reveal ---------- */

export function Reveal({
  children,
  delay = 0,
  className = "",
}: {
  children: React.ReactNode;
  delay?: number;
  className?: string;
}) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            el.classList.add("is-in");
            io.disconnect();
          }
        });
      },
      { threshold: 0.08 }
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);
  return (
    <div ref={ref} className={`reveal ${className}`} style={{ transitionDelay: `${delay}ms` }}>
      {children}
    </div>
  );
}

/* ---------- headings ---------- */

export function SectionHead({
  kicker,
  title,
  desc,
  icon,
  tone = "leaf",
}: {
  kicker: string;
  title: string;
  desc?: string;
  icon: IconName;
  tone?: "leaf" | "gold" | "coral" | "aqua" | "lav";
}) {
  const toneText: Record<string, string> = {
    leaf: "text-leaf-400",
    gold: "text-gold-400",
    coral: "text-coral-400",
    aqua: "text-aqua-400",
    lav: "text-lav-400",
  };
  return (
    <div className="mb-6">
      <div className={`flex items-center gap-2 text-[11px] font-semibold tracking-[0.22em] uppercase ${toneText[tone]}`}>
        <Icon name={icon} size={15} strokeWidth={2} />
        {kicker}
      </div>
      <h2 className="font-display text-3xl md:text-[34px] font-bold leading-tight mt-2 text-mist-100">{title}</h2>
      {desc && <p className="text-mist-400 mt-2 max-w-2xl leading-relaxed">{desc}</p>}
    </div>
  );
}

/* ---------- ring progress ---------- */

export function Ring({
  pct,
  size = 200,
  stroke = 8,
  color = "#98dd66",
  track = "rgba(60,97,70,0.35)",
  children,
}: {
  pct: number;
  size?: number;
  stroke?: number;
  color?: string;
  track?: string;
  children?: React.ReactNode;
}) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  return (
    <div className="relative inline-flex items-center justify-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} stroke={track} strokeWidth={stroke} fill="none" />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          stroke={color}
          strokeWidth={stroke}
          strokeLinecap="round"
          fill="none"
          strokeDasharray={c}
          strokeDashoffset={c - (Math.max(0, Math.min(1, pct)) * c)}
          style={{ transition: "stroke-dashoffset 0.5s cubic-bezier(0.22,0.9,0.3,1)" }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">{children}</div>
    </div>
  );
}

/* ---------- animated number ---------- */

export function CountUp({ value, decimals = 0, className = "" }: { value: number; decimals?: number; className?: string }) {
  const [display, setDisplay] = useState(value);
  const prev = useRef(value);
  useEffect(() => {
    const from = prev.current;
    const to = value;
    prev.current = value;
    if (from === to) return;
    const start = performance.now();
    const dur = 650;
    let raf = 0;
    const tick = (t: number) => {
      const k = Math.min(1, (t - start) / dur);
      const eased = 1 - Math.pow(1 - k, 3);
      setDisplay(from + (to - from) * eased);
      if (k < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [value]);
  return <span className={className}>{display.toFixed(decimals)}</span>;
}

/* ---------- stat chip ---------- */

export function Stat({
  label,
  value,
  icon,
  tone = "text-leaf-400",
  sub,
}: {
  label: string;
  value: React.ReactNode;
  icon: IconName;
  tone?: string;
  sub?: string;
}) {
  return (
    <div className="panel px-4 py-3.5 flex items-center gap-3 min-w-0 transition-transform duration-200 hover:-translate-y-0.5">
      <div className={`shrink-0 w-9 h-9 rounded-lg bg-pine-700/60 border border-pine-600/50 flex items-center justify-center ${tone}`}>
        <Icon name={icon} size={17} />
      </div>
      <div className="min-w-0">
        <div className="text-[11px] uppercase tracking-wider text-mist-500 font-semibold">{label}</div>
        <div className="font-display font-bold text-lg leading-tight text-mist-100 truncate">{value}</div>
        {sub && <div className="text-[11px] text-mist-500">{sub}</div>}
      </div>
    </div>
  );
}

/* ---------- toasts ---------- */

export function ToastHost() {
  const { toasts, dismissToast } = useStore();
  const kindStyle: Record<string, { border: string; icon: IconName; color: string }> = {
    xp: { border: "border-gold-500/50", icon: "bolt", color: "text-gold-400" },
    ok: { border: "border-leaf-500/50", icon: "check", color: "text-leaf-400" },
    info: { border: "border-aqua-500/50", icon: "leaf", color: "text-aqua-400" },
    warn: { border: "border-coral-500/50", icon: "flame", color: "text-coral-400" },
  };
  return (
    <div className="fixed top-4 right-4 z-[90] flex flex-col gap-2 w-[300px] pointer-events-none">
      {toasts.map((t) => {
        const k = kindStyle[t.kind] || kindStyle.info;
        return (
          <div
            key={t.id}
            className={`toast-in pointer-events-auto panel ${k.border} border px-3.5 py-3 flex items-start gap-3 bg-pine-850/95 backdrop-blur`}
          >
            <div className={`${k.color} mt-0.5 shrink-0`}>
              <Icon name={k.icon} size={17} strokeWidth={2} />
            </div>
            <div className="min-w-0 flex-1">
              <div className="font-display font-bold text-sm text-mist-100">{t.title}</div>
              {t.sub && <div className="text-xs text-mist-400 mt-0.5 leading-snug">{t.sub}</div>}
            </div>
            <button
              onClick={() => dismissToast(t.id)}
              className="text-mist-600 hover:text-mist-200 transition-colors shrink-0"
              aria-label="Dismiss"
            >
              <Icon name="x" size={14} />
            </button>
          </div>
        );
      })}
    </div>
  );
}

/* ---------- modal ---------- */

export function Modal({
  open,
  onClose,
  title,
  children,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
}) {
  useEffect(() => {
    if (!open) return;
    const h = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[80] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-pine-950/80 backdrop-blur-sm" onClick={onClose} />
      <div className="pop-in relative panel w-full max-w-lg p-6 border-leaf-700/40">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-display font-bold text-lg text-mist-100">{title}</h3>
          <button onClick={onClose} className="text-mist-500 hover:text-mist-100 transition-colors" aria-label="Close">
            <Icon name="x" size={18} />
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

/* ---------- empty state ---------- */

export function EmptyState({
  icon,
  title,
  sub,
  action,
}: {
  icon: IconName;
  title: string;
  sub: string;
  action?: React.ReactNode;
}) {
  return (
    <div className="panel border-dashed border-pine-600/60 flex flex-col items-center justify-center text-center px-6 py-12">
      <div className="w-14 h-14 rounded-xl bg-pine-700/50 border border-pine-600/50 flex items-center justify-center text-leaf-400 mb-4">
        <Icon name={icon} size={26} strokeWidth={1.6} />
      </div>
      <div className="font-display font-bold text-lg text-mist-100">{title}</div>
      <p className="text-sm text-mist-400 mt-1.5 max-w-xs leading-relaxed">{sub}</p>
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}
