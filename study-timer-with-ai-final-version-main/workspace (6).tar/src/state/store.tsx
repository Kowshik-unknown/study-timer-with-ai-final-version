import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useReducer,
  useRef,
  useState,
} from "react";
import { ambient } from "../lib/audioEngine";
import type { Flashcard } from "../lib/textEngine";

/* ================= persistence + domain types ================= */

export type PlantType = "sprout" | "flower" | "tree" | "mushroom" | "fern";

export interface PlantRec {
  id: string;
  type: PlantType;
  x: number;
  z: number;
  s: number;
  planted: number;
}

export interface DeckRec {
  id: string;
  name: string;
  topic: string;
  cards: Flashcard[];
  created: number;
}

export interface AppSettings {
  onlineAI: boolean;
  autoPauseAway: boolean;
  chime: boolean;
  aiUrl: string;
  aiKey: string;
  aiModel: string;
}

export interface AwayEntry {
  at: number;
  secs: number;
}

export interface AppState {
  xp: number;
  streak: number;
  bestStreak: number;
  lastActive: string | null;
  totalMin: number;
  sessions: number;
  todayMin: number;
  todayKey: string;
  plants: PlantRec[];
  decks: DeckRec[];
  quizTaken: number;
  quizCorrect: number;
  quizTotal: number;
  settings: AppSettings;
  awaySecsToday: number;
  awayLog: AwayEntry[];
  lastAwaySecs: number;
  lastReturnAt: number;
}

export function fmtDur(sec: number): string {
  const s = Math.max(0, Math.round(sec));
  if (s < 60) return `${s}s`;
  const m = Math.floor(s / 60);
  if (m < 60) return `${m}m ${s % 60}s`;
  const h = Math.floor(m / 60);
  return `${h}h ${String(m % 60).padStart(2, "0")}m`;
}

const todayKey = () => new Date().toISOString().slice(0, 10);
const yesterdayKey = () => new Date(Date.now() - 86400000).toISOString().slice(0, 10);
const uid = () => Math.random().toString(36).slice(2, 10);

const DEFAULT_SETTINGS: AppSettings = {
  onlineAI: true,
  autoPauseAway: true,
  chime: true,
  aiUrl: "",
  aiKey: "",
  aiModel: "",
};

const DEFAULT_STATE: AppState = {
  xp: 0,
  streak: 0,
  bestStreak: 0,
  lastActive: null,
  totalMin: 0,
  sessions: 0,
  todayMin: 0,
  todayKey: todayKey(),
  plants: [],
  decks: [],
  quizTaken: 0,
  quizCorrect: 0,
  quizTotal: 0,
  settings: DEFAULT_SETTINGS,
  awaySecsToday: 0,
  awayLog: [],
  lastAwaySecs: 0,
  lastReturnAt: Date.now(),
};

const LS_KEY = "grove-state-v1";

function load(): AppState {
  try {
    const raw = localStorage.getItem(LS_KEY);
    if (!raw) return DEFAULT_STATE;
    const parsed = JSON.parse(raw) as AppState;
    const s = { ...DEFAULT_STATE, ...parsed, settings: { ...DEFAULT_SETTINGS, ...(parsed.settings || {}) } };
    if (s.todayKey !== todayKey()) {
      s.todayKey = todayKey();
      s.todayMin = 0;
      s.awaySecsToday = 0;
      s.awayLog = [];
    }
    s.lastReturnAt = Date.now();
    return s;
  } catch {
    return DEFAULT_STATE;
  }
}

/* ================= actions ================= */

type Action =
  | { type: "FINISH_FOCUS"; minutes: number }
  | { type: "AWARD"; xp: number }
  | { type: "ADD_PLANT"; plant: PlantRec }
  | { type: "SAVE_DECK"; deck: DeckRec }
  | { type: "DELETE_DECK"; id: string }
  | { type: "QUIZ"; correct: number; total: number }
  | { type: "SET_SETTINGS"; patch: Partial<AppSettings> }
  | { type: "AWAY"; secs: number; at: number }
  | { type: "MARK_RETURN"; at: number }
  | { type: "RESET" };

function touchStreak(s: AppState): AppState {
  const today = todayKey();
  if (s.lastActive === today) return s;
  const streak = s.lastActive === yesterdayKey() ? s.streak + 1 : 1;
  return { ...s, lastActive: today, streak, bestStreak: Math.max(streak, s.bestStreak) };
}

function reducer(state: AppState, action: Action): AppState {
  switch (action.type) {
    case "FINISH_FOCUS": {
      let s = touchStreak(state);
      s = {
        ...s,
        totalMin: s.totalMin + action.minutes,
        todayMin: s.todayMin + action.minutes,
        sessions: s.sessions + 1,
      };
      return s;
    }
    case "AWARD":
      return touchStreak({ ...state, xp: state.xp + action.xp });
    case "ADD_PLANT":
      return { ...state, plants: [...state.plants, action.plant].slice(-80) };
    case "SAVE_DECK":
      return {
        ...state,
        decks: [action.deck, ...state.decks.filter((d) => d.id !== action.deck.id)].slice(0, 12),
      };
    case "DELETE_DECK":
      return { ...state, decks: state.decks.filter((d) => d.id !== action.id) };
    case "QUIZ":
      return {
        ...state,
        quizTaken: state.quizTaken + 1,
        quizCorrect: state.quizCorrect + action.correct,
        quizTotal: state.quizTotal + action.total,
      };
    case "SET_SETTINGS":
      return { ...state, settings: { ...state.settings, ...action.patch } };
    case "AWAY":
      return {
        ...state,
        awaySecsToday: state.awaySecsToday + action.secs,
        lastAwaySecs: action.secs,
        lastReturnAt: action.at,
        awayLog: [{ at: action.at, secs: action.secs }, ...state.awayLog].slice(0, 6),
      };
    case "MARK_RETURN":
      return { ...state, lastReturnAt: action.at };
    case "RESET":
      return { ...DEFAULT_STATE, settings: state.settings, todayKey: todayKey(), lastReturnAt: Date.now() };
    default:
      return state;
  }
}

/* ================= levels ================= */

export function levelInfo(xp: number) {
  let level = 1;
  let spent = 0;
  const needFor = (l: number) => Math.round(120 * Math.pow(l, 1.3));
  while (xp - spent >= needFor(level)) {
    spent += needFor(level);
    level++;
  }
  const need = needFor(level);
  const into = xp - spent;
  return { level, into, need, pct: Math.min(100, Math.round((into / need) * 100)) };
}

export const GARDEN_TIERS = [
  { min: 0, name: "Bare Soil" },
  { min: 3, name: "First Sprouts" },
  { min: 8, name: "Sprouting Patch" },
  { min: 15, name: "Young Garden" },
  { min: 25, name: "Blooming Garden" },
  { min: 40, name: "Wild Meadow" },
  { min: 60, name: "Ancient Grove" },
];

export function gardenTier(count: number) {
  return [...GARDEN_TIERS].reverse().find((t) => count >= t.min) || GARDEN_TIERS[0];
}

/* ================= plants ================= */

function randomPlant(existing: PlantRec[]): PlantRec {
  const roll = Math.random();
  const type: PlantType =
    roll < 0.3 ? "sprout" : roll < 0.55 ? "flower" : roll < 0.72 ? "tree" : roll < 0.87 ? "mushroom" : "fern";
  let x = 0;
  let z = 0;
  for (let attempt = 0; attempt < 10; attempt++) {
    const r = 2.8 + Math.random() * 8.6;
    const a = Math.random() * Math.PI * 2;
    x = Math.cos(a) * r;
    z = Math.sin(a) * r;
    const clash = existing.some((p) => (p.x - x) ** 2 + (p.z - z) ** 2 < 1.1);
    if (!clash) break;
  }
  return { id: uid(), type, x, z, s: 0.85 + Math.random() * 0.45, planted: Date.now() };
}

/* ================= toasts ================= */

export type ToastKind = "xp" | "ok" | "info" | "warn";
export interface Toast {
  id: string;
  kind: ToastKind;
  title: string;
  sub?: string;
}

/* ================= timer ================= */

export type TimerMode = "focus" | "short" | "long";
export const MODE_MIN: Record<TimerMode, number> = { focus: 25, short: 5, long: 15 };
export const MODE_LABEL: Record<TimerMode, string> = {
  focus: "Focus",
  short: "Short Break",
  long: "Long Break",
};

interface TimerState {
  mode: TimerMode;
  duration: number; // seconds
  remaining: number; // seconds
  running: boolean;
  endsAt: number | null;
  cycles: number; // completed focus sessions in current set
}

/* ================= context ================= */

interface StoreApi {
  state: AppState;
  toasts: Toast[];
  toast: (kind: ToastKind, title: string, sub?: string) => void;
  dismissToast: (id: string) => void;
  award: (xp: number, reason: string) => void;
  timer: TimerState;
  setMode: (m: TimerMode) => void;
  setDurationMin: (min: number) => void;
  startTimer: () => void;
  pauseTimer: () => void;
  resetTimer: () => void;
  skipPhase: () => void;
  saveDeck: (name: string, topic: string, cards: Flashcard[]) => void;
  deleteDeck: (id: string) => void;
  recordQuiz: (correct: number, total: number) => void;
  setSettings: (patch: Partial<AppSettings>) => void;
  resetAll: () => void;
}

const StoreCtx = createContext<StoreApi | null>(null);

export function StoreProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(reducer, undefined, load);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [timer, setTimer] = useState<TimerState>({
    mode: "focus",
    duration: MODE_MIN.focus * 60,
    remaining: MODE_MIN.focus * 60,
    running: false,
    endsAt: null,
    cycles: 0,
  });
  const timerRef = useRef(timer);
  timerRef.current = timer;

  useEffect(() => {
    try {
      localStorage.setItem(LS_KEY, JSON.stringify(state));
    } catch {
      /* storage full / private mode */
    }
  }, [state]);

  const dismissToast = useCallback((id: string) => {
    setToasts((t) => t.filter((x) => x.id !== id));
  }, []);

  const toast = useCallback(
    (kind: ToastKind, title: string, sub?: string) => {
      const id = uid();
      setToasts((t) => [...t.slice(-3), { id, kind, title, sub }]);
      window.setTimeout(() => dismissToast(id), 4200);
    },
    [dismissToast]
  );

  const award = useCallback(
    (xp: number, reason: string) => {
      if (xp <= 0) return;
      dispatch({ type: "AWARD", xp });
      toast("xp", `+${xp} XP`, reason);
    },
    [toast]
  );

  const setSettings = useCallback((patch: Partial<AppSettings>) => {
    dispatch({ type: "SET_SETTINGS", patch });
  }, []);

  const stateRef = useRef(state);
  stateRef.current = state;

  /* ----- timer loop ----- */
  useEffect(() => {
    if (!timer.running || timer.endsAt === null) return;
    const iv = window.setInterval(() => {
      const t = timerRef.current;
      if (!t.running || t.endsAt === null) return;
      const rem = Math.max(0, Math.round((t.endsAt - Date.now()) / 1000));
      if (rem <= 0) {
        window.clearInterval(iv);
        finishPhase(t);
      } else {
        setTimer((prev) => ({ ...prev, remaining: rem }));
      }
    }, 300);
    return () => window.clearInterval(iv);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [timer.running, timer.endsAt]);

  const finishPhase = useCallback(
    (t: TimerState) => {
      const minutes = Math.max(1, Math.round(t.duration / 60));
      if (t.mode === "focus") {
        if (stateRef.current.settings.chime) ambient.chime();
        dispatch({ type: "FINISH_FOCUS", minutes });
        dispatch({ type: "AWARD", xp: minutes * 2 });
        const plant = randomPlant([]);
        dispatch({ type: "ADD_PLANT", plant });
        const nextCycles = t.cycles + 1;
        const goLong = nextCycles % 4 === 0;
        const nextMode: TimerMode = goLong ? "long" : "short";
        setTimer({
          mode: nextMode,
          duration: MODE_MIN[nextMode] * 60,
          remaining: MODE_MIN[nextMode] * 60,
          running: false,
          endsAt: null,
          cycles: nextCycles,
        });
        toast("xp", `+${minutes * 2} XP · focus complete`, `A ${plant.type} took root in your garden`);
      } else {
        ambient.blip();
        setTimer((prev) => ({
          ...prev,
          mode: "focus",
          duration: MODE_MIN.focus * 60,
          remaining: MODE_MIN.focus * 60,
          running: false,
          endsAt: null,
        }));
        toast("info", "Break finished", "Back to the garden — next focus session awaits");
      }
    },
    [toast]
  );

  const setMode = useCallback((m: TimerMode) => {
    setTimer((prev) =>
      prev.running
        ? prev
        : { ...prev, mode: m, duration: MODE_MIN[m] * 60, remaining: MODE_MIN[m] * 60, endsAt: null }
    );
  }, []);

  const setDurationMin = useCallback((min: number) => {
    setTimer((prev) =>
      prev.running
        ? prev
        : { ...prev, duration: min * 60, remaining: min * 60, endsAt: null }
    );
  }, []);

  const startTimer = useCallback(() => {
    const t = timerRef.current;
    if (t.running) return;
    setTimer((prev) => ({
      ...prev,
      running: true,
      endsAt: Date.now() + prev.remaining * 1000,
    }));
    if (t.mode === "focus") ambient.blip();
  }, []);

  const pauseTimer = useCallback(() => {
    setTimer((prev) => ({
      ...prev,
      running: false,
      endsAt: null,
      remaining: prev.endsAt ? Math.max(0, Math.round((prev.endsAt - Date.now()) / 1000)) : prev.remaining,
    }));
  }, []);

  const resetTimer = useCallback(() => {
    setTimer((prev) => ({ ...prev, running: false, endsAt: null, remaining: prev.duration }));
  }, []);

  const skipPhase = useCallback(() => {
    const t = timerRef.current;
    // skipping a focus phase does NOT grant rewards
    if (t.mode === "focus") {
      const nextCycles = t.cycles;
      const nextMode: TimerMode = nextCycles > 0 && nextCycles % 4 === 0 ? "long" : "short";
      setTimer({
        mode: nextMode,
        duration: MODE_MIN[nextMode] * 60,
        remaining: MODE_MIN[nextMode] * 60,
        running: false,
        endsAt: null,
        cycles: nextCycles,
      });
    } else {
      setTimer((prev) => ({
        ...prev,
        mode: "focus",
        duration: MODE_MIN.focus * 60,
        remaining: MODE_MIN.focus * 60,
        running: false,
        endsAt: null,
      }));
    }
  }, []);

  /* ----- distraction shield: track time away from the page ----- */
  useEffect(() => {
    let leftAt: number | null = null;
    const onVis = () => {
      if (document.hidden) {
        leftAt = Date.now();
        const t = timerRef.current;
        if (stateRef.current.settings.autoPauseAway && t.running && t.mode === "focus") {
          pauseTimer();
        }
      } else if (leftAt) {
        const secs = Math.round((Date.now() - leftAt) / 1000);
        leftAt = null;
        if (secs >= 5) {
          dispatch({ type: "AWAY", secs, at: Date.now() });
          if (secs >= 10) {
            toast("warn", `Away for ${fmtDur(secs)}`, "Logged to your distraction shield in the garden.");
          }
        } else {
          dispatch({ type: "MARK_RETURN", at: Date.now() });
        }
      }
    };
    document.addEventListener("visibilitychange", onVis);
    return () => document.removeEventListener("visibilitychange", onVis);
  }, [pauseTimer, toast]);

  const saveDeck = useCallback((name: string, topic: string, cards: Flashcard[]) => {
    dispatch({ type: "SAVE_DECK", deck: { id: uid(), name, topic, cards, created: Date.now() } });
  }, []);

  const deleteDeck = useCallback((id: string) => {
    dispatch({ type: "DELETE_DECK", id });
  }, []);

  const recordQuiz = useCallback((correct: number, total: number) => {
    dispatch({ type: "QUIZ", correct, total });
  }, []);

  const resetAll = useCallback(() => {
    dispatch({ type: "RESET" });
    localStorage.removeItem(LS_KEY);
  }, []);

  const api = useMemo<StoreApi>(
    () => ({
      state,
      toasts,
      toast,
      dismissToast,
      award,
      timer,
      setMode,
      setDurationMin,
      startTimer,
      pauseTimer,
      resetTimer,
      skipPhase,
      saveDeck,
      deleteDeck,
      recordQuiz,
      setSettings,
      resetAll,
    }),
    [state, toasts, toast, dismissToast, award, timer, setMode, setDurationMin, startTimer, pauseTimer, resetTimer, skipPhase, saveDeck, deleteDeck, recordQuiz, setSettings, resetAll]
  );

  return <StoreCtx.Provider value={api}>{children}</StoreCtx.Provider>;
}

export function useStore(): StoreApi {
  const ctx = useContext(StoreCtx);
  if (!ctx) throw new Error("useStore must be used inside StoreProvider");
  return ctx;
}
