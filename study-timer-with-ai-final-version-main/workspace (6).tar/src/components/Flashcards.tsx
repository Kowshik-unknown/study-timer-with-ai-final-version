import React, { useMemo, useState } from "react";
import { Icon } from "./icons";
import { EmptyState, Reveal, SectionHead } from "./shared";
import { Flashcard, makeFlashcards, SAMPLE_PASSAGE } from "../lib/textEngine";
import { useStore } from "../state/store";

const SUBJECTS = ["Biology", "History", "Computer Science", "Chemistry", "Literature", "Economics", "Physics", "General"];

function shuffleArr<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

export default function Flashcards() {
  const { state, saveDeck, deleteDeck, award, toast } = useStore();

  const [topic, setTopic] = useState("");
  const [subject, setSubject] = useState("Biology");
  const [source, setSource] = useState("");
  const [count, setCount] = useState(8);
  const [generating, setGenerating] = useState(false);

  const [deck, setDeck] = useState<Flashcard[]>([]);
  const [deckTopic, setDeckTopic] = useState("");
  const [deckName, setDeckName] = useState("");
  const [idx, setIdx] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const [knew, setKnew] = useState(0);
  const [again, setAgain] = useState(0);
  const [phase, setPhase] = useState<"build" | "review" | "done">("build");
  const [savedThisDeck, setSavedThisDeck] = useState(false);

  const generate = () => {
    if (source.trim().length < 200) {
      toast("warn", "A little more material needed", "Paste at least a paragraph (200+ characters) of your study material.");
      return;
    }
    setGenerating(true);
    window.setTimeout(() => {
      const cards = makeFlashcards(source, topic, count);
      setGenerating(false);
      if (cards.length < 2) {
        toast("warn", "Could not extract cards", "Try longer, factual text with repeated key terms.");
        return;
      }
      setDeck(cards);
      setDeckTopic(topic.trim() || subject);
      setDeckName(topic.trim() || `${subject} deck`);
      setIdx(0);
      setKnew(0);
      setAgain(0);
      setFlipped(false);
      setSavedThisDeck(false);
      setPhase("review");
      award(5, "Flashcards generated");
    }, 750);
  };

  const advance = (got: boolean) => {
    setKnew((k) => k + (got ? 1 : 0));
    setAgain((a) => a + (got ? 0 : 1));
    setFlipped(false);
    window.setTimeout(() => setIdx((i) => i + 1), 180);
    if (idx + 1 >= deck.length) {
      window.setTimeout(() => {
        setPhase("done");
        const earned = (got ? knew + 1 : knew) * 5 + (got ? again : again + 1);
        if (earned > 0) award(earned, "Flashcard review complete");
      }, 260);
    }
  };

  const finishSave = () => {
    if (savedThisDeck) return;
    saveDeck(deckName.trim() || deckTopic, deckTopic, deck);
    setSavedThisDeck(true);
    toast("ok", "Deck saved", `“${deckName.trim() || deckTopic}” is in your shelf below.`);
  };

  const loadDeck = (id: string) => {
    const d = state.decks.find((x) => x.id === id);
    if (!d) return;
    setDeck(d.cards);
    setDeckTopic(d.topic);
    setDeckName(d.name);
    setIdx(0);
    setKnew(0);
    setAgain(0);
    setFlipped(false);
    setSavedThisDeck(true);
    setPhase("review");
  };

  const current = deck[idx];
  const progress = deck.length ? (idx / deck.length) * 100 : 0;
  const accuracy = useMemo(() => {
    const total = knew + again;
    return total ? Math.round((knew / total) * 100) : 0;
  }, [knew, again]);

  return (
    <div>
      <SectionHead
        kicker="Flashcard Forge"
        title="Turn raw notes into a review deck"
        desc="Paste any study material — Grove extracts the key terms and builds cloze and definition cards automatically. Rate yourself to bank XP."
        icon="cards"
        tone="gold"
      />

      <div className="grid lg:grid-cols-[430px_1fr] gap-5 items-start">
        {/* ---------- generator ---------- */}
        <Reveal>
          <div className="panel p-5">
            <label className="block">
              <span className="text-[11px] uppercase tracking-wider font-semibold text-mist-500">Topic (optional)</span>
              <input
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                placeholder="e.g. Photosynthesis"
                className="mt-1.5 w-full rounded-lg bg-pine-900/80 border border-pine-600/70 px-3.5 py-2.5 text-sm text-mist-100 placeholder-mist-600 focus:border-leaf-500/60 outline-none transition-colors"
              />
            </label>

            <div className="mt-4">
              <span className="text-[11px] uppercase tracking-wider font-semibold text-mist-500">Subject</span>
              <div className="flex flex-wrap gap-1.5 mt-1.5">
                {SUBJECTS.map((s) => (
                  <button
                    key={s}
                    onClick={() => setSubject(s)}
                    className={`chip-btn rounded-md px-2.5 py-1 text-xs font-semibold border ${
                      subject === s
                        ? "border-gold-500/60 text-gold-300 bg-gold-500/15"
                        : "border-pine-600 text-mist-400 hover:text-mist-200"
                    }`}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>

            <label className="block mt-4">
              <div className="flex items-center justify-between">
                <span className="text-[11px] uppercase tracking-wider font-semibold text-mist-500">Source material</span>
                <button
                  onClick={() => {
                    setSource(SAMPLE_PASSAGE);
                    setTopic("Photosynthesis");
                  }}
                  className="chip-btn text-[11px] text-aqua-400 hover:text-aqua-300 font-semibold flex items-center gap-1"
                >
                  <Icon name="wand" size={12} /> use sample
                </button>
              </div>
              <textarea
                value={source}
                onChange={(e) => setSource(e.target.value)}
                rows={8}
                placeholder="Paste your notes, a textbook passage, lecture transcript…"
                className="mt-1.5 w-full rounded-lg bg-pine-900/80 border border-pine-600/70 px-3.5 py-2.5 text-sm text-mist-100 placeholder-mist-600 focus:border-leaf-500/60 outline-none transition-colors resize-y leading-relaxed"
              />
              <div className="text-[11px] text-mist-600 mt-1 text-right">{source.trim().length} chars</div>
            </label>

            <label className="block mt-3">
              <div className="flex justify-between text-[11px] font-semibold">
                <span className="uppercase tracking-wider text-mist-500">Cards to generate</span>
                <span className="text-gold-400 font-mono">{count}</span>
              </div>
              <input
                type="range"
                min={4}
                max={16}
                value={count}
                onChange={(e) => setCount(parseInt(e.target.value))}
                className="w-full mt-2"
                style={{ ["--fill" as string]: `${((count - 4) / 12) * 100}%` }}
              />
            </label>

            <button
              onClick={generate}
              disabled={generating}
              className="chip-btn mt-5 w-full flex items-center justify-center gap-2 rounded-lg px-4 py-3 font-display font-bold text-[15px] bg-gold-500/20 border border-gold-500/60 text-gold-200 hover:bg-gold-500/30 disabled:opacity-60 shadow-glow"
            >
              {generating ? (
                <>
                  <span className="w-4 h-4 rounded-full border-2 border-gold-300 border-t-transparent animate-spin" />
                  Distilling terms…
                </>
              ) : (
                <>
                  <Icon name="wand" size={16} strokeWidth={2} />
                  Generate deck
                </>
              )}
            </button>
            {generating && <div className="shimmer h-2 rounded-full mt-3" />}
          </div>
        </Reveal>

        {/* ---------- deck area ---------- */}
        <Reveal delay={90}>
          {phase === "build" && (
            <EmptyState
              icon="cards"
              title="No deck on the table yet"
              sub="Generate one from your notes on the left, or load a saved deck from your shelf below."
            />
          )}

          {phase === "review" && current && (
            <div className="panel p-5 sm:p-7">
              <div className="flex items-center justify-between gap-3">
                <div className="min-w-0">
                  <div className="text-[11px] uppercase tracking-widest text-mist-500 font-semibold">{deckTopic}</div>
                  <div className="font-display font-bold text-mist-100 truncate">
                    Card {idx + 1} <span className="text-mist-500 font-normal">of {deck.length}</span>
                  </div>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <span className="text-xs font-semibold text-leaf-400 border border-leaf-500/40 bg-leaf-600/15 rounded-md px-2 py-1">
                    {knew} knew
                  </span>
                  <span className="text-xs font-semibold text-coral-400 border border-coral-500/40 bg-coral-500/10 rounded-md px-2 py-1">
                    {again} again
                  </span>
                  <button
                    onClick={() => setDeck((d) => shuffleArr(d))}
                    className="chip-btn p-2 rounded-lg border border-pine-600 text-mist-400 hover:text-mist-100"
                    title="Shuffle deck"
                  >
                    <Icon name="shuffle" size={15} />
                  </button>
                </div>
              </div>

              <div className="h-1.5 rounded-full bg-pine-700/70 mt-3 overflow-hidden">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-leaf-600 to-leaf-400 transition-all duration-500"
                  style={{ width: `${progress}%` }}
                />
              </div>

              <button className="flip-scene block w-full mt-5 h-[300px] cursor-pointer group" onClick={() => setFlipped((f) => !f)}>
                <div className={`flip-inner ${flipped ? "flipped" : ""}`}>
                  <div className="flip-face panel rounded-xl bg-gradient-to-br from-pine-800 to-pine-850 flex flex-col items-center justify-center px-8 text-center border-pine-600/60 group-hover:border-leaf-500/50 transition-colors">
                    <span className="text-[10px] uppercase tracking-[0.25em] font-bold text-gold-400 mb-4">
                      {current.kind === "cloze" ? "Fill the blank" : current.kind === "def" ? "Definition" : "Big picture"}
                    </span>
                    <p className="font-display text-xl sm:text-2xl font-semibold leading-snug text-mist-100">{current.front}</p>
                    <span className="mt-6 text-[11px] text-mist-500 flex items-center gap-1.5">
                      <Icon name="cards" size={13} /> tap to flip
                    </span>
                  </div>
                  <div className="flip-face flip-back panel rounded-xl bg-gradient-to-br from-leaf-700/40 to-pine-850 flex flex-col items-center justify-center px-8 text-center border-leaf-500/40">
                    <span className="text-[10px] uppercase tracking-[0.25em] font-bold text-leaf-400 mb-4">Answer</span>
                    <p className={`font-semibold leading-relaxed text-mist-100 ${current.back.length > 60 ? "text-base sm:text-lg" : "font-display text-3xl"}`}>
                      {current.back}
                    </p>
                  </div>
                </div>
              </button>

              <div className="grid grid-cols-2 gap-3 mt-5">
                <button
                  onClick={() => advance(false)}
                  className="chip-btn flex items-center justify-center gap-2 rounded-lg px-4 py-3 font-semibold text-sm bg-coral-500/12 border border-coral-500/50 text-coral-300 hover:bg-coral-500/25"
                >
                  <Icon name="x" size={15} strokeWidth={2.4} /> Still learning
                </button>
                <button
                  onClick={() => advance(true)}
                  className="chip-btn flex items-center justify-center gap-2 rounded-lg px-4 py-3 font-semibold text-sm bg-leaf-600/20 border border-leaf-500/60 text-leaf-200 hover:bg-leaf-600/35"
                >
                  <Icon name="check" size={15} strokeWidth={2.4} /> Got it · +5 XP
                </button>
              </div>
            </div>
          )}

          {phase === "done" && (
            <div className="panel p-7 text-center rise-in">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-xl bg-leaf-600/20 border border-leaf-500/50 text-leaf-300 mb-4">
                <Icon name="star" size={30} strokeWidth={1.6} />
              </div>
              <h3 className="font-display text-2xl font-bold text-mist-100">Deck cleared</h3>
              <p className="text-mist-400 mt-1.5 text-sm">
                You knew <span className="text-leaf-300 font-bold">{knew}</span> of {deck.length} cards —{" "}
                <span className="text-gold-300 font-bold">{accuracy}%</span> accuracy.
              </p>
              {!savedThisDeck ? (
                <div className="flex gap-2 max-w-sm mx-auto mt-5">
                  <input
                    value={deckName}
                    onChange={(e) => setDeckName(e.target.value)}
                    className="flex-1 rounded-lg bg-pine-900/80 border border-pine-600/70 px-3 py-2 text-sm text-mist-100 outline-none focus:border-leaf-500/60"
                  />
                  <button
                    onClick={finishSave}
                    className="chip-btn rounded-lg px-4 py-2 text-sm font-semibold bg-leaf-600/25 border border-leaf-500/60 text-leaf-200 hover:bg-leaf-600/40"
                  >
                    Save deck
                  </button>
                </div>
              ) : (
                <p className="text-xs text-mist-500 mt-4">Deck saved to your shelf ✓</p>
              )}
              <div className="flex justify-center gap-2.5 mt-5">
                <button
                  onClick={() => {
                    setDeck((d) => shuffleArr(d));
                    setIdx(0);
                    setKnew(0);
                    setAgain(0);
                    setFlipped(false);
                    setPhase("review");
                  }}
                  className="chip-btn rounded-lg px-4 py-2 text-sm font-semibold border border-pine-600 text-mist-300 hover:text-mist-100 flex items-center gap-2"
                >
                  <Icon name="reset" size={14} /> Review again
                </button>
                <button
                  onClick={() => setPhase("build")}
                  className="chip-btn rounded-lg px-4 py-2 text-sm font-semibold border border-gold-500/50 bg-gold-500/15 text-gold-300 hover:bg-gold-500/25 flex items-center gap-2"
                >
                  <Icon name="plus" size={14} /> New deck
                </button>
              </div>
            </div>
          )}

          {/* saved shelf */}
          <div className="mt-5">
            <div className="flex items-center gap-2 mb-2.5">
              <Icon name="book" size={15} className="text-mist-500" />
              <span className="text-[11px] uppercase tracking-widest font-bold text-mist-500">Your shelf · {state.decks.length}</span>
            </div>
            {state.decks.length === 0 ? (
              <p className="text-xs text-mist-600 border border-dashed border-pine-600/60 rounded-lg px-4 py-3">
                Saved decks appear here so you can revisit them any time.
              </p>
            ) : (
              <div className="grid sm:grid-cols-2 gap-2.5">
                {state.decks.map((d) => (
                  <div key={d.id} className="panel rounded-lg px-3.5 py-3 flex items-center gap-3 group hover:border-pine-500 transition-colors">
                    <div className="w-8 h-8 rounded-md bg-gold-500/15 border border-gold-500/40 text-gold-400 flex items-center justify-center shrink-0">
                      <Icon name="cards" size={15} />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="text-sm font-semibold text-mist-100 truncate">{d.name}</div>
                      <div className="text-[11px] text-mist-500">
                        {d.cards.length} cards · {new Date(d.created).toLocaleDateString()}
                      </div>
                    </div>
                    <button
                      onClick={() => loadDeck(d.id)}
                      className="chip-btn text-xs font-semibold text-leaf-400 border border-leaf-500/40 rounded-md px-2.5 py-1 hover:bg-leaf-600/20"
                    >
                      Study
                    </button>
                    <button
                      onClick={() => {
                        deleteDeck(d.id);
                        toast("info", "Deck deleted", `“${d.name}” removed from the shelf.`);
                      }}
                      className="chip-btn text-mist-600 hover:text-coral-400 transition-colors"
                      aria-label="Delete deck"
                    >
                      <Icon name="trash" size={15} />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </Reveal>
      </div>
    </div>
  );
}
