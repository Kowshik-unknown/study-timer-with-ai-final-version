/* Step-by-step math solver: arithmetic, linear & quadratic equations, percentages. */

export interface MathResult {
  title: string;
  steps: string[];
  answer: string;
}

const fmt = (n: number): string => {
  if (!isFinite(n)) return "undefined";
  const r = Math.round(n * 1e6) / 1e6;
  return String(r);
};

/* ---------- safe arithmetic evaluator (shunting-yard) ---------- */

function evalArithmetic(expr: string): number | null {
  const s = expr
    .replace(/sqrt\(\s*(-?\d+(?:\.\d+)?)\s*\)/gi, (_, n) => fmt(Math.sqrt(parseFloat(n))))
    .replace(/[×·]/g, "*")
    .replace(/÷/g, "/")
    .replace(/\bx\b/gi, "*")
    .replace(/\s+/g, "");
  if (!/^[\d.+\-*/^()%]+$/.test(s)) return null;

  const tokens: (number | string)[] = [];
  let i = 0;
  while (i < s.length) {
    const c = s[i];
    if (/[\d.]/.test(c)) {
      let j = i;
      while (j < s.length && /[\d.]/.test(s[j])) j++;
      tokens.push(parseFloat(s.slice(i, j)));
      i = j;
    } else if ("+-*/^()%".includes(c)) {
      tokens.push(c);
      i++;
    } else return null;
  }

  // unary minus
  const norm: (number | string)[] = [];
  tokens.forEach((t, k) => {
    if (t === "-" && (k === 0 || (typeof tokens[k - 1] === "string" && tokens[k - 1] !== ")"))) {
      const next = tokens[k + 1];
      if (typeof next === "number") {
        norm.push(-next);
        tokens[k + 1] = 0;
        return;
      }
    }
    if (!(typeof t === "number" && t === 0 && norm.length && typeof tokens[k] === "number" && k > 0 && tokens[k - 1] === "-")) {
      norm.push(t);
    }
  });

  const prec: Record<string, number> = { "+": 1, "-": 1, "*": 2, "/": 2, "%": 2, "^": 3 };
  const out: (number | string)[] = [];
  const ops: string[] = [];
  for (const t of norm) {
    if (typeof t === "number") out.push(t);
    else if (t === "(") ops.push(t);
    else if (t === ")") {
      while (ops.length && ops[ops.length - 1] !== "(") out.push(ops.pop()!);
      ops.pop();
    } else {
      while (ops.length && prec[ops[ops.length - 1]] >= prec[t] && t !== "^") out.push(ops.pop()!);
      ops.push(t);
    }
  }
  while (ops.length) out.push(ops.pop()!);

  const st: number[] = [];
  for (const t of out) {
    if (typeof t === "number") st.push(t);
    else {
      const b = st.pop();
      const a = st.pop();
      if (a === undefined || b === undefined) return null;
      switch (t) {
        case "+": st.push(a + b); break;
        case "-": st.push(a - b); break;
        case "*": st.push(a * b); break;
        case "/": st.push(b === 0 ? NaN : a / b); break;
        case "%": st.push(a % b); break;
        case "^": st.push(Math.pow(a, b)); break;
      }
    }
  }
  return st.length === 1 ? st[0] : null;
}

/* ---------- equation helpers ---------- */

interface Lin { a: number; b: number }

function parseLinearSide(side: string): Lin | null {
  const s = side.replace(/\s+/g, "").replace(/−/g, "-").toLowerCase();
  if (!/^[+\-\d.x*/()]+$/.test(s)) return null;
  const re = /([+-]?)(\d*\.?\d*)\*?x|([+-]?\d+\.?\d*)/g;
  let a = 0;
  let b = 0;
  let m: RegExpExecArray | null;
  let matched = false;
  while ((m = re.exec(s)) !== null) {
    if (m[0] === "") break;
    matched = true;
    if (m[2] !== undefined && (m[2] !== "" || m[1] !== "" || s[m.index] !== undefined)) {
      const sign = m[1] === "-" ? -1 : 1;
      const coef = m[2] === "" ? 1 : parseFloat(m[2]);
      if (isNaN(coef)) return null;
      a += sign * coef;
    } else if (m[3] !== undefined) {
      b += parseFloat(m[3]);
    }
  }
  return matched ? { a, b } : null;
}

export function tryMath(raw: string): MathResult | null {
  const q = raw.replace(/\s+/g, " ").trim();
  const stripped =
    q
      .replace(/^(hey\s+|hi\s+|please\s+)?(can\s+you\s+|could\s+you\s+)?(solve|find|calculate|compute|evaluate|simplify|what\s+is|what's|whats|value\s+of)\s*/i, "")
      .replace(/[?.!]+\s*$/, "")
      .trim() || q;
  const compact = stripped.replace(/\s+/g, "").replace(/−/g, "-").toLowerCase();

  /* percentage */
  const pct =
    stripped.match(/(-?\d+(?:\.\d+)?)\s*%\s*of\s*(-?\d+(?:\.\d+)?)/i) ||
    q.match(/(-?\d+(?:\.\d+)?)\s*%\s*of\s*(-?\d+(?:\.\d+)?)/i);
  if (pct) {
    const p = parseFloat(pct[1]);
    const n = parseFloat(pct[2]);
    const val = (p / 100) * n;
    return {
      title: `Percentage · ${p}% of ${n}`,
      steps: [
        `Percent means “per hundred”, so ${p}% = ${p}/100 = ${fmt(p / 100)}.`,
        `Multiply the decimal by the number: ${fmt(p / 100)} × ${n}.`,
      ],
      answer: `${fmt(val)}`,
    };
  }

  const hasEq = compact.includes("=");

  /* quadratic: ax^2 + bx + c = 0 */
  if (hasEq && compact.includes("x^2")) {
    const [left, right] = compact.split("=");
    const rhs = right === "0" || right === "" ? 0 : evalArithmetic(right);
    if (rhs === null || isNaN(rhs)) return null;
    const side = rhs === 0 ? left : `${left}${rhs > 0 ? "-" : "+"}${Math.abs(rhs)}`;
    const re = /([+-]?\d*\.?\d*)x\^2(?:\s*([+-]\s*\d*\.?\d*)x)?(?:\s*([+-]\s*\d+\.?\d*))?/;
    const m = side.match(re);
    if (m) {
      const co = (s: string | undefined, def: number) => {
        if (s === undefined) return def;
        const t = s.replace(/\s+/g, "");
        if (t === "" || t === "+") return 1;
        if (t === "-") return -1;
        return parseFloat(t);
      };
      const a = m[1] === "" || m[1] === "+" ? 1 : m[1] === "-" ? -1 : parseFloat(m[1]);
      const b = co(m[2], 0);
      const c = co(m[3], 0);
      const D = b * b - 4 * a * c;
      const steps = [
        `Match against the standard form ax² + bx + c = 0 → a = ${fmt(a)}, b = ${fmt(b)}, c = ${fmt(c)}.`,
        `Compute the discriminant: D = b² − 4ac = (${fmt(b)})² − 4·(${fmt(a)})·(${fmt(c)}) = ${fmt(D)}.`,
      ];
      if (D > 0) {
        const r1 = (-b + Math.sqrt(D)) / (2 * a);
        const r2 = (-b - Math.sqrt(D)) / (2 * a);
        steps.push(
          `D > 0 → two distinct real roots. √D = ${fmt(Math.sqrt(D))}.`,
          `x = (−b ± √D) / 2a = (${fmt(-b)} ± ${fmt(Math.sqrt(D))}) / ${fmt(2 * a)}.`
        );
        return { title: "Quadratic equation", steps, answer: `x₁ = ${fmt(r1)},  x₂ = ${fmt(r2)}` };
      }
      if (D === 0) {
        const r = -b / (2 * a);
        steps.push(`D = 0 → one repeated root: x = −b / 2a.`);
        return { title: "Quadratic equation", steps, answer: `x = ${fmt(r)} (double root)` };
      }
      const rePart = -b / (2 * a);
      const imPart = Math.sqrt(-D) / (2 * a);
      steps.push(`D < 0 → no real roots; the roots are complex conjugates.`);
      return {
        title: "Quadratic equation",
        steps,
        answer: `x = ${fmt(rePart)} ± ${fmt(Math.abs(imPart))}i`,
      };
    }
  }

  /* linear */
  if (hasEq && /[x]/.test(compact)) {
    const [lRaw, rRaw] = compact.split("=");
    const L = parseLinearSide(lRaw);
    const R = parseLinearSide(rRaw);
    if (L && R && (L.a !== 0 || R.a !== 0)) {
      const a = L.a - R.a;
      const b = R.b - L.b;
      const steps = [
        `Collect x-terms on the left and constants on the right: ${fmt(L.a)}x − (${fmt(R.a)}x) = ${fmt(R.b)} − (${fmt(L.b)}).`,
        `Simplify: ${fmt(a)}x = ${fmt(b)}.`,
      ];
      if (a === 0) {
        return {
          title: "Linear equation",
          steps,
          answer: b === 0 ? "Infinitely many solutions (identity)" : "No solution (contradiction)",
        };
      }
      steps.push(`Divide both sides by ${fmt(a)}: x = ${fmt(b)} / ${fmt(a)}.`);
      return { title: "Linear equation", steps, answer: `x = ${fmt(b / a)}` };
    }
  }

  /* plain arithmetic */
  if (/^[\d\s+\-*/^().%×÷x·]+$/i.test(stripped) && /\d/.test(stripped) && /[+\-*/^%×÷]/.test(stripped)) {
    const val = evalArithmetic(stripped);
    if (val !== null && !isNaN(val)) {
      const pretty = stripped.replace(/\*/g, " × ").replace(/\//g, " ÷ ").replace(/\s+/g, " ").trim();
      return {
        title: "Arithmetic",
        steps: [
          `Expression: ${pretty}`,
          `Follow order of operations — brackets first, then powers, then × ÷, then + −.`,
        ],
        answer: fmt(val),
      };
    }
  }

  return null;
}
