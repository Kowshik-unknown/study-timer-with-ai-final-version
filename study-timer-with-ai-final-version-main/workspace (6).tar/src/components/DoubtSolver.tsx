import React, { useEffect, useRef, useState } from "react";
import { Icon } from "./icons";
import { SectionHead } from "./shared";
import { tryMath, MathResult } from "../lib/mathEngine";
import { KnowledgeEntry, searchKnowledge, SUGGESTED_DOUBTS } from "../lib/knowledge";
import { askOnlineAI } from "../lib/ai";
import { useStore } from "../state/store";

interface Msg {
  id: string;
  role: "user" | "bot";
  kind?: "math" | "knowledge" | "text" | "online";
  text?: string;
  math?: MathResult;
  entry?: KnowledgeEntry;
  engine?: string;
}

const uid = () => Math.random().toString(36).slice(2, 10);

const FALLBACKS = [
  (q: string) =>
    `Good question — let's break “${q}” down the way a tutor would:\n\n1. Restate it in your own words. If you can't, the gap is in vocabulary, not logic.\n2. Find the smallest sub-question you *can* answer, and build up from there.\n3. Teach the answer to an imaginary student — the moment you stumble is exactly where your doubt lives.\n\nExact equations and percentages are always solved on-device (try “solve 3x − 7 = 11”), and concept keywords like “photosynthesis” hit my local library instantly.`,
  (q: string) =>
    `I don't have a ready answer for “${q}”, but here's a 3-step doubt-clearing drill:\n\n1. Write the doubt as a single question mark sentence.\n2. List what you already know around it — usually 3–4 facts.\n3. Bridge the gap: which one fact, if true, would resolve it? Verify that one fact in your textbook.\n\nMeanwhile, try me on an equation, a percentage, or a topic keyword — I solve those step by step.`,
];

export default function DoubtSolver() {
  const { award, state } = useStore();
  const [messages, setMessages] = useState<Msg[]>([
    {
      id: uid(),
      role: "bot",
      kind: "text",
      text: "Namaste, scholar. Drop any doubt here — an equation, a physics derivation, a chemistry mechanism, or a concept like photosynthesis — and I'll walk through it step by step, with the working shown.",
    },
  ]);
  const [input, setInput] = useState("");
  const [thinking, setThinking] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const fallbackIdx = useRef(0);

  useEffect(() => {
    const el = scrollRef.current;
    if (el) el.scrollTo({ top: el.scrollHeight, behavior: "smooth" });
  }, [messages, thinking]);

  const send = async (raw?: string) => {
    const q = (raw ?? input).trim();
    if (!q || thinking) return;
    setInput("");
    setMessages((m) => [...m, { id: uid(), role: "user", kind: "text", text: q }]);
    setThinking(true);
    award(10, "Doubt asked — curiosity rewarded");

    const thinkDelay = 700 + Math.min(700, q.length * 10);
    const wait = (ms: number) => new Promise((r) => window.setTimeout(r, ms));

    /* 1 — exact math, solved on-device */
    const math = tryMath(q);
    if (math) {
      await wait(thinkDelay);
      setThinking(false);
      setMessages((m) => [...m, { id: uid(), role: "bot", kind: "math", math }]);
      return;
    }

    /* 2 — known concepts from the bank */
    const entry = searchKnowledge(q);
    if (entry) {
      await wait(thinkDelay);
      setThinking(false);
      setMessages((m) => [...m, { id: uid(), role: "bot", kind: "knowledge", entry }]);
      return;
    }

    /* 3 — anything else goes to the cloud tutor */
    const s = state.settings;
    let aiError: string | null = null;
    if (s.onlineAI) {
      try {
        const endpoint = s.aiUrl.trim() || s.aiKey.trim() ? { url: s.aiUrl, key: s.aiKey, model: s.aiModel } : null;
        const r = await askOnlineAI(q, endpoint);
        setThinking(false);
        setMessages((m) => [...m, { id: uid(), role: "bot", kind: "online", text: r.text, engine: r.engine }]);
        return;
      } catch (e) {
        aiError = e instanceof Error ? e.message : "network error";
      }
    }

    /* 4 — offline coaching */
    await wait(500);
    const fb = FALLBACKS[fallbackIdx.current % FALLBACKS.length](q);
    fallbackIdx.current++;
    const note = s.onlineAI
      ? `(Every AI route failed — ${aiError ?? "unknown error"}. Check the key in Settings, or use this strategy that always works.)\n\n`
      : "(Online AI is switched off in Settings, so here's a strategy that always works.)\n\n";
    setThinking(false);
    setMessages((m) => [...m, { id: uid(), role: "bot", kind: "text", text: note + fb }]);
  };

  return (
    <div>
      <SectionHead
        kicker="Doubt Clinic"
        title="Ask the doubt. Watch it dissolve."
        desc="Exact equations are solved step by step on-device; everything else — math, physics, chemistry, any subject — goes to the Gemini tutor with worked reasoning and a boxed answer. +10 XP for every doubt you ask."
        icon="spark"
        tone="aqua"
      />

      <div className="grid lg:grid-cols-[1fr_300px] gap-5 items-start">
        {/* chat */}
        <div className="panel flex flex-col h-[560px] sm:h-[600px] overflow-hidden">
          <div className="flex items-center gap-2.5 px-5 py-3.5 border-b border-pine-700/60">
            <div className="relative w-8 h-8 rounded-lg bg-aqua-500/15 border border-aqua-500/40 flex items-center justify-center text-aqua-400">
              <Icon name="brain" size={17} />
              <span className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full bg-leaf-400 pulse-dot" />
            </div>
            <div>
              <div className="font-display font-bold text-sm text-mist-100 leading-tight">Grove Tutor</div>
              <div className="text-[11px] text-mist-500">on-device · no data leaves your browser</div>
            </div>
            <span className="ml-auto text-[10px] uppercase tracking-widest font-bold text-leaf-400 border border-leaf-500/40 bg-leaf-600/15 rounded px-2 py-0.5">
              online
            </span>
          </div>

          <div ref={scrollRef} className="flex-1 overflow-y-auto px-5 py-4 space-y-4">
            {messages.map((m) =>
              m.role === "user" ? (
                <div key={m.id} className="flex justify-end rise-in">
                  <div className="max-w-[80%] rounded-xl rounded-br-sm bg-leaf-600/25 border border-leaf-500/40 px-4 py-2.5 text-sm text-mist-100 leading-relaxed">
                    {m.text}
                  </div>
                </div>
              ) : (
                <div key={m.id} className="flex gap-2.5 rise-in">
                  <div className="w-7 h-7 shrink-0 rounded-lg bg-aqua-500/15 border border-aqua-500/40 flex items-center justify-center text-aqua-400 mt-0.5">
                    <Icon name="brain" size={14} />
                  </div>
                  <div className="max-w-[85%] min-w-0">
                    {m.kind === "math" && m.math && (
                      <div className="panel rounded-xl rounded-tl-sm bg-pine-900/70 px-4 py-3.5">
                        <div className="flex items-center gap-2 text-gold-400">
                          <Icon name="bolt" size={14} strokeWidth={2} />
                          <span className="text-[11px] uppercase tracking-widest font-bold">{m.math.title}</span>
                          <span className="ml-auto text-[9px] uppercase tracking-widest font-bold text-leaf-400 border border-leaf-500/40 rounded px-1.5 py-0.5">
                            on-device
                          </span>
                        </div>
                        <ol className="mt-2.5 space-y-2">
                          {m.math.steps.map((s, i) => (
                            <li key={i} className="flex gap-2.5 text-sm text-mist-300 leading-relaxed">
                              <span className="shrink-0 w-5 h-5 rounded-md bg-pine-700 border border-pine-600 text-[10px] font-bold text-mist-400 flex items-center justify-center mt-0.5">
                                {i + 1}
                              </span>
                              <span className="font-mono text-[13px]">{s}</span>
                            </li>
                          ))}
                        </ol>
                        <div className="mt-3 rounded-lg bg-leaf-600/15 border border-leaf-500/40 px-3.5 py-2.5 flex items-center gap-2">
                          <Icon name="check" size={15} className="text-leaf-400 shrink-0" strokeWidth={2.4} />
                          <span className="font-mono font-semibold text-leaf-200 text-sm">{m.math.answer}</span>
                        </div>
                      </div>
                    )}
                    {m.kind === "knowledge" && m.entry && (
                      <div className="panel rounded-xl rounded-tl-sm bg-pine-900/70 px-4 py-3.5">
                        <div className="font-display font-bold text-mist-100">{m.entry.title}</div>
                        <p className="text-sm text-mist-300 leading-relaxed mt-1.5">{m.entry.body}</p>
                        {m.entry.steps && (
                          <ul className="mt-2.5 space-y-1.5">
                            {m.entry.steps.map((s, i) => (
                              <li key={i} className="flex gap-2 text-[13px] text-mist-400 leading-relaxed">
                                <Icon name="leaf" size={13} className="text-leaf-400 shrink-0 mt-1" />
                                {s}
                              </li>
                            ))}
                          </ul>
                        )}
                        <div className="flex flex-wrap gap-1.5 mt-3">
                          {m.entry.related.map((r) => (
                            <button
                              key={r}
                              onClick={() => send(`Explain ${r}`)}
                              className="chip-btn text-[11px] font-semibold text-aqua-400 border border-aqua-500/40 rounded-md px-2 py-1 hover:bg-aqua-500/15"
                            >
                              {r} ↗
                            </button>
                          ))}
                        </div>
                      </div>
                    )}
                    {m.kind === "online" && (
                      <div className="panel rounded-xl rounded-tl-sm bg-pine-900/70 px-4 py-3.5">
                        <div className="flex items-center gap-2 text-aqua-400 mb-2">
                          <Icon name="orbit" size={14} strokeWidth={2} />
                          <span className="text-[10px] uppercase tracking-widest font-bold">
                            cloud tutor · {m.engine || "gemini"}
                          </span>
                        </div>
                        <p className="text-sm text-mist-200 leading-relaxed whitespace-pre-line">{m.text}</p>
                      </div>
                    )}
                    {m.kind === "text" && (
                      <div className="panel rounded-xl rounded-tl-sm bg-pine-900/70 px-4 py-3 text-sm text-mist-300 leading-relaxed whitespace-pre-line">
                        {m.text}
                      </div>
                    )}
                  </div>
                </div>
              )
            )}

            {thinking && (
              <div className="flex gap-2.5 rise-in">
                <div className="w-7 h-7 shrink-0 rounded-lg bg-aqua-500/15 border border-aqua-500/40 flex items-center justify-center text-aqua-400">
                  <Icon name="brain" size={14} />
                </div>
                <div className="panel rounded-xl rounded-tl-sm bg-pine-900/70 px-4 py-3.5 flex items-center gap-1.5">
                  {[0, 1, 2].map((i) => (
                    <span key={i} className="typing-dot w-1.5 h-1.5 rounded-full bg-aqua-400 inline-block" />
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* suggestions */}
          <div className="px-5 pb-2 flex gap-1.5 overflow-x-auto pb-2.5 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
            {SUGGESTED_DOUBTS.map((s) => (
              <button
                key={s}
                onClick={() => send(s)}
                className="chip-btn shrink-0 text-[11px] font-semibold text-mist-400 border border-pine-600 rounded-full px-3 py-1.5 hover:text-aqua-300 hover:border-aqua-500/50"
              >
                {s}
              </button>
            ))}
          </div>

          <div className="px-4 pb-4 pt-1">
            <div className="flex items-end gap-2 rounded-xl bg-pine-900/80 border border-pine-600/70 focus-within:border-aqua-500/60 transition-colors px-3.5 py-2.5">
              <input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && send()}
                placeholder="Type your doubt… e.g. solve x^2 - 5x + 6 = 0"
                className="flex-1 bg-transparent outline-none text-sm text-mist-100 placeholder-mist-600"
              />
              <button
                onClick={() => send()}
                disabled={!input.trim() || thinking}
                className="chip-btn w-9 h-9 rounded-lg bg-aqua-500/20 border border-aqua-500/50 text-aqua-300 flex items-center justify-center hover:bg-aqua-500/35 disabled:opacity-40"
                aria-label="Send"
              >
                <Icon name="send" size={16} />
              </button>
            </div>
          </div>
        </div>

        {/* side rail */}
        <div className="space-y-4">
          <div className="panel p-4">
            <div className="flex items-center gap-2 text-gold-400 mb-2.5">
              <Icon name="bolt" size={15} strokeWidth={2} />
              <span className="text-[11px] uppercase tracking-widest font-bold">Rewards</span>
            </div>
            <p className="text-sm text-mist-300 leading-relaxed">
              Every doubt asked earns <span className="text-gold-300 font-bold">+10 XP</span> — asking is the skill we reward.
            </p>
          </div>
          <div className="panel p-4">
            <div className="flex items-center gap-2 text-aqua-400 mb-2.5">
              <Icon name="spark" size={15} />
              <span className="text-[11px] uppercase tracking-widest font-bold">What it solves</span>
            </div>
            <ul className="space-y-2">
              {[
                ["Linear equations", "2x + 5 = 17"],
                ["Quadratics", "x² − 5x + 6 = 0"],
                ["Arithmetic", "(128 + 56) / 8 × 3"],
                ["Percentages", "35% of 240"],
                ["Concepts", "16 science & math topics"],
                ["Anything else", "Gemini tutor · any subject"],
              ].map(([t, ex]) => (
                <li key={t} className="text-[13px] text-mist-400">
                  <span className="text-mist-200 font-semibold">{t}</span>
                  <span className="block font-mono text-[11px] text-mist-600">{ex}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
