/* Text → notes / flashcards / quizzes. All extractive, runs fully client-side. */

export interface Flashcard {
  id: string;
  front: string;
  back: string;
  kind: "cloze" | "def" | "topic";
}

export interface QuizQ {
  id: string;
  prompt: string;
  options: string[];
  answer: number;
  context: string;
}

export interface StudyNotes {
  title: string;
  summary: string[];
  keyPoints: string[];
  definitions: { term: string; def: string }[];
  outline: { heading: string; points: string[] }[];
  wordCount: number;
}

const STOP = new Set(
  "a,an,the,and,or,but,if,then,else,when,while,of,at,by,for,with,about,against,between,into,through,during,before,after,above,below,to,from,up,down,in,out,on,off,over,under,again,further,once,here,there,all,any,both,each,few,more,most,other,some,such,no,nor,not,only,own,same,so,than,too,very,can,will,just,should,now,is,are,was,were,be,been,being,have,has,had,having,do,does,did,doing,would,could,might,must,shall,may,it,its,itself,this,that,these,those,i,you,he,she,we,they,them,his,her,our,their,your,my,me,us,him,what,which,who,whom,as,also,been,such,one,two,three,per,via,etc,thus,hence,therefore,however,although,because,until,unless,upon,within,without,among,towards,toward,across,behind,beyond,around,along,despite,like,unlike,unlike,including,according,using,used,use,uses,make,makes,made,many,much,every,another,each,less,least,several,whole,often,always,never,sometimes,usually,generally,commonly,known,know,call,called,where,why,how,who,whom".split(",")
);

const uid = () => Math.random().toString(36).slice(2, 10);

export function cleanText(raw: string): string {
  return raw.replace(/\s+/g, " ").trim();
}

export function splitSentences(text: string): string[] {
  const t = cleanText(text);
  const matches = t.match(/[^.!?]+[.!?]+["')\]]*|[^.!?]+$/g) || [];
  return matches.map((s) => s.trim()).filter((s) => s.length > 35);
}

function words(text: string): string[] {
  return (text.toLowerCase().match(/[a-z][a-z'-]{2,}/g) || []).filter((w) => !STOP.has(w));
}

function freqMap(text: string): Map<string, number> {
  const m = new Map<string, number>();
  for (const w of words(text)) m.set(w, (m.get(w) || 0) + 1);
  return m;
}

export function keyTerms(text: string, n: number): string[] {
  const freq = freqMap(text);
  return [...freq.entries()]
    .filter(([w]) => w.length >= 4)
    .sort((a, b) => b[1] * (b[0].length > 6 ? 1.35 : 1) - a[1] * (a[0].length > 6 ? 1.35 : 1))
    .slice(0, n)
    .map(([w]) => w);
}

function scoreSentence(s: string, freq: Map<string, number>): number {
  const ws = words(s);
  if (ws.length === 0) return 0;
  const sum = ws.reduce((acc, w) => acc + (freq.get(w) || 0), 0);
  return sum / Math.sqrt(ws.length + 4);
}

function firstWords(s: string, n: number): string {
  const ws = s.split(" ").slice(0, n).join(" ");
  return s.split(" ").length > n ? ws + "…" : ws;
}

const truncate = (s: string, n: number) => (s.length > n ? s.slice(0, n - 1).trimEnd() + "…" : s);

function ranked(text: string): { s: string; score: number }[] {
  const freq = freqMap(text);
  return splitSentences(text)
    .map((s) => ({ s, score: scoreSentence(s, freq) }))
    .sort((a, b) => b.score - a.score);
}

export function summarize(text: string, n = 4): string[] {
  const r = ranked(text);
  const top = r.slice(0, n * 3).sort((a, b) => text.indexOf(a.s) - text.indexOf(b.s));
  return top.slice(0, n).map((x) => x.s);
}

function bestSentenceFor(term: string, sentences: string[]): string | null {
  const re = new RegExp(`\\b${term}\\b`, "i");
  const candidates = sentences.filter((s) => re.test(s));
  if (candidates.length === 0) return null;
  candidates.sort((a, b) => {
    const ideal = (s: string) => Math.abs(s.length - 130);
    return ideal(a) - ideal(b);
  });
  return candidates[0];
}

function cloze(sentence: string, term: string): string {
  const re = new RegExp(`\\b${term}\\b`, "i");
  return sentence.replace(re, "＿＿＿＿");
}

export function makeFlashcards(text: string, topic: string, count: number): Flashcard[] {
  const sentences = splitSentences(text);
  const terms = keyTerms(text, count * 2);
  const cards: Flashcard[] = [];
  const seen = new Set<string>();

  if (topic.trim()) {
    cards.push({
      id: uid(),
      kind: "topic",
      front: `Give a one-breath overview of “${topic.trim()}”.`,
      back: truncate(summarize(text, 2).join(" ") || firstWords(text, 40), 320),
    });
  }

  let i = 0;
  for (const term of terms) {
    if (cards.length >= count) break;
    const s = bestSentenceFor(term, sentences);
    if (!s) continue;
    if (i % 2 === 0) {
      const front = cloze(s, term);
      if (seen.has(front)) continue;
      seen.add(front);
      cards.push({ id: uid(), kind: "cloze", front, back: term.toUpperCase() });
    } else {
      const front = `Define: ${term}`;
      if (seen.has(front)) continue;
      seen.add(front);
      cards.push({ id: uid(), kind: "def", front, back: truncate(s, 260) });
    }
    i++;
  }
  return cards;
}

function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

export function makeQuiz(text: string, count = 8): QuizQ[] {
  const sentences = splitSentences(text);
  const terms = keyTerms(text, count * 3);
  const qs: QuizQ[] = [];
  const usedTerms = new Set<string>();

  for (const term of terms) {
    if (qs.length >= count) break;
    const s = bestSentenceFor(term, sentences);
    if (!s || s.length < 50) continue;
    const distractors = shuffle(terms.filter((t) => t !== term && !usedTerms.has(t))).slice(0, 3);
    if (distractors.length < 3) continue;
    usedTerms.add(term);
    const options = shuffle([term, ...distractors]);
    qs.push({
      id: uid(),
      prompt: cloze(s, term),
      options,
      answer: options.indexOf(term),
      context: s,
    });
  }
  return qs;
}

export function makeNotes(text: string, sourceTitle: string): StudyNotes {
  const paragraphs = text
    .split(/\n\s*\n|\n/)
    .map((p) => cleanText(p))
    .filter((p) => p.length > 90);

  const summary = summarize(text, 4);
  const summarySet = new Set(summary);
  const keyPoints = ranked(text)
    .filter((x) => !summarySet.has(x.s))
    .slice(0, 6)
    .map((x) => truncate(x.s, 170));

  const terms = keyTerms(text, 8);
  const sentences = splitSentences(text);
  const definitions = terms
    .map((t) => {
      const s = bestSentenceFor(t, sentences);
      return s ? { term: t, def: truncate(s, 220) } : null;
    })
    .filter((x): x is { term: string; def: string } => x !== null)
    .slice(0, 6);

  const outline = paragraphs.slice(0, 5).map((p) => {
    const freq = freqMap(p);
    const pts = splitSentences(p)
      .map((s) => ({ s, score: scoreSentence(s, freq) }))
      .sort((a, b) => b.score - a.score)
      .slice(0, 2)
      .map((x) => truncate(x.s, 160));
    return { heading: firstWords(p, 6), points: pts.length ? pts : [truncate(p, 160)] };
  });

  return {
    title: sourceTitle.trim() || firstWords(cleanText(text), 6) || "Untitled source",
    summary,
    keyPoints,
    definitions,
    outline,
    wordCount: (text.match(/\S+/g) || []).length,
  };
}

export function notesToMarkdown(n: StudyNotes): string {
  const lines: string[] = [`# ${n.title}`, "", "## Summary", ...n.summary.map((s) => `> ${s}`), ""];
  lines.push("## Key Points", ...n.keyPoints.map((k) => `- ${k}`), "");
  if (n.definitions.length) {
    lines.push("## Definitions", ...n.definitions.map((d) => `- **${d.term}** — ${d.def}`), "");
  }
  if (n.outline.length) {
    lines.push("## Outline");
    n.outline.forEach((o, i) => {
      lines.push(`### ${i + 1}. ${o.heading}`, ...o.points.map((p) => `- ${p}`), "");
    });
  }
  lines.push(`---\n_Generated in Grove · ${n.wordCount} words distilled_`);
  return lines.join("\n");
}

/* ---------- PDF extraction (pdf.js, lazy-loaded) ---------- */

export async function extractPdfText(
  file: File,
  onProgress: (pct: number, page: number, total: number) => void
): Promise<string> {
  const pdfjs = await import("pdfjs-dist");
  const worker = await import("pdfjs-dist/build/pdf.worker.min.mjs?url");
  pdfjs.GlobalWorkerOptions.workerSrc = worker.default;
  const data = await file.arrayBuffer();
  const doc = await pdfjs.getDocument({ data }).promise;
  let out = "";
  for (let i = 1; i <= doc.numPages; i++) {
    onProgress(i / doc.numPages, i, doc.numPages);
    const page = await doc.getPage(i);
    const tc = await page.getTextContent();
    out +=
      tc.items
        .map((it) => ("str" in it ? (it as { str: string }).str : ""))
        .join(" ") + "\n\n";
  }
  return out.trim();
}

export const SAMPLE_PASSAGE = `Photosynthesis is the process by which green plants convert light energy into chemical energy stored in glucose. It takes place mainly in the chloroplasts, which contain the green pigment chlorophyll. Chlorophyll absorbs red and blue wavelengths of light and reflects green, which is why most leaves appear green.

The process happens in two stages. The light-dependent reactions occur in the thylakoid membranes, where water molecules are split and oxygen is released as a by-product. These reactions produce ATP and NADPH, the energy carriers of the cell.

The light-independent stage, called the Calvin cycle, runs in the stroma of the chloroplast. Here carbon dioxide from the air is fixed into organic molecules using the ATP and NADPH made earlier. The enzyme RuBisCO catalyses the first major step of carbon fixation.

Several factors affect the rate of photosynthesis, including light intensity, carbon dioxide concentration and temperature. At low light, increasing light speeds up the process until another factor becomes limiting. This idea is known as the law of limiting factors.

Photosynthesis is essential for life on Earth. It supplies the oxygen we breathe and forms the base of nearly every food chain. The glucose produced is later broken down during cellular respiration to release usable energy for the plant.`;
