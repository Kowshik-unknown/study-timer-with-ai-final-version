import React, { useState } from "react";
import { Icon } from "./icons";
import { Modal, Reveal, SectionHead } from "./shared";
import { deriveVars, PRESETS, StoredTheme, ThemeBases } from "../lib/themes";
import { builtinKeyHint } from "../lib/ai";
import { useStore } from "../state/store";

interface Props {
  stored: StoredTheme;
  onPreset: (id: string) => void;
  onCustom: (bases: ThemeBases, name: string) => void;
}

function Toggle({
  on,
  onChange,
  label,
  sub,
}: {
  on: boolean;
  onChange: (v: boolean) => void;
  label: string;
  sub: string;
}) {
  return (
    <button
      onClick={() => onChange(!on)}
      className="chip-btn w-full flex items-center gap-3.5 text-left rounded-lg border border-pine-600/70 bg-pine-900/50 px-4 py-3 hover:border-pine-500"
    >
      <span className="min-w-0 flex-1">
        <span className="block text-sm font-semibold text-mist-100">{label}</span>
        <span className="block text-[11px] text-mist-500 mt-0.5 leading-snug">{sub}</span>
      </span>
      <span className={`relative w-10 h-[22px] shrink-0 rounded-full transition-colors duration-200 ${on ? "bg-leaf-600" : "bg-pine-600"}`}>
        <span
          className={`absolute top-[3px] w-4 h-4 rounded-full bg-mist-100 transition-all duration-200 ${on ? "left-[21px]" : "left-[3px]"}`}
        />
      </span>
    </button>
  );
}

const BASE_FIELDS: { key: keyof ThemeBases; label: string }[] = [
  { key: "bg", label: "Background" },
  { key: "text", label: "Text" },
  { key: "accent", label: "Accent" },
  { key: "warm", label: "Warm (XP)" },
  { key: "signal", label: "Signal (streak)" },
  { key: "info", label: "Info" },
  { key: "calm", label: "Calm" },
];

export default function Settings({ stored, onPreset, onCustom }: Props) {
  const { state, setSettings, resetAll, toast } = useStore();
  const s = state.settings;
  const [draft, setDraft] = useState<ThemeBases>(stored.custom ?? PRESETS[0].bases);
  const [name, setName] = useState(stored.customName || "My Theme");
  const [confirmReset, setConfirmReset] = useState(false);

  const tweak = (key: keyof ThemeBases, value: string) => {
    const next = { ...draft, [key]: value };
    setDraft(next);
    const el = document.documentElement;
    for (const [k, v] of Object.entries(deriveVars(next))) el.style.setProperty(k, v);
  };

  const saveCustom = () => {
    onCustom(draft, name.trim() || "My Theme");
    toast("ok", "Theme saved", `“${name.trim() || "My Theme"}” is now your look.`);
  };

  const previewVars = deriveVars(draft);

  return (
    <div>
      <SectionHead
        kicker="Settings"
        title="Make Grove unmistakably yours"
        desc="Pick a beloved theme or forge your own — every surface, glow and accent recolors live. Behavior and the AI tutor live here too."
        icon="gear"
        tone="gold"
      />

      {/* ---------------- themes ---------------- */}
      <Reveal>
        <div className="panel p-6 mb-5">
          <div className="flex items-center gap-2 text-gold-400 mb-4">
            <Icon name="palette" size={16} strokeWidth={2} />
            <span className="text-[11px] uppercase tracking-widest font-bold">Themes</span>
            <span className="text-[11px] text-mist-500 normal-case tracking-normal ml-1">click to apply instantly</span>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {PRESETS.map((p) => {
              const active = stored.presetId === p.id;
              return (
                <button
                  key={p.id}
                  onClick={() => onPreset(p.id)}
                  className={`chip-btn text-left rounded-xl border p-4 transition-all ${
                    active
                      ? "border-leaf-500/70 bg-leaf-600/12 shadow-glow"
                      : "border-pine-600/70 bg-pine-900/50 hover:border-pine-500 hover:-translate-y-0.5"
                  }`}
                >
                  <div
                    className="h-16 rounded-lg border border-black/20 relative overflow-hidden mb-3"
                    style={{ background: `linear-gradient(135deg, ${p.bases.bg} 0%, ${deriveVars(p.bases)["--t-pine-700"]} 100%)` }}
                  >
                    <span className="absolute top-2 left-2 right-2 h-1.5 rounded-full" style={{ background: p.bases.text, opacity: 0.85 }} />
                    <span className="absolute top-5 left-2 right-8 h-1.5 rounded-full" style={{ background: p.bases.text, opacity: 0.35 }} />
                    <span className="absolute bottom-2 left-2 w-10 h-4 rounded-md flex items-center justify-center" style={{ background: p.bases.accent }}>
                      <span className="w-6 h-1 rounded-full" style={{ background: p.bases.bg, opacity: 0.8 }} />
                    </span>
                    <span className="absolute bottom-2 right-2 w-4 h-4 rounded-full" style={{ background: p.bases.warm }} />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className={`font-display font-bold text-sm ${active ? "text-leaf-300" : "text-mist-100"}`}>{p.name}</span>
                    {active && <Icon name="check" size={15} className="text-leaf-400" strokeWidth={2.6} />}
                  </div>
                  <p className="text-[11px] text-mist-500 mt-0.5 leading-snug">{p.tagline}</p>
                </button>
              );
            })}

            {/* custom slot */}
            <div
              className={`rounded-xl border p-4 ${
                stored.presetId === "custom" ? "border-leaf-500/70 bg-leaf-600/12 shadow-glow" : "border-dashed border-pine-500/60 bg-pine-900/30"
              }`}
            >
              <div
                className="h-16 rounded-lg border border-black/20 relative overflow-hidden mb-3"
                style={{ background: `linear-gradient(135deg, ${draft.bg} 0%, ${previewVars["--t-pine-700"]} 100%)` }}
              >
                <span className="absolute top-2 left-2 right-2 h-1.5 rounded-full" style={{ background: draft.text, opacity: 0.85 }} />
                <span className="absolute top-5 left-2 right-8 h-1.5 rounded-full" style={{ background: draft.text, opacity: 0.35 }} />
                <span className="absolute bottom-2 left-2 w-10 h-4 rounded-md" style={{ background: draft.accent }} />
                <span className="absolute bottom-2 right-2 w-4 h-4 rounded-full" style={{ background: draft.warm }} />
              </div>
              <div className="flex items-center justify-between">
                <span className="font-display font-bold text-sm text-mist-100">{stored.custom ? stored.customName : "Your own theme"}</span>
                {stored.presetId === "custom" && <Icon name="check" size={15} className="text-leaf-400" strokeWidth={2.6} />}
              </div>
              <p className="text-[11px] text-mist-500 mt-0.5">Forge it below — it previews live as you pick colors</p>
            </div>
          </div>
        </div>
      </Reveal>

      {/* ---------------- custom forge ---------------- */}
      <Reveal delay={70}>
        <div className="grid lg:grid-cols-[1fr_330px] gap-5 mb-5 items-start">
          <div className="panel p-6">
            <div className="flex items-center gap-2 text-lav-400 mb-1">
              <Icon name="wand" size={16} strokeWidth={2} />
              <span className="text-[11px] uppercase tracking-widest font-bold">Theme forge</span>
            </div>
            <p className="text-xs text-mist-500 mb-4">
              Seven base colors — Grove derives every shade, glow and border from them. Changes apply as you drag.
            </p>
            <div className="grid sm:grid-cols-2 gap-3">
              {BASE_FIELDS.map((f) => (
                <label key={f.key} className="flex items-center gap-3 rounded-lg border border-pine-600/70 bg-pine-900/50 px-3.5 py-2.5">
                  <span
                    className="relative w-9 h-9 rounded-lg border-2 border-pine-500/60 overflow-hidden shrink-0 cursor-pointer"
                    style={{ background: draft[f.key] }}
                  >
                    <input
                      type="color"
                      value={draft[f.key]}
                      onChange={(e) => tweak(f.key, e.target.value)}
                      className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
                      aria-label={f.label}
                    />
                  </span>
                  <span className="min-w-0">
                    <span className="block text-[13px] font-semibold text-mist-100">{f.label}</span>
                    <span className="block font-mono text-[11px] text-mist-500 uppercase">{draft[f.key]}</span>
                  </span>
                </label>
              ))}
              <label className="flex items-center gap-3 rounded-lg border border-pine-600/70 bg-pine-900/50 px-3.5 py-2.5">
                <span className="w-9 h-9 rounded-lg border-2 border-pine-500/60 bg-pine-800 flex items-center justify-center text-mist-400 shrink-0">
                  <Icon name="notes" size={15} />
                </span>
                <span className="flex-1">
                  <input
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    maxLength={24}
                    placeholder="Theme name"
                    className="w-full bg-transparent outline-none text-[13px] font-semibold text-mist-100 placeholder-mist-600"
                  />
                  <span className="block text-[11px] text-mist-500">name your creation</span>
                </span>
              </label>
            </div>
            <div className="flex gap-2.5 mt-5">
              <button
                onClick={saveCustom}
                className="chip-btn flex items-center gap-2 rounded-lg px-4 py-2.5 text-sm font-bold bg-leaf-600/25 border border-leaf-500/60 text-leaf-200 hover:bg-leaf-600/40"
              >
                <Icon name="check" size={15} strokeWidth={2.4} />
                Save & apply my theme
              </button>
              <button
                onClick={() => {
                  const base = PRESETS[0].bases;
                  setDraft(base);
                  for (const [k, v] of Object.entries(deriveVars(base))) document.documentElement.style.setProperty(k, v);
                  toast("info", "Forge reset", "Back to Grove Nocturne bases.");
                }}
                className="chip-btn rounded-lg px-4 py-2.5 text-sm font-semibold border border-pine-600 text-mist-300 hover:text-mist-100"
              >
                Reset colors
              </button>
            </div>
          </div>

          {/* live mini preview */}
          <div className="panel p-5">
            <div className="text-[11px] uppercase tracking-widest font-bold text-mist-500 mb-3">Live preview</div>
            <div className="rounded-xl overflow-hidden border border-black/20" style={{ background: draft.bg, color: draft.text }}>
              <div className="px-4 py-3 flex items-center gap-2" style={{ background: previewVars["--t-pine-850"] }}>
                <span className="w-6 h-6 rounded-md flex items-center justify-center" style={{ background: draft.accent, color: draft.bg }}>
                  <Icon name="sprout" size={13} strokeWidth={2.4} />
                </span>
                <span className="font-display font-bold text-sm">Grove</span>
                <span
                  className="ml-auto rounded-full px-2 py-0.5 text-[10px] font-bold"
                  style={{ background: previewVars["--t-gold-500"], color: draft.bg }}
                >
                  240 XP
                </span>
              </div>
              <div className="p-4 space-y-2.5">
                <div className="rounded-lg p-3" style={{ background: previewVars["--t-pine-800"], border: `1px solid ${previewVars["--t-pine-600"]}` }}>
                  <div className="h-1.5 rounded-full w-3/4" style={{ background: draft.text, opacity: 0.9 }} />
                  <div className="h-1.5 rounded-full w-1/2 mt-2" style={{ background: draft.text, opacity: 0.4 }} />
                </div>
                <div className="flex gap-2">
                  <span className="rounded-md px-2.5 py-1.5 text-[10px] font-bold" style={{ background: draft.accent, color: draft.bg }}>
                    Start focus
                  </span>
                  <span className="rounded-md px-2.5 py-1.5 text-[10px] font-bold" style={{ background: previewVars["--t-coral-500"], color: draft.text }}>
                    3 day streak
                  </span>
                  <span className="rounded-md px-2.5 py-1.5 text-[10px] font-bold" style={{ background: previewVars["--t-aqua-500"], color: draft.bg }}>
                    Quiz
                  </span>
                </div>
              </div>
            </div>
            <p className="text-[11px] text-mist-600 mt-3 leading-relaxed">
              This is exactly how your garden, cards and panels will dress themselves.
            </p>
          </div>
        </div>
      </Reveal>

      {/* ---------------- behavior ---------------- */}
      <Reveal delay={120}>
        <div className="grid lg:grid-cols-2 gap-5 items-start">
          <div className="panel p-6">
            <div className="flex items-center gap-2 text-leaf-400 mb-4">
              <Icon name="shield" size={16} strokeWidth={2} />
              <span className="text-[11px] uppercase tracking-widest font-bold">Focus behavior</span>
            </div>
            <div className="space-y-2.5">
              <Toggle
                on={s.autoPauseAway}
                onChange={(v) => setSettings({ autoPauseAway: v })}
                label="Pause focus when I leave the page"
                sub="Switching tabs or minimizing pauses the timer and logs the absence to the distraction shield."
              />
              <Toggle
                on={s.chime}
                onChange={(v) => setSettings({ chime: v })}
                label="Chime when a session completes"
                sub="A soft bell marks the moment a plant takes root."
              />
            </div>
          </div>

          <div className="panel p-6">
            <div className="flex items-center gap-2 text-aqua-400 mb-4">
              <Icon name="brain" size={16} strokeWidth={2} />
              <span className="text-[11px] uppercase tracking-widest font-bold">AI doubt tutor</span>
              <span className="ml-auto flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wider text-leaf-400 border border-leaf-500/40 bg-leaf-600/10 rounded-full px-2 py-0.5">
                <span className="w-1.5 h-1.5 rounded-full bg-leaf-400 pulse-dot" />
                gemini · {builtinKeyHint(s.aiKey)}
              </span>
            </div>
            <Toggle
              on={s.onlineAI}
              onChange={(v) => setSettings({ onlineAI: v })}
              label="Online AI for any doubt"
              sub="Math and known concepts are solved on-device first. Everything else — math, physics, chemistry, any subject — is answered by the built-in Gemini tutor, with automatic fallbacks if a route is down."
            />
            <div className="grid gap-2.5 mt-3.5">
              <input
                value={s.aiUrl}
                onChange={(e) => setSettings({ aiUrl: e.target.value })}
                placeholder="Custom endpoint (optional) — https://api.openai.com/v1"
                className="rounded-lg bg-pine-900/80 border border-pine-600/70 px-3.5 py-2.5 text-[13px] font-mono text-mist-100 placeholder-mist-600 focus:border-aqua-500/60 outline-none"
              />
              <div className="grid grid-cols-2 gap-2.5">
                <input
                  value={s.aiKey}
                  onChange={(e) => setSettings({ aiKey: e.target.value })}
                  placeholder={`Tutor key — blank = built-in ${builtinKeyHint()}`}
                  type="password"
                  className="rounded-lg bg-pine-900/80 border border-pine-600/70 px-3.5 py-2.5 text-[13px] font-mono text-mist-100 placeholder-mist-600 focus:border-aqua-500/60 outline-none"
                />
                <input
                  value={s.aiModel}
                  onChange={(e) => setSettings({ aiModel: e.target.value })}
                  placeholder="Model — gemini-3.5-flash"
                  className="rounded-lg bg-pine-900/80 border border-pine-600/70 px-3.5 py-2.5 text-[13px] font-mono text-mist-100 placeholder-mist-600 focus:border-aqua-500/60 outline-none"
                />
              </div>
              <p className="text-[11px] text-mist-600 leading-relaxed">
                Grove ships with a built-in Gemini key (masked above). Paste your own Gemini or Pollinations key to override it — if a
                route is down, the next one picks up automatically. A custom endpoint below takes priority over everything and works
                with any OpenAI-compatible API, including local Ollama (
                <span className="font-mono">http://localhost:11434/v1</span>). Keys never leave your browser except to the endpoint
                they belong to.
              </p>
            </div>
          </div>
        </div>
      </Reveal>

      {/* ---------------- danger ---------------- */}
      <Reveal delay={160}>
        <div className="panel p-6 mt-5 border-coral-500/30">
          <div className="flex items-center justify-between gap-4 flex-wrap">
            <div>
              <div className="flex items-center gap-2 text-coral-400">
                <Icon name="trash" size={15} strokeWidth={2} />
                <span className="text-[11px] uppercase tracking-widest font-bold">Danger zone</span>
              </div>
              <p className="text-xs text-mist-500 mt-1.5">
                Wipe XP, streak, plants, decks and distraction logs. Themes and settings survive.
              </p>
            </div>
            <button
              onClick={() => setConfirmReset(true)}
              className="chip-btn rounded-lg px-4 py-2.5 text-sm font-bold border border-coral-500/50 bg-coral-500/10 text-coral-300 hover:bg-coral-500/25"
            >
              Reset all progress
            </button>
          </div>
        </div>
      </Reveal>

      <Modal open={confirmReset} onClose={() => setConfirmReset(false)} title="Reset all progress?">
        <p className="text-sm text-mist-300 leading-relaxed">
          Your garden returns to bare soil — {state.plants.length} plants, {state.xp} XP and a {state.streak}-day streak will be
          cleared. This cannot be undone.
        </p>
        <div className="flex gap-2.5 mt-6">
          <button
            onClick={() => {
              resetAll();
              setConfirmReset(false);
              toast("warn", "Progress reset", "The soil is bare again. Time to regrow.");
            }}
            className="chip-btn flex-1 rounded-lg px-4 py-2.5 text-sm font-bold border border-coral-500/60 bg-coral-500/20 text-coral-300 hover:bg-coral-500/35"
          >
            Yes, clear everything
          </button>
          <button
            onClick={() => setConfirmReset(false)}
            className="chip-btn flex-1 rounded-lg px-4 py-2.5 text-sm font-semibold border border-pine-600 text-mist-300 hover:text-mist-100"
          >
            Keep my garden
          </button>
        </div>
      </Modal>
    </div>
  );
}
