import React from "react";

export type IconName =
  | "sprout"
  | "timer"
  | "cards"
  | "spark"
  | "notes"
  | "target"
  | "flame"
  | "bolt"
  | "play"
  | "pause"
  | "reset"
  | "skip"
  | "music"
  | "volume"
  | "download"
  | "copy"
  | "check"
  | "x"
  | "plus"
  | "trash"
  | "shuffle"
  | "send"
  | "upload"
  | "leaf"
  | "book"
  | "brain"
  | "chart"
  | "clock"
  | "arrow"
  | "star"
  | "film"
  | "file"
  | "wand"
  | "orbit"
  | "gear"
  | "shield"
  | "palette";

const P: Record<IconName, React.ReactNode> = {
  sprout: (
    <>
      <path d="M12 21v-8" />
      <path d="M12 13c0-4.2-3.4-7.6-7.6-7.6C4.4 9.6 7.8 13 12 13Z" />
      <path d="M12 10.6c0-3 2.5-5.5 5.5-5.5 0 3-2.5 5.5-5.5 5.5Z" />
      <path d="M7 21h10" />
    </>
  ),
  timer: (
    <>
      <circle cx="12" cy="13.5" r="7.5" />
      <path d="M12 9.5v4l2.8 1.8" />
      <path d="M9.5 3h5" />
      <path d="M12 3v3" />
    </>
  ),
  cards: (
    <>
      <rect x="7.5" y="5" width="12.5" height="15" rx="2" />
      <path d="M5.5 8.5 5 17.6c-.15 1.2.7 2.3 1.9 2.4l8.6 1" />
      <path d="M11 9.5h5.5M11 13h5.5" />
    </>
  ),
  spark: (
    <>
      <path d="M12 3v4M12 17v4M3 12h4M17 12h4" />
      <path d="m6.2 6.2 2.4 2.4M15.4 15.4l2.4 2.4M6.2 17.8l2.4-2.4M15.4 8.6l2.4-2.4" />
      <circle cx="12" cy="12" r="2.2" />
    </>
  ),
  notes: (
    <>
      <path d="M7 3.5h7.5L19 8v11a1.5 1.5 0 0 1-1.5 1.5h-10A1.5 1.5 0 0 1 6 19V5a1.5 1.5 0 0 1 1-1.5Z" />
      <path d="M14 3.5V8h4.5" />
      <path d="M9.5 12.5c1.5-1.8 3.5-1.8 5 0M9.5 16c1.5-1.8 3.5-1.8 5 0" />
    </>
  ),
  target: (
    <>
      <circle cx="12" cy="12" r="8.5" />
      <circle cx="12" cy="12" r="4.5" />
      <circle cx="12" cy="12" r="0.8" fill="currentColor" />
      <path d="M12 2.5v3M12 18.5v3M2.5 12h3M18.5 12h3" />
    </>
  ),
  flame: (
    <>
      <path d="M12 21c3.9 0 6.5-2.6 6.5-6.2 0-2.7-1.6-4.6-3-6.3-1.2-1.4-2.4-2.8-2.7-4.5-2.3 1.5-3.4 3.4-3.3 5.6-1-.3-1.6-1-1.8-2-1.2 1.4-2.2 3.6-2.2 5.6C5.5 18.4 8.1 21 12 21Z" />
      <path d="M12 21c-1.8 0-3-1.4-3-3.1 0-1.5 1-2.5 3-4 2 1.5 3 2.5 3 4 0 1.7-1.2 3.1-3 3.1Z" />
    </>
  ),
  bolt: <path d="M13 2.5 5 13.5h5.5L10 21.5l8-11h-5.5L13 2.5Z" />,
  play: <path d="M8 5.5v13l10-6.5-10-6.5Z" />,
  pause: (
    <>
      <rect x="7" y="5.5" width="3.4" height="13" rx="1" />
      <rect x="13.6" y="5.5" width="3.4" height="13" rx="1" />
    </>
  ),
  reset: (
    <>
      <path d="M4.5 12a7.5 7.5 0 1 1 2.2 5.3" />
      <path d="M4.5 20v-5h5" />
    </>
  ),
  skip: (
    <>
      <path d="M5.5 5.5v13l8.5-6.5-8.5-6.5Z" />
      <path d="M17.5 5.5v13" />
    </>
  ),
  music: (
    <>
      <path d="M9 18.5V6.2l10-2v11.5" />
      <circle cx="6.5" cy="18.5" r="2.5" />
      <circle cx="16.5" cy="15.7" r="2.5" />
    </>
  ),
  volume: (
    <>
      <path d="M4 9.5v5h3.5L12 19V5L7.5 9.5H4Z" />
      <path d="M15.5 9a4.5 4.5 0 0 1 0 6M18 6.5a8 8 0 0 1 0 11" />
    </>
  ),
  download: (
    <>
      <path d="M12 4v10.5" />
      <path d="m7.5 10.5 4.5 4.5 4.5-4.5" />
      <path d="M5 19.5h14" />
    </>
  ),
  copy: (
    <>
      <rect x="8.5" y="8.5" width="11" height="11" rx="2" />
      <path d="M6 15.5H5.5A1.5 1.5 0 0 1 4 14V5.5A1.5 1.5 0 0 1 5.5 4H14a1.5 1.5 0 0 1 1.5 1.5V6" />
    </>
  ),
  check: <path d="m5 12.5 4.5 4.5L19 7.5" />,
  x: <path d="M6 6l12 12M18 6 6 18" />,
  plus: <path d="M12 5v14M5 12h14" />,
  trash: (
    <>
      <path d="M4.5 7h15M9.5 7V5a1 1 0 0 1 1-1h3a1 1 0 0 1 1 1v2" />
      <path d="M6.5 7l1 12.2a1.5 1.5 0 0 0 1.5 1.3h6a1.5 1.5 0 0 0 1.5-1.3l1-12.2" />
      <path d="M10 11v6M14 11v6" />
    </>
  ),
  shuffle: (
    <>
      <path d="M3.5 6.5h3.2c5.5 0 6.6 11 12 11h1.8" />
      <path d="M3.5 17.5h3.2c2.2 0 3.7-1.8 5-3.9M20.5 6.5h-1.8c-2.2 0-3.7 1.8-5 3.9" />
      <path d="m17.5 3.5 3.5 3-3.5 3M17.5 14.5l3.5 3-3.5 3" />
    </>
  ),
  send: <path d="M4 11.5 20 4l-4.5 16-4-6.5L4 11.5ZM11.5 13.5 20 4" />,
  upload: (
    <>
      <path d="M12 15V4.5" />
      <path d="m7.5 8.5 4.5-4.5 4.5 4.5" />
      <path d="M5 19.5h14" />
    </>
  ),
  leaf: (
    <>
      <path d="M5 19C5 9.5 11.5 4.5 20 4c-.5 8.5-5.5 15-15 15Z" />
      <path d="M5 19c3-5.5 6.5-9 11-11.5" />
    </>
  ),
  book: (
    <>
      <path d="M12 6.5c-1.8-1.6-4.4-2-8-1.5v13.5c3.6-.5 6.2-.1 8 1.5 1.8-1.6 4.4-2 8-1.5V5c-3.6-.5-6.2-.1-8 1.5Z" />
      <path d="M12 6.5V20" />
    </>
  ),
  brain: (
    <>
      <path d="M9.5 4A2.5 2.5 0 0 0 7 6.5c-1.9.3-3 1.7-3 3.5 0 .9.3 1.7.8 2.3-.5.6-.8 1.4-.8 2.2 0 2 1.5 3.5 3.5 3.5.3 1.2 1.3 2 2.5 2s2-1 2-2.5V6.5A2.5 2.5 0 0 0 9.5 4Z" />
      <path d="M14.5 4A2.5 2.5 0 0 1 17 6.5c1.9.3 3 1.7 3 3.5 0 .9-.3 1.7-.8 2.3.5.6.8 1.4.8 2.2 0 2-1.5 3.5-3.5 3.5-.3 1.2-1.3 2-2.5 2s-2-1-2-2.5V6.5A2.5 2.5 0 0 1 14.5 4Z" />
    </>
  ),
  chart: (
    <>
      <path d="M4 4v16h16" />
      <path d="M8 16v-5M12.5 16V7.5M17 16v-8.5" />
    </>
  ),
  clock: (
    <>
      <circle cx="12" cy="12" r="8.5" />
      <path d="M12 7v5l3.2 2" />
    </>
  ),
  arrow: <path d="M4.5 12h15m0 0-5.5-5.5M19.5 12 14 17.5" />,
  star: <path d="m12 3.5 2.6 5.4 5.9.8-4.3 4.1 1 5.9-5.2-2.8-5.2 2.8 1-5.9-4.3-4.1 5.9-.8L12 3.5Z" />,
  film: (
    <>
      <rect x="3.5" y="5" width="17" height="14" rx="2" />
      <path d="M8 5v14M16 5v14M3.5 9.5H8M3.5 14.5H8M16 9.5h4.5M16 14.5h4.5" />
    </>
  ),
  file: (
    <>
      <path d="M7 3.5h7.5L19 8v11a1.5 1.5 0 0 1-1.5 1.5h-10A1.5 1.5 0 0 1 6 19V5a1.5 1.5 0 0 1 1-1.5Z" />
      <path d="M14 3.5V8h4.5M9.5 12h5M9.5 15.5h5" />
    </>
  ),
  wand: (
    <>
      <path d="m5 19 9.5-9.5M16 4.5v3M14.5 6h3M19.5 9.5v2M18.5 10.5h2M10 3.5v2M9 4.5h2" />
      <path d="M5 19l-1.5 1.5" />
    </>
  ),
  orbit: (
    <>
      <circle cx="12" cy="12" r="3" />
      <path d="M18.5 7.5c1.8 2.6.6 6.8-2.9 9.8S7.6 21.5 5.5 19c-2-2.5-.4-6.6 3.1-9.6s8.1-4.5 9.9-1.9Z" transform="rotate(20 12 12)" />
    </>
  ),
  gear: (
    <>
      <circle cx="12" cy="12" r="3.2" />
      <path d="M12 2.8l1.2 2.4 2.6-.6 1 2.4 2.6.6-.5 2.6 2 1.8-2 1.8.5 2.6-2.6.6-1 2.4-2.6-.6L12 21.2l-1.2-2.4-2.6.6-1-2.4-2.6-.6.5-2.6-2-1.8 2-1.8-.5-2.6 2.6-.6 1-2.4 2.6.6L12 2.8Z" />
    </>
  ),
  shield: (
    <>
      <path d="M12 3 5 5.8v5.4c0 4.6 3 8 7 9.8 4-1.8 7-5.2 7-9.8V5.8L12 3Z" />
      <path d="m9 11.5 2.2 2.2L15.5 9" />
    </>
  ),
  palette: (
    <>
      <path d="M12 3.5a8.5 8.5 0 1 0 0 17c1.3 0 2-.8 2-1.8 0-.9-.6-1.4-.6-2.2 0-1 .8-1.8 2-1.8h1.8c2 0 3.3-1.4 3.3-3.2 0-4.6-4-8-8.5-8Z" />
      <circle cx="8.2" cy="9.5" r="1.1" fill="currentColor" stroke="none" />
      <circle cx="12.5" cy="7.2" r="1.1" fill="currentColor" stroke="none" />
      <circle cx="16.6" cy="9.8" r="1.1" fill="currentColor" stroke="none" />
      <circle cx="7.6" cy="14" r="1.1" fill="currentColor" stroke="none" />
    </>
  ),
};

export function Icon({
  name,
  size = 18,
  className = "",
  strokeWidth = 1.8,
}: {
  name: IconName;
  size?: number;
  className?: string;
  strokeWidth?: number;
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
    >
      {P[name]}
    </svg>
  );
}
