/* Theme engine — every palette in Grove derives from 8 base colors. */

export interface ThemeBases {
  bg: string;
  text: string;
  accent: string;
  warm: string;
  signal: string;
  info: string;
  calm: string;
}

export interface ThemePreset {
  id: string;
  name: string;
  tagline: string;
  bases: ThemeBases;
}

export const PRESETS: ThemePreset[] = [
  {
    id: "grove",
    name: "Grove Nocturne",
    tagline: "The original — deep pine, leaf-light & firefly gold",
    bases: {
      bg: "#08110c",
      text: "#eaf3e4",
      accent: "#98dd66",
      warm: "#f4c566",
      signal: "#e97261",
      info: "#63bcb2",
      calm: "#c0b1ec",
    },
  },
  {
    id: "ember",
    name: "Ember Dusk",
    tagline: "Charred wood, amber lanterns, slow smoke",
    bases: {
      bg: "#120d0a",
      text: "#f5ead9",
      accent: "#f5a352",
      warm: "#e8c06a",
      signal: "#e4694f",
      info: "#c99a6b",
      calm: "#c58fd9",
    },
  },
  {
    id: "oceanic",
    name: "Oceanic Deep",
    tagline: "Abyssal navy with bioluminescent teal",
    bases: {
      bg: "#06111a",
      text: "#e4f2f4",
      accent: "#4fd6b4",
      warm: "#f2c268",
      signal: "#f28d7a",
      info: "#5fb2e8",
      calm: "#9d8ff0",
    },
  },
  {
    id: "orchid",
    name: "Orchid Night",
    tagline: "Plum dark, petal violet, rose signal",
    bases: {
      bg: "#120c17",
      text: "#f0e9f5",
      accent: "#cf9df5",
      warm: "#f2b56b",
      signal: "#ef86a8",
      info: "#7fc8d9",
      calm: "#a99bf0",
    },
  },
  {
    id: "daylight",
    name: "Daylight Sage",
    tagline: "A bright, calm paper garden for daytime study",
    bases: {
      bg: "#eef1e9",
      text: "#1c291f",
      accent: "#3d7d39",
      warm: "#a5761a",
      signal: "#bd4f37",
      info: "#2c7a72",
      calm: "#6757ad",
    },
  },
];

/* ---------- color math ---------- */

function hexToRgb(hex: string): [number, number, number] {
  const h = hex.replace("#", "");
  const full = h.length === 3 ? h.split("").map((c) => c + c).join("") : h;
  const n = parseInt(full, 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

function rgbToHex(r: number, g: number, b: number): string {
  const c = (x: number) => Math.max(0, Math.min(255, Math.round(x))).toString(16).padStart(2, "0");
  return `#${c(r)}${c(g)}${c(b)}`;
}

/** mix color a toward color b by t (0..1) */
function mix(a: string, b: string, t: number): string {
  const [ar, ag, ab] = hexToRgb(a);
  const [br, bg, bb] = hexToRgb(b);
  return rgbToHex(ar + (br - ar) * t, ag + (bg - ag) * t, ab + (bb - ab) * t);
}

/* ---------- derivation ---------- */

export function deriveVars(b: ThemeBases): Record<string, string> {
  const { bg, text, accent, warm, signal, info, calm } = b;
  const v: Record<string, string> = {};

  // surfaces (bg nudged toward text — works for dark and light themes)
  v["--t-pine-950"] = bg;
  v["--t-pine-900"] = mix(bg, text, 0.045);
  v["--t-pine-850"] = mix(bg, text, 0.08);
  v["--t-pine-800"] = mix(bg, text, 0.125);
  v["--t-pine-700"] = mix(bg, text, 0.2);
  v["--t-pine-600"] = mix(bg, text, 0.28);
  v["--t-pine-500"] = mix(bg, text, 0.38);

  // ink scale (text faded toward bg)
  v["--t-mist-100"] = text;
  v["--t-mist-200"] = mix(text, bg, 0.12);
  v["--t-mist-300"] = mix(text, bg, 0.24);
  v["--t-mist-400"] = mix(text, bg, 0.36);
  v["--t-mist-500"] = mix(text, bg, 0.47);
  v["--t-mist-600"] = mix(text, bg, 0.58);
  v["--t-mist-700"] = mix(text, bg, 0.68);

  // accent (leaf)
  v["--t-leaf-200"] = mix(accent, text, 0.55);
  v["--t-leaf-300"] = mix(accent, text, 0.32);
  v["--t-leaf-400"] = accent;
  v["--t-leaf-500"] = mix(accent, bg, 0.28);
  v["--t-leaf-600"] = mix(accent, bg, 0.48);
  v["--t-leaf-700"] = mix(accent, bg, 0.64);

  // warm (gold)
  v["--t-gold-200"] = mix(warm, text, 0.58);
  v["--t-gold-300"] = mix(warm, text, 0.35);
  v["--t-gold-400"] = warm;
  v["--t-gold-500"] = mix(warm, bg, 0.25);
  v["--t-gold-600"] = mix(warm, bg, 0.48);

  // signal (coral)
  v["--t-coral-300"] = mix(signal, text, 0.42);
  v["--t-coral-400"] = signal;
  v["--t-coral-500"] = mix(signal, bg, 0.22);
  v["--t-coral-600"] = mix(signal, bg, 0.44);

  // info (aqua)
  v["--t-aqua-300"] = mix(info, text, 0.42);
  v["--t-aqua-400"] = info;
  v["--t-aqua-500"] = mix(info, bg, 0.26);

  // calm (lavender)
  v["--t-lav-300"] = mix(calm, text, 0.35);
  v["--t-lav-400"] = calm;

  // ambient glows
  v["--t-glow1"] = accent;
  v["--t-glow2"] = info;
  v["--t-glow3"] = warm;
  return v;
}

export function applyTheme(bases: ThemeBases) {
  const vars = deriveVars(bases);
  const el = document.documentElement;
  for (const [k, val] of Object.entries(vars)) el.style.setProperty(k, val);
}

/* ---------- persistence ---------- */

const LS_KEY = "grove-theme-v1";

export interface StoredTheme {
  presetId: string;
  custom: ThemeBases | null;
  customName: string;
}

export function loadStoredTheme(): StoredTheme {
  try {
    const raw = localStorage.getItem(LS_KEY);
    if (raw) return { presetId: "grove", custom: null, customName: "My Theme", ...JSON.parse(raw) };
  } catch {
    /* ignore */
  }
  return { presetId: "grove", custom: null, customName: "My Theme" };
}

export function saveStoredTheme(t: StoredTheme) {
  try {
    localStorage.setItem(LS_KEY, JSON.stringify(t));
  } catch {
    /* ignore */
  }
}

export function resolveBases(t: StoredTheme): ThemeBases {
  if (t.presetId === "custom" && t.custom) return t.custom;
  return PRESETS.find((p) => p.id === t.presetId)?.bases || PRESETS[0].bases;
}
